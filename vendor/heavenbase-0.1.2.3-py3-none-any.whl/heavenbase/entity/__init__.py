"""Entity declaration and JSON compiler."""

__all__ = [
    "ComputeCallable",
    "ComputeHook",
    "DeriveSpec",
    "Entity",
    "EntityMeta",
    "FieldRef",
    "FieldSpec",
    "QueryComputeHook",
    "field",
    "pending_entities",
    "register_compute",
    "register_query_compute",
    "registered_computes",
    "registered_query_computes",
]

from .base import Entity, EntityMeta, pending_entities
from .computes import ComputeCallable, register_compute, register_query_compute, registered_computes, registered_query_computes
from .fields import ComputeHook, DeriveSpec, FieldSpec, QueryComputeHook, field
from .ref import FieldRef
