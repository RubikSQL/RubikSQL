"""LLM CLI command group."""

from __future__ import annotations

__all__ = ["llm_group"]

from .group import llm_group
