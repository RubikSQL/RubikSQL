"""Prompt CLI command group."""

from __future__ import annotations

__all__ = ["prompt_group"]

from .group import prompt_group
