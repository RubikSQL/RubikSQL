"""MCP and Toolkit CLI command group facade."""

from __future__ import annotations

from .group import mcp_group

__all__ = ["mcp_group"]
