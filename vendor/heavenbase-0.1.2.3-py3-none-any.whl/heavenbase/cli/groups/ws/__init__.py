"""Workspace CLI group package API."""

from __future__ import annotations

__all__ = ["ws_group"]

from .group import ws_group
