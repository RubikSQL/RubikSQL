"""Config CLI command group."""

from __future__ import annotations

__all__ = ["config_group"]

from .group import config_group
