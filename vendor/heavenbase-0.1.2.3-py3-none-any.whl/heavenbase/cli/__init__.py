"""HeavenBase command-line interface toolkit and app factory."""

from __future__ import annotations

from heavenbase._lazy import _attach_lazy_exports

__all__ = [
    "ArgumentSpec",
    "CLIContext",
    "CLIOutput",
    "CLIRegistry",
    "CommandGroupSpec",
    "CommandSpec",
    "OptionSpec",
    "PackageCLIContext",
    "create_cli",
    "main",
    "raise_cli_error",
]

from .base import CLIContext
from .context import PackageCLIContext, raise_cli_error
from .output import CLIOutput
from .registry import CLIRegistry
from .spec import ArgumentSpec, CommandGroupSpec, CommandSpec, OptionSpec

_LAZY_EXPORTS = {
    "create_cli": (".app", "create_cli"),
    "main": (".app", "main"),
}

__getattr__, __dir__ = _attach_lazy_exports(__name__, globals(), _LAZY_EXPORTS, __all__)
