"""HeavenBase `hb` CLI app factory."""

from __future__ import annotations

__all__ = ["build_registry", "create_cli", "main"]

import sys

from heavenbase.utils import Any, CM_HVNB, Callable, Dict, Optional, Tuple, dget
from heavenbase.version import __version__

from .backends import build_argparse, build_click, build_typer, run_argparse, run_click, run_typer
from .base import CLIContext
from .context import PackageCLIContext, raise_cli_error
from .groups import config_group, llm_group, mcp_group, prompt_group, root_commands, ws_group
from .output import CLIOutput
from .registry import CLIRegistry

BackendFactory = Callable[[CLIRegistry, CLIContext], Any]
BackendRunner = Callable[[Any, Optional[list[str]]], Any]
BACKENDS: Dict[str, Tuple[BackendFactory, BackendRunner]] = {
    "typer": (build_typer, run_typer),
    "click": (build_click, run_click),
    "argparse": (build_argparse, run_argparse),
}


def build_registry() -> CLIRegistry:
    """Build the default HeavenBase CLI registry.

    Args:
        None.

    Returns:
        CLIRegistry: Registry populated with root commands and built-in groups.
    """
    registry = CLIRegistry()
    for command in root_commands():
        registry.add_root(command)
    registry.add_group(ws_group())
    registry.add_group(config_group())
    registry.add_group(llm_group())
    registry.add_group(mcp_group())
    registry.add_group(prompt_group())
    return registry


def _context(context: Optional[PackageCLIContext] = None) -> PackageCLIContext:
    result = context or PackageCLIContext(package="hb", version=__version__, cm=CM_HVNB, out=CLIOutput())
    if result.out is None:
        result.out = CLIOutput()
    return result


def _config_default(context: PackageCLIContext, key: str) -> Any:
    return dget(getattr(context.cm, "default", {}), key)


def _backend(context: PackageCLIContext, backend: Optional[str] = None) -> str:
    selected = backend if backend is not None else context.cm.get("heavenbase.cli.backend", default=_config_default(context, "heavenbase.cli.backend"))
    if not selected:
        raise ValueError("Missing CLI backend config: heavenbase.cli.backend")
    return str(selected).lower()


def create_cli(
    backend: Optional[str] = None,
    context: Optional[PackageCLIContext] = None,
    registry: Optional[CLIRegistry] = None,
) -> Any:
    """Create a CLI app for the selected backend.

    Args:
        backend (str | None): CLI backend name. When omitted, reads
            ``heavenbase.cli.backend`` from the runtime config manager.
        context (PackageCLIContext | None): Runtime context passed to command
            callbacks. A default ``hb`` context is created when omitted.
        registry (CLIRegistry | None): Optional caller-owned command registry.
            When omitted, builds the built-in ``hb`` registry.

    Returns:
        Any: Backend-specific application object compiled from ``registry``
            (Typer, Click, or argparse depending on ``backend``).

    Raises:
        ValueError: If ``backend`` is unsupported or missing from config.
    """
    ctx = _context(context)
    selected = _backend(ctx, backend)
    selected_registry = build_registry() if registry is None else registry
    if selected not in BACKENDS:
        raise ValueError(f"Unsupported CLI backend {selected!r}; expected one of {sorted(BACKENDS)}")
    return BACKENDS[selected][0](selected_registry, ctx)


def _strip_path_prefix(argv: list[str]) -> list[str]:
    """Remove ``path:`` prefix from args to work around Git Bash bugs
    with tokens starting with ``/``, ``%``, ``&``, etc."""
    prefix = "path:"
    return [a.removeprefix(prefix) if a.startswith(prefix) else a for a in argv]


def main(argv: Optional[list[str]] = None) -> Any:
    """Run the configured CLI entry point.

    Args:
        argv (list[str] | None): Arguments to parse instead of ``sys.argv[1:]``.

    Returns:
        Any: Return value from the selected backend runner, if any.

    Raises:
        SystemExit: Raised for normal CLI exits, including rendered errors.
    """
    argv = _strip_path_prefix(argv if argv is not None else sys.argv[1:])
    ctx = _context()
    try:
        selected = _backend(ctx)
        app = create_cli(selected, context=ctx)
        return BACKENDS[selected][1](app, argv)
    except SystemExit:
        raise
    except KeyboardInterrupt as error:
        raise_cli_error(ctx, error, code=130, msg="interrupted")
    except Exception as error:
        raise_cli_error(ctx, error)


if __name__ == "__main__":
    main()
