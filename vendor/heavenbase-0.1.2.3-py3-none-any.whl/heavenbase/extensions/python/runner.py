"""In-process Python execution for caller-authored analysis code."""

from __future__ import annotations

__all__ = ["PYTHON_RESULT_CHARS", "run_python_code"]

import ast
import contextlib
import io
import time
import traceback

from heavenbase.utils import Any, Dict, Optional, coerce_posint

# Results feed a model's context, so a large frame must not arrive whole. The
# cap is declared in the payload rather than applied quietly, because an
# unmarked cut is what makes a caller report a slice as a total.
PYTHON_RESULT_CHARS = 20000


class _BoundedText(io.TextIOBase):
    """Capture at most one character budget while counting everything written."""

    def __init__(self, limit: int) -> None:
        self.limit = limit
        self.chars = 0
        self._parts: list[str] = []
        self._kept = 0

    def write(self, text: str) -> int:
        """Capture the bounded prefix and report the complete write length."""
        if not isinstance(text, str):
            raise TypeError("captured stdout accepts text only")
        length = len(text)
        self.chars += length
        remaining = self.limit - self._kept
        if remaining > 0:
            part = text[:remaining]
            self._parts.append(part)
            self._kept += len(part)
        return length

    def getvalue(self) -> str:
        """Return the retained output prefix."""
        return "".join(self._parts)


def run_python_code(code: str, namespace: Dict[str, Any], *, result_chars: int = PYTHON_RESULT_CHARS) -> Dict[str, Any]:
    """Execute one Python program and return its output with its coverage.

    Statements run through :func:`exec`; a trailing expression is evaluated so
    the last line's value is the result, matching the REPL behaviour callers
    expect. Execution is in-process and unrestricted: the program can do
    anything the host process can.

    A `ResultFrame` result is rendered through the workspace payload builder, so
    a paginated frame still reports `total` and `truncated` instead of letting a
    page read as a whole. Printed output and rendered results are capped, and a
    cap that fired is stated in the payload.

    Args:
        code (str): Python source to execute.
        namespace (Dict[str, Any]): Globals the program runs against. Mutations
            persist in the mapping the caller supplied.
        result_chars (int): Maximum characters kept for `stdout` and for the
            rendered result. Defaults to :data:`PYTHON_RESULT_CHARS`.

    Returns:
        Dict[str, Any]: ``{"ok", "stdout", "result", "elapsed"}`` on success,
        plus ``"error"``/``"traceback"`` when the program raised, and
        ``"stdout_truncated"``/``"result_truncated"`` when a cap fired.

    Raises:
        SyntaxError: If ``code`` does not parse. Runtime failures are reported
            in the payload rather than raised, so a caller sees the program's
            own output alongside its error.
    """
    result_chars = coerce_posint(result_chars, "run_python result_chars")
    tree = ast.parse(code)
    tail = tree.body.pop() if tree.body and isinstance(tree.body[-1], ast.Expr) else None
    stdout = _BoundedText(result_chars)
    payload: Dict[str, Any] = {"ok": True}
    started = time.time()
    with contextlib.redirect_stdout(stdout):
        try:
            if tree.body:
                exec(compile(tree, "<python>", "exec"), namespace, namespace)  # noqa: S102 - caller-authored code is the feature
            value = eval(compile(ast.Expression(tail.value), "<python>", "eval"), namespace, namespace) if tail is not None else None
        except BaseException as error:  # a program's own failure is data for the caller, not an exception here
            payload.update({"ok": False, "error": f"{type(error).__name__}: {error}", "traceback": traceback.format_exc(limit=8)})
            value = None
    payload["elapsed"] = round(time.time() - started, 3)
    payload["stdout"] = stdout.getvalue()
    if stdout.chars > result_chars:
        payload["stdout_truncated"] = True
        payload["stdout_chars"] = stdout.chars
    if payload["ok"]:
        _set_bounded(payload, "result", _render_result(value), result_chars)
    return payload


def _render_result(value: Any) -> Optional[Any]:
    """Return one JSON-ready result, preserving a frame's coverage metadata."""
    if value is None:
        return None
    if hasattr(value, "rows") and hasattr(value, "col_names"):
        from heavenbase.toolkit.families.workspace.result import frame_dict

        return frame_dict(value)
    try:
        from heavenbase.utils.serialize import validate_json

        validate_json(value)
        return value
    except (TypeError, ValueError):
        return repr(value)


def _set_bounded(payload: Dict[str, Any], key: str, value: Any, limit: int) -> None:
    """Store one value, declaring the cut when it did not fit."""
    if not isinstance(value, str):
        rendered = value
        text = None if value is None else str(value)
    else:
        rendered = value
        text = value
    if text is not None and len(text) > limit:
        payload[key] = text[:limit]
        payload[f"{key}_truncated"] = True
        payload[f"{key}_chars"] = len(text)
        return
    payload[key] = rendered
