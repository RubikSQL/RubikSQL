"""Prepared globals for caller-authored analysis code."""

from __future__ import annotations

__all__ = ["python_namespace"]

from heavenbase.utils import Any, Dict


def python_namespace(workspace: Any) -> Dict[str, Any]:
    """Return the globals one Python program starts from.

    The workspace and its registered entity classes are preloaded, so a program
    reads and aggregates without first resolving names the caller would have to
    guess. Entities bind under their class name, which is what a schema
    description reports.

    Args:
        workspace (Any): Open workspace the program queries.

    Returns:
        Dict[str, Any]: Globals containing ``hb``, ``ws``, and one binding per
        registered entity class.
    """
    import heavenbase as hb

    namespace: Dict[str, Any] = {"hb": hb, "ws": workspace, "__name__": "__python__"}
    for entity_id in workspace.entities:
        entity = workspace.entities[entity_id]
        name = getattr(entity, "__name__", None)
        if name and name not in namespace:
            namespace[name] = entity
    return namespace
