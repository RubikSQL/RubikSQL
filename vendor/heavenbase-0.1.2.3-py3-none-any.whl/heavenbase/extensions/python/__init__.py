"""Optional in-process Python execution extension."""

from __future__ import annotations

__all__ = [
    "PYTHON_EXTENSION_ID",
    "PYTHON_RESULT_CHARS",
    "python_namespace",
    "render_python_guide",
    "run_python_code",
]

from heavenbase.extensions.ids import PYTHON_EXTENSION_ID

from .guide import render_python_guide
from .namespace import python_namespace
from .runner import PYTHON_RESULT_CHARS, run_python_code
