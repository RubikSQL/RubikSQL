"""One module per python MCP tool."""
