"""Workspace extension contracts, registry, and built-in bundles."""

from __future__ import annotations

from .base import Extension
from .ids import AGENT_EXTENSION_ID, CAPSULE_EXTENSION_ID, DATABASE_EXTENSION_ID, MEMORY_EXTENSION_ID, PROMPT_EXTENSION_ID, TOOLKIT_EXTENSION_ID

__all__ = [
    "Extension",
    "AGENT_EXTENSION_ID",
    "CAPSULE_EXTENSION_ID",
    "DATABASE_EXTENSION_ID",
    "MEMORY_EXTENSION_ID",
    "PROMPT_EXTENSION_ID",
    "TOOLKIT_EXTENSION_ID",
]
