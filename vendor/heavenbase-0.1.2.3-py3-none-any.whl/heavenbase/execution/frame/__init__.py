"""Neutral result-frame execution values."""

from __future__ import annotations

__all__ = ["ResultFrame", "difference", "intersect", "union"]

from .merge import difference, intersect, union
from .result import ResultFrame
