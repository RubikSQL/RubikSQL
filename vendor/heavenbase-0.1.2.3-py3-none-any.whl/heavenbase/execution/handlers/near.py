"""Shared portable vector-near handler compiler."""

from __future__ import annotations

__all__ = ["near_handler"]

from math import isfinite

from heavenbase.types import cosine_score, euclidean_score, inner_product_score
from heavenbase.utils import Any, Dict

from ..contracts import HandlerContext, QueryFragment

_SCORERS = {
    "cosine": cosine_score,
    "l2": euclidean_score,
    "euclidean": euclidean_score,
    "ip": inner_product_score,
    "inner": inner_product_score,
    "inner_product": inner_product_score,
}


class _PreparedVectors:
    """Own immutable binary64 coordinates and reusable magnitudes for one generation."""

    def __init__(self, rows: list[dict], field: str) -> None:
        import numpy as np

        present = [row for row in rows if row.get(field) is not None]
        self.positions = {row["object_id"]: index for index, row in enumerate(present)}
        self.values = np.asarray([row[field] for row in present], dtype=np.float64) if present else np.empty((0, 0), dtype=np.float64)
        if self.values.ndim != 2 or not np.isfinite(self.values).all():
            raise ValueError("Exact near requires finite, consistently dimensioned vectors")
        with np.errstate(over="ignore", invalid="ignore"):
            self.norms = np.sqrt(np.sum(self.values * self.values, axis=1))
        self.values.flags.writeable = False
        self.norms.flags.writeable = False


def _batch_scores(
    rows: list[dict], field: str, query: list[float], metric: str, scalar: Any, *, prepared: _PreparedVectors | None = None
) -> list[float | None]:
    """Score a bounded portable batch in binary64, using NumPy when installed."""
    try:
        import numpy as np
    except ImportError:
        return [scalar(row) for row in rows]
    present = [index for index, row in enumerate(rows) if row.get(field) is not None]
    scores: list[float | None] = [None] * len(rows)
    if not present:
        return scores
    positions = [prepared.positions[rows[index]["object_id"]] for index in present] if prepared is not None else None
    vectors = prepared.values[positions] if prepared is not None else np.asarray([rows[index][field] for index in present], dtype=np.float64)
    q = np.asarray(query, dtype=np.float64)
    if vectors.ndim != 2 or vectors.shape[1] != len(q):
        raise ValueError("Exact near requires matching vector dimensions")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        if metric == "cosine":
            dot = np.sum(vectors * q, axis=1)
            stored_norms = prepared.norms[positions] if prepared is not None else np.sqrt(np.sum(vectors * vectors, axis=1))
            norms = stored_norms * np.sqrt(np.sum(q * q))
            values = np.divide(dot, norms, out=np.zeros(len(present)), where=norms != 0)
        elif metric in ("l2", "euclidean"):
            delta = vectors - q
            values = -np.sqrt(np.sum(delta * delta, axis=1))
        else:
            values = np.sum(vectors * q, axis=1)
    # Overflow or invalid coordinates must not turn into a plausible finite score.
    if not np.isfinite(vectors).all() or not np.isfinite(values).all():
        raise ValueError("Exact near produced a non-finite score")
    if metric == "cosine" and not np.isfinite(norms).all():
        raise ValueError("Exact near produced a non-finite magnitude")
    for index, value in zip(present, values):
        scores[index] = float(value)
    return scores


def near_handler(field_schema: Any, value: Any, ctx: HandlerContext) -> QueryFragment:
    """Compile a vector-near request to the portable scan fallback.

    Args:
        field_schema (Any): Routed vector field schema.
        value (Any): Query vector validated against the field dtype.
        ctx (HandlerContext): Selected backend and strategy context.

    Returns:
        QueryFragment: Python scan fragment scoring rows with the configured metric.
    """
    query = field_schema.dtype.validate(value)
    metric = str(ctx.metric).lower()
    if metric not in _SCORERS:
        raise ValueError(f"Portable near does not support metric {ctx.metric!r}")
    scorer = _SCORERS[metric]
    if ctx.exact and not all(isfinite(item) for item in query):
        raise ValueError("Exact near requires a finite query vector")

    def _payload(row: dict) -> float | None:
        vec = row.get(field_schema.name)
        if vec is None:
            return None if ctx.exact else 0.0
        score = scorer(vec, query)
        if ctx.exact and not isfinite(score):
            raise ValueError(f"Exact near produced a non-finite score for {row.get('object_id')!r}")
        return score

    reason = ctx.fallback_reason("near", type(field_schema.dtype).identifier)
    notes: Dict[str, Any] = {"mode": "py_scan", "top_k": ctx.top_k}
    if ctx.exact:
        notes["exact"] = True
        notes["batch_payload"] = lambda rows: _batch_scores(rows, field_schema.name, query, metric, _payload)
    if reason:
        notes["fallback_reason"] = reason
    return QueryFragment(ctx.backend, "near", field_schema.name, _payload, returns=["score"], notes=notes)
