"""Durable dashboard-assistant session logging.

The recorder enforces one doctrine: **model-visible means logged**. Every
provider-bound request made on behalf of an assistant turn is persisted as an
immutable ``agent-trace`` event row BEFORE provider I/O (via the LLM trace
seam), followed by its terminal ``response``/``error`` row and one ``turn``
row when the turn completes. A ``request`` row without a terminal sibling is
itself the durable record of an interrupted call — no in-memory bookkeeping
is involved. ``agent-session``/``agent-message`` rows are maintained as a
readable, resumable projection and can always be rebuilt from the trace rows.

Failure doctrine, mirroring the dashboard assistant's own: configuration is
validated loudly (:meth:`AssistSessionLog.validate` — non-durable backends and
the ``share_credentials`` combination are refused, at boot and again per
turn), while per-turn recording is fail-soft — a recorder failure warns once
per failure class, marks the turn's ``capture`` state (surfaced to clients as
``capture_warning``), and never fails the user's question.

Retry semantics: a client retry reuses its ``turn_id``. A replay of a
completed turn returns its stored answer without provider I/O. A retry after
an interrupted or errored attempt records its provider calls under a fresh
attempt namespace — including when a hard interruption left no ``turn`` row —
and its successful ``turn`` row supersedes the provisional interrupted/errored
one, which is the single sanctioned overwrite of a trace row.
"""

from __future__ import annotations

__all__ = ["AssistSessionLog", "AssistTurnLog"]

import threading
import warnings
from time import time

from heavenbase.llm.trace import LLMTraceEvent, TraceCallback, forward_trace, trace_state
from heavenbase.utils import Any, Dict, List, Mapping, Optional, hash_id

_SESSION_SOURCE = "dashboard-assist"
_CONFIG_ROOT = "heavenbase.dashboard.assistant"
# Entity Identifier fields accept any non-empty text up to this many chars.
_IDENTIFIER_MAX_CHARS = 63
_WARNED_FAILURES: set = set()


def _warn_once(context: str, error: Exception) -> None:
    """Warn once per (context, exception type) that recording degraded."""
    marker = f"{context}:{type(error).__name__}"
    if marker in _WARNED_FAILURES:
        return
    _WARNED_FAILURES.add(marker)
    try:
        warnings.warn(f"assistant session log {context} failed ({type(error).__name__}: {error}); the turn continues unrecorded", UserWarning, stacklevel=3)
    except Exception:
        pass  # warnings-as-errors must not let a diagnostic fail the turn


def _safe_identifier(value: str, namespace: str) -> str:
    """Return ``value`` when storage-safe, else its deterministic hash.

    The HTTP contract accepts ids up to 128 characters while entity
    ``Identifier`` fields cap at 63, so oversize ids map to a stable hash —
    the same client id always maps to the same stored id, preserving retry
    idempotency.
    """
    return value if len(value) <= _IDENTIFIER_MAX_CHARS else hash_id(namespace, value)


def _is_duplicate_write(error: ValueError) -> bool:
    """Return whether ``error`` is the writer's existing-row refusal.

    ``upsert(overwrite=False)`` raises ``ValueError`` both for duplicates and
    for field validation; only the former is an idempotent replay. Anything
    else is a real recording failure and must mark the turn's capture state.
    """
    return "already exists" in str(error)


class AssistSessionLog:
    """Owner of the assistant session-log workspace and its write discipline.

    One instance serves one :class:`~heavenbase.api.service.DashboardAPI`.
    The log workspace is opened lazily on the first enabled turn; its
    construction contract (name and backends) comes from
    ``heavenbase.dashboard.assistant.session_log_*`` and is validated by
    :meth:`validate` before anything is written.
    """

    def __init__(self, cm: Any, context: Any = None) -> None:
        """Bind the recorder to one config manager and context.

        Args:
            cm (Any): Config manager resolving the assistant block.
            context (Any): Context owning the log workspace. Defaults to the
                process context.
        """
        self.cm = cm
        self.context = context
        self._ws: Any = None
        self._lock = threading.RLock()
        # Conversations with a turn in flight; retention never evicts them.
        self._active: Dict[str, int] = {}

    def _entity(self, name: str) -> Any:
        """Resolve one agent entity class through the workspace's registry.

        The log workspace registers the registry's artifact-compiled classes;
        a directly imported source class is a different type with a different
        structure hash, so resolution must go through the same registry.
        """
        from heavenbase.entity.registry import load_entity_type

        return load_entity_type(name, resolver=self.workspace().module_resolver)

    # ------------------------------------------------------------- config

    @classmethod
    def enabled(cls, cm: Any) -> bool:
        """Return whether session logging is switched on (strict literal).

        A truthy non-boolean (``"true"``, ``1``) warns once instead of
        silently reading as off — an operator who believes logging is on must
        not discover otherwise from an empty log.
        """
        value = cm.get(f"{_CONFIG_ROOT}.session_log", default=False)
        if value is True:
            return True
        if value not in (False, None):
            _warn_once("config", ValueError(f"session_log must be the literal boolean true, got {value!r}; logging stays OFF"))
        return False

    @classmethod
    def validate(cls, cm: Any) -> None:
        """Fail loudly on a configuration that cannot keep the log's promise.

        A disabled log validates trivially. An enabled one must declare a
        durable backend (preset fallback resolves to in-memory stores) and
        must not be combined with ``share_credentials``, which would persist
        raw credentials at rest, unless ``session_log_allow_credentials`` is
        the literal ``true``. Runs at server boot and again per turn, so a
        post-boot config flip stops recording instead of persisting secrets.

        Args:
            cm (Any): Config manager resolving the assistant block.

        Raises:
            ValueError: If the backend declaration is missing or non-durable,
                or the credential-sharing combination is refused.
        """
        if not cls.enabled(cm):
            return
        share = cm.get(f"{_CONFIG_ROOT}.share_credentials", default=False) is True
        allow = cm.get(f"{_CONFIG_ROOT}.session_log_allow_credentials", default=False) is True
        if share and not allow:
            raise ValueError(
                "session_log with share_credentials would persist raw credentials at rest; "
                "disable one of them, or set heavenbase.dashboard.assistant.session_log_allow_credentials: true to accept that explicitly"
            )
        cls._durable_backends(cm)
        cls._max_sessions(cm)

    @classmethod
    def _durable_backends(cls, cm: Any) -> Dict[str, Any]:
        """Return the declared log backends, refusing known non-durable forms.

        This is a declaration check, not a construction probe: it rejects the
        in-memory backend types and the sqlite in-memory database spellings
        the codebase ships. A custom backend that discards data anyway is the
        operator's own declaration.
        """
        key = f"{_CONFIG_ROOT}.session_log_backend"
        backends = cm.get(key, default=None)
        if not hasattr(backends, "items") or not dict(backends):
            raise ValueError(f"{key} must declare the log workspace backends explicitly; preset fallback may resolve to in-memory stores")
        resolved = {str(name): dict(entry) if hasattr(entry, "items") else entry for name, entry in dict(backends).items()}
        for name, entry in resolved.items():
            if not hasattr(entry, "items"):
                raise ValueError(f"{key}.{name} must be a backend mapping")
            if str(entry.get("type") or "").strip() in {"inmem", "memory"}:
                raise ValueError(f"{key}.{name} is an in-memory backend; a session log that vanishes with the process is not a log")
            if str(entry.get("database") or "").strip() == ":memory:" or entry.get("in_memory"):
                raise ValueError(f"{key}.{name} points at an in-memory database; a session log that vanishes with the process is not a log")
        return resolved

    def _workspace_id(self) -> str:
        return str(self.cm.get(f"{_CONFIG_ROOT}.session_log_workspace", default="assistant-log") or "assistant-log")

    @classmethod
    def _max_sessions(cls, cm: Any) -> int:
        value = cm.get(f"{_CONFIG_ROOT}.session_log_max_sessions", default=256)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("heavenbase.dashboard.assistant.session_log_max_sessions must be a non-negative integer")
        return value

    # ---------------------------------------------------------- workspace

    def workspace(self) -> Any:
        """Return the open log workspace, constructing it on first use.

        Returns:
            Any: Workspace with the ``agent`` extension enabled.

        Raises:
            ValueError: If validation refuses the configuration, or the
                workspace name is already registered under a different
                construction contract.
        """
        with self._lock:
            if self._ws is not None:
                return self._ws
            self.validate(self.cm)
            from heavenbase.workspace import HeavenBase

            ws_id = self._workspace_id()
            try:
                ws = HeavenBase(ws_id, context=self.context, backends=self._durable_backends(self.cm))
            except FileExistsError as error:
                raise ValueError(
                    f"workspace {ws_id!r} is already registered with a different construction contract; "
                    "point session_log_workspace at a fresh name or restore the original session_log_backend"
                ) from error
            ws.enable_extension("agent")
            self._ws = ws
            return ws

    # -------------------------------------------------------------- turns

    def begin_turn(
        self,
        question: str,
        *,
        conversation_id: Optional[str] = None,
        turn_id: Optional[str] = None,
        ws_id: str = "",
    ) -> "Optional[AssistTurnLog]":
        """Open one turn's recorder, or ``None`` when logging is off.

        Serve-time refusals (an unopenable log workspace, a configuration
        turned unsafe after boot) degrade to a dead recorder whose
        ``capture`` names the reason, so the reply still carries a
        ``capture_warning`` instead of silently claiming nothing. The loud
        path for the same errors is :meth:`validate` at server boot.

        Args:
            question (str): The user question opening the turn.
            conversation_id (str | None): Client conversation identity (up to
                the protocol's 128 chars; out-of-shape ids map to a stable
                hash). Absent, each turn logs as its own conversation.
                Defaults to ``None``.
            turn_id (str | None): Client turn identity; retries that reuse it
                replay completed turns as no-ops and record retried attempts
                under a fresh attempt namespace. Defaults to ``None``.
            ws_id (str): Workspace the turn serves. Defaults to ``""``.

        Returns:
            Optional[AssistTurnLog]: Turn recorder (possibly dead), or
            ``None`` when logging is off.
        """
        if not self.enabled(self.cm):
            return None
        try:
            self.validate(self.cm)  # per-turn re-check: a post-boot unsafe flip stops recording
            ws = self.workspace()
        except Exception as error:
            _warn_once("workspace", error)
            return AssistTurnLog.dead(self, f"workspace:{type(error).__name__}")
        conversation = _safe_identifier(str(conversation_id or "") or hash_id("assist-conv", ws_id, question, time()), "assist-conv")
        turn = _safe_identifier(str(turn_id or "") or hash_id("assist-turn", conversation, time()), "assist-turn")
        log = AssistTurnLog(self, ws, conversation, turn, ws_id=ws_id, question=question)
        log._admit()
        return log

    # -------------------------------------------------------- projection

    def _open_session(self, ws: Any, conversation_id: str, question: str) -> Any:
        """Load the conversation's projection session, creating it on first use."""
        Session = self._entity("agent-session")
        ref = hash_id("assist-log", conversation_id)
        try:
            return Session.load(ref, ws=ws)
        except KeyError:
            self._evict_for_admission(ws)
            session = Session(object_id=ref, title=question.strip()[:80], agent_ref=_SESSION_SOURCE, ws=ws)
            session._set(state={"source": _SESSION_SOURCE, "conversation_id": conversation_id, "started_at": int(time() * 1000)})
            ws.upsert(Session, session.to_dict())
            return session

    def rebuild_session(self, conversation_id: str) -> Any:
        """Rebuild one conversation's Session/Message projection from trace rows.

        The trace rows are the authority; the projection is derived state. A
        lost update on the aggregate row, a crash between writes, or a
        skipped append therefore never damages the record — this method
        recomputes the readable transcript from the ``turn`` rows (ordered by
        their ``closed_at`` stamp, errored and interrupted turns excluded)
        and replaces the projection wholesale, re-aggregating usage from the
        turn payloads.

        Args:
            conversation_id (str): Logged conversation identity (as stored;
                a client id that was hash-normalized rebuilds under its
                stored form).

        Returns:
            Any: The rebuilt ``Session``.

        Raises:
            ValueError: If the conversation has no trace rows at all.
        """
        with self._lock:
            ws = self.workspace()
            Trace = self._entity("agent-trace")
            rows = [row for row in ws.rows(Trace) if row.get("conversation_id") == conversation_id]
            if not rows:
                raise ValueError(f"conversation {conversation_id!r} has no trace rows to rebuild from")
            turns = [row for row in rows if row.get("kind") == "turn"]
            turns.sort(key=lambda row: int((row.get("payload") or {}).get("closed_at") or 0))
            transcript: List[Dict[str, Any]] = []
            usage: Dict[str, Any] = {}
            last_turn = ""
            for row in turns:
                payload = row.get("payload") or {}
                if payload.get("error") or not str(payload.get("text") or "").strip():
                    continue  # the projection is a clean transcript; failures stay in the trace rows
                transcript.append({"role": "user", "content": str(payload.get("question") or "")})
                transcript.append({"role": "assistant", "content": str(payload.get("text") or "")})
                for key, value in dict(payload.get("usage") or {}).items():
                    usage[key] = usage.get(key, 0) + value if isinstance(value, (int, float)) and not isinstance(value, bool) else value
                last_turn = str(row.get("turn_id") or "")
            question = transcript[0]["content"] if transcript else ""
            session = self._open_session(ws, conversation_id, question)
            session.set_messages(transcript, source=_SESSION_SOURCE, usage=usage, state={"last_turn_id": last_turn}, ws=ws)
            return session

    def _evict_for_admission(self, ws: Any) -> None:
        """Apply the whole-session retention cap before admitting a new one.

        This is the recorder's single sanctioned bulk deletion: the oldest
        sessions (by their recorded ``state.started_at``) are removed
        together with their message and trace rows, plus orphaned trace rows
        whose projection session never materialized. Conversations with a
        turn in flight are never evicted. Runs only at conversation
        admission, under the recorder lock.
        """
        cap = self._max_sessions(self.cm)
        if not cap:
            return
        Session, Message, Trace = self._entity("agent-session"), self._entity("agent-message"), self._entity("agent-trace")
        traces_by_conversation: Dict[str, List[Any]] = {}
        for trace_row in ws.rows(Trace):  # one pass, grouped, instead of a rescan per victim
            traces_by_conversation.setdefault(str(trace_row.get("conversation_id") or ""), []).append(trace_row.get("object_id"))
        rows = [row for row in ws.rows(Session) if (row.get("state") or {}).get("source") == _SESSION_SOURCE]
        owned = {str((row.get("state") or {}).get("conversation_id") or "") for row in rows}
        targets: List[tuple] = []
        for conversation, trace_ids in traces_by_conversation.items():
            if conversation and conversation not in owned and conversation not in self._active:
                targets.extend((Trace, trace_id) for trace_id in trace_ids)  # orphans no session row owns
        rows = [row for row in rows if str((row.get("state") or {}).get("conversation_id") or "") not in self._active]
        overflow = len(rows) - (cap - 1)
        if overflow > 0:
            rows.sort(key=lambda row: int((row.get("state") or {}).get("started_at") or 0))
            for row in rows[:overflow]:
                conversation = str((row.get("state") or {}).get("conversation_id") or "")
                targets.append((Session, row.get("object_id")))
                targets.extend((Message, message_id) for message_id in row.get("message_ids") or [])
                targets.extend((Trace, trace_id) for trace_id in traces_by_conversation.get(conversation, []))
        if targets:
            ws.delete_many(targets)


class AssistTurnLog:
    """Recorder for one assistant turn: trace events plus the projection."""

    def __init__(self, owner: AssistSessionLog, ws: Any, conversation_id: str, turn_id: str, *, ws_id: str, question: str) -> None:
        self._owner = owner
        self._ws = ws
        self.conversation_id = conversation_id
        self.turn_id = turn_id
        self.ws_id = ws_id
        self.question = question
        self._state = trace_state(self._persist_event)
        self._failures: List[str] = []
        self._closed = False
        self._dead_reason = ""
        self._attempt = 1
        self._replay_payload: Optional[Dict[str, Any]] = None

    @classmethod
    def dead(cls, owner: AssistSessionLog, reason: str) -> "AssistTurnLog":
        """Return a recorder that records nothing but confesses why.

        Its ``capture`` names the failure, so the reply still carries a
        ``capture_warning`` when the log workspace itself is unavailable.
        """
        log = cls(owner, None, "", "", ws_id="", question="")
        log._dead_reason = reason
        log._failures.append(reason)
        return log

    def llm_trace(self, call: Optional[str] = None) -> TraceCallback:
        """Return the trace callback for one LLM call of this turn.

        Args:
            call (str | None): Override tag for every event of that call
                (e.g. ``"replay_compaction"``); ``None`` keeps the LLM's own
                ``round``/``turn_compaction`` tags. All calls share this
                turn's monotonic sequence.

        Returns:
            TraceCallback: Callback to pass as ``LLM.chat(..., trace=...)``.
        """
        return forward_trace(self._state, call)

    def _admit(self) -> None:
        """Register the turn: attempt detection, active pin, projection session."""
        with self._owner._lock:
            existing = None
            rows: List[Any] = []
            try:
                Trace = self._owner._entity("agent-trace")
                existing = self._ws.get(Trace.event_id(self.conversation_id, self.turn_id, 0, "turn"), entity=Trace)
                rows = [row for row in self._ws.rows(Trace) if row.get("conversation_id") == self.conversation_id]
            except Exception as error:
                _warn_once("session", error)
                self._failures.append(f"session:{type(error).__name__}")

            if existing is not None:
                payload = dict(existing.get("payload") or {})
                if not payload.get("error"):
                    if str(payload.get("question") or "") != self.question or str(existing.get("ws_id") or "") != self.ws_id:
                        raise ValueError(f"assistant turn {self.turn_id!r} is already completed for a different question or workspace")
                    self._attempt = int(payload.get("attempt") or 1)
                    self._replay_payload = payload
                    self._closed = True
                    return

            attempts = set()
            prefix = f"{self.turn_id}-a"
            for row in rows:
                row_turn = str(row.get("turn_id") or "")
                if row_turn == self.turn_id:
                    attempt = int((row.get("payload") or {}).get("attempt") or 1) if row.get("kind") == "turn" else 1
                    attempts.add(attempt)
                elif row_turn.startswith(prefix) and row_turn[len(prefix) :].isdigit():
                    attempts.add(int(row_turn[len(prefix) :]))
            self._attempt = max(attempts) + 1 if attempts else 1
            self._owner._active[self.conversation_id] = self._owner._active.get(self.conversation_id, 0) + 1
            try:
                self._owner._open_session(self._ws, self.conversation_id, self.question)
            except Exception as error:
                _warn_once("session", error)
                self._failures.append(f"session:{type(error).__name__}")

    def replay(self) -> Optional[Dict[str, Any]]:
        """Return the completed turn as an assistant response without provider I/O.

        Args:
            None.

        Returns:
            Dict[str, Any] | None: Dashboard assistant response reconstructed
            from the completed turn row, or ``None`` when this turn still needs
            execution. Trace-only details such as prior reasoning and evidence
            frames are deliberately not projected into the replay response.
        """
        if self._replay_payload is None:
            return None
        payload = self._replay_payload
        reply = {
            "text": str(payload.get("text") or ""),
            "think": "",
            "served_model": str(payload.get("served_model") or ""),
            "frames": [],
            "sql_frames": [],
            "events": [],
            "elapsed": float(payload.get("elapsed") or 0.0),
            "truncated": bool(payload.get("truncated")),
        }
        capture = str(payload.get("capture") or "complete")
        if capture != "complete":
            reply["capture_warning"] = capture
        return reply

    def _event_turn_key(self) -> str:
        """Return the attempt-namespaced turn key for request/terminal rows."""
        return self.turn_id if self._attempt == 1 else f"{self.turn_id}-a{self._attempt}"

    def _persist_event(self, event: LLMTraceEvent) -> None:
        """Write one immutable event row; a replayed write is a no-op."""
        if self._dead_reason:
            return
        try:
            Trace = self._owner._entity("agent-trace")
            row = Trace.event(self.conversation_id, self._event_turn_key(), event.seq, event.kind, call=event.call, ws_id=self.ws_id, payload=event.payload)
            self._ws.upsert(Trace, row, overwrite=False)
        except ValueError as error:
            if _is_duplicate_write(error):
                return  # the same event coordinates were already recorded (idempotent replay)
            _warn_once("event", error)
            self._failures.append(f"event:{type(error).__name__}")
        except Exception as error:
            _warn_once("event", error)
            self._failures.append(f"event:{type(error).__name__}")

    @property
    def capture(self) -> str:
        """Return ``"complete"`` or ``"incomplete:<reasons>"`` for this turn."""
        return "complete" if not self._failures else "incomplete:" + ",".join(sorted(set(self._failures)))

    def close(
        self,
        *,
        text: str = "",
        served_model: str = "",
        elapsed: float = 0.0,
        truncated: bool = False,
        usage: Optional[Mapping[str, Any]] = None,
        error: str = "",
    ) -> None:
        """Seal the turn: write its ``turn`` row and update the projection.

        Never raises. A successful close supersedes a provisional
        interrupted/errored turn row left by an earlier attempt — the one
        sanctioned overwrite — and the projection append is deduplicated by
        the session's ``last_turn_id``, so crash-window retries repair the
        transcript instead of doubling it.

        Args:
            text (str): Final answer text. Defaults to ``""``.
            served_model (str): Provider-reported model. Defaults to ``""``.
            elapsed (float): Turn latency in seconds. Defaults to ``0.0``.
            truncated (bool): Whether the tool budget cut the answer short.
                Defaults to ``False``.
            usage (Mapping[str, Any] | None): Merged provider usage. Defaults
                to ``None``.
            error (str): Terminal failure description when the turn errored.
                Defaults to ``""``.
        """
        if self._closed or self._dead_reason:
            return
        self._closed = True
        try:
            self._close_guarded(text=text, served_model=served_model, elapsed=elapsed, truncated=truncated, usage=usage, error=error)
        except Exception as failure:
            _warn_once("turn", failure)
        finally:
            with self._owner._lock:
                remaining = self._owner._active.get(self.conversation_id, 1) - 1
                if remaining > 0:
                    self._owner._active[self.conversation_id] = remaining
                else:
                    self._owner._active.pop(self.conversation_id, None)

    def _close_guarded(self, *, text: str, served_model: str, elapsed: float, truncated: bool, usage: Optional[Mapping[str, Any]], error: str) -> None:
        """Write the turn row (with supersede semantics) and the projection."""
        Trace = self._owner._entity("agent-trace")
        payload = {
            "question": self.question,
            "text": text,
            "served_model": served_model,
            "elapsed": elapsed,
            "truncated": bool(truncated),
            "events": self._state["seq"],
            "capture": self.capture,
            "attempt": self._attempt,
            "closed_at": int(time() * 1000),  # cross-turn ordering key for projection rebuilds
        }
        if usage:
            payload["usage"] = dict(usage)
        if error:
            payload["error"] = error
        row = Trace.event(self.conversation_id, self.turn_id, 0, "turn", ws_id=self.ws_id, payload=payload)
        try:
            self._ws.upsert(Trace, row, overwrite=False)
        except ValueError as write_error:
            if not _is_duplicate_write(write_error):
                _warn_once("turn", write_error)
                self._failures.append(f"turn:{type(write_error).__name__}")
                return
            existing = self._ws.get(Trace.event_id(self.conversation_id, self.turn_id, 0, "turn"), entity=Trace)
            provisional = bool(((existing or {}).get("payload") or {}).get("error"))
            if not provisional or error:
                return  # completed-turn replay, or a failed retry of a failed turn: first record stands
            # A successful retry supersedes the provisional interrupted row —
            # the answer the user actually received is the turn's record.
            payload["superseded"] = ((existing or {}).get("payload") or {}).get("error")
            self._ws.upsert(Trace, Trace.event(self.conversation_id, self.turn_id, 0, "turn", ws_id=self.ws_id, payload=payload))
        if error or not text.strip():
            return  # errored turns live in trace rows only; the projection stays a clean transcript
        with self._owner._lock:
            try:
                session = self._owner._open_session(self._ws, self.conversation_id, self.question)
                if str((session.state or {}).get("last_turn_id") or "") == self.turn_id:
                    return  # this turn already reached the transcript (replay or crash-window retry)
                session.append_messages(
                    [{"role": "user", "content": self.question}, {"role": "assistant", "content": text}],
                    source=_SESSION_SOURCE,
                    usage=usage,
                    state={"last_turn_id": self.turn_id, "ws_id": self.ws_id},
                    ws=self._ws,
                )
            except Exception as failure:
                _warn_once("projection", failure)
