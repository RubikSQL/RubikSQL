"""Dependency-light public interop facade."""

__all__ = [
    "InteropIssue",
    "InteropReport",
    "InteropSet",
    "InteropTypeInferer",
    "from_daft",
    "from_numpy",
    "from_pandas",
    "from_pydantic",
    "from_pyarrow",
    "from_sql_result",
    "registered_interop_type_inferers",
    "register_interop_type_inferer",
    "row_from_any",
]

from ._loaders import from_daft, from_numpy, from_pandas, from_pydantic, from_pyarrow, from_sql_result
from .base import InteropIssue, InteropReport, InteropSet
from .mapping import InteropTypeInferer, registered_interop_type_inferers, register_interop_type_inferer
from .rows import row_from_any
