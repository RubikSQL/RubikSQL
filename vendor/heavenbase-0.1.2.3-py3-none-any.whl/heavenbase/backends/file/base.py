"""Folder-backed backend base."""

from __future__ import annotations

__all__ = [
    "FileBackend",
]

from urllib.parse import quote

from heavenbase.utils import Any, Dict, Iterable, List, Optional, Sequence
from heavenbase.utils.files import delete_dir, delete_file, exists_path, file_uri_to_path, list_files, replace_file, temp_file, touch_dir
from heavenbase.utils.files import pj
from heavenbase.utils.serialize import dump_json, load_json, load_pkl, save_pkl

from ...modules import ModuleResolver
from ...utils.ids import check_entity_id
from ..base import backend_locked
from heavenbase.execution.contracts import RowOp
from ..inmem import InMemBackend


class FileBackend(InMemBackend):
    """Folder-backed row store that persists each row as one record file."""

    identifier = "file"
    aliases = ()
    default_path_key = "heavenbase.backend_defaults.file.path"
    default_path = "file://%/file"

    @classmethod
    def from_config(
        cls,
        name: str,
        data: dict[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "FileBackend":
        """Build the generic file backend from a config mapping.

        Args:
            name: Workspace backend instance name.
            data: Backend config mapping. Supports ``path``, ``fmt``, and optional ``ws_id``.
            resolver: Context-owned module authority.
            config: Config authority used for backend defaults and runtime policy.

        Returns:
            FileBackend: Configured folder-backed backend instance.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        return cls(name, cfg.pop("path", None), cfg.pop("fmt", "json"), ws_id=ws_id, resolver=resolver, config=config)

    def __init__(
        self,
        name: str = "file",
        path: str | None = None,
        fmt: str = "json",
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> None:
        """Create a folder-backed backend.

        Args:
            name: Workspace backend instance name.
            path: Base folder for persisted row files. When omitted, uses the configured
                file backend default path.
            fmt: Record format. Supported values are ``"json"``, ``"pkl"``, and ``"pickle"``.
            ws_id: Optional workspace namespace. When set, files live under a workspace subfolder.
            resolver: Context-owned module authority.
            config: Config authority used for backend defaults and runtime policy.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(name, ws_id=ws_id, resolver=resolver, config=config)
        configured_path = self._construction_config_get(type(self).default_path_key, default=type(self).default_path)
        self._base_path = file_uri_to_path(path or configured_path, home=self.config.root)
        self.path = touch_dir(pj(self._base_path, self.ws_id) if self.ws_id else self._base_path)
        self.fmt = fmt
        self._loaded_entities: Dict[str, set] = {}

    def _construction_tag_claims(self) -> dict[str, Any]:
        """Return format-derived tags for the configurable generic File Backend."""
        claims = super()._construction_tag_claims()
        if self.type == "file":
            claims["binary-storage"] = "base64" if self.fmt == "json" else "bytes"
        return claims

    def _refresh_workspace(self) -> None:
        self._refresh_path()

    def _refresh_path(self) -> None:
        """Recompute self.path when ws_id is assigned after construction."""
        with self._lock:
            self.path = touch_dir(pj(self._base_path, self.ws_id) if self.ws_id else self._base_path)
            self.data.clear()
            self._loaded_entities.clear()

    @backend_locked
    def drop(self) -> None:
        """Delete the current workspace directory for this file backend.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        delete_dir(self.path)
        self.data.pop(self.ws_id, None)
        self._loaded_entities.pop(self.ws_id, None)

    @backend_locked
    def refresh(self, entity_id: str | None = None) -> None:
        """Clear cached file rows for this backend.

        Args:
            entity_id: Optional logical entity identifier to clear. When omitted, all cached rows for the current workspace are cleared.

        Returns:
            None: This function does not return a value.

        Warnings:
            This only clears in-memory snapshots; it does not delete persisted files. Normal row lookups read the current
            record file, while ``refresh`` is useful after manual file edits or before inspecting backend ``data`` directly.

        Examples:
            ``backend.refresh("note")`` clears cached rows for one entity. ``backend.refresh()`` clears the whole workspace cache.
        """
        ns = self.ws_id
        if entity_id is None:
            self.data.pop(ns, None)
            self._loaded_entities.pop(ns, None)
            return
        entity_id = check_entity_id(entity_id)
        self.data.get(ns, {}).pop(entity_id, None)
        self._loaded_entities.get(ns, set()).discard(entity_id)

    @property
    def suffix(self) -> str:
        """Return the file suffix used by this backend format.

        Returns:
            str: ``".json"`` for JSON records or ``".pkl"`` for pickle records.

        Raises:
            ValueError: If ``fmt`` is not a supported record format.
        """
        if self.fmt == "json":
            return ".json"
        if self.fmt in ("pkl", "pickle"):
            return ".pkl"
        raise ValueError(f"Unsupported file backend format {self.fmt!r}")

    def _entity_dir(self, entity_id: str) -> str:
        return pj(self.path, self._physical_name(entity_id))

    def _record_path(self, entity_id: str, row_id: str) -> str:
        return pj(self._entity_dir(entity_id), f"{quote(row_id, safe='')}{self.suffix}")

    def _load_entity(self, entity_id: str) -> Dict[Any, Dict[str, Any]]:
        rows: Dict[Any, Dict[str, Any]] = {}
        entity_dir = self._entity_dir(entity_id)
        if not exists_path(entity_dir):
            return rows
        for record_path in list_files(entity_dir, ext=self.suffix[1:], abs=True):
            row = self._load_record(record_path)
            if row is None:
                continue
            row_id = row.get("object_id")
            if row_id is not None:
                rows[row_id] = row
        return rows

    def _ensure_loaded(self, entity_id: str) -> None:
        entity_id = check_entity_id(entity_id)
        loaded = self._loaded_entities.setdefault(self.ws_id, set())
        if entity_id in loaded:
            return
        self.data.setdefault(self.ws_id, {})[entity_id] = self._load_entity(entity_id)
        loaded.add(entity_id)

    def _load_record(self, path: str) -> Dict[str, Any] | None:
        if self.fmt == "json":
            return load_json(path) or None
        return load_pkl(path) or None

    def _save_record(self, entity_id: str, row_id: str, values: Dict[str, Any]) -> None:
        entity_dir = self._entity_dir(entity_id)
        touch_dir(entity_dir)
        path = self._record_path(entity_id, row_id)
        tmp = temp_file(path)
        try:
            if self.fmt == "json":
                dump_json(values, tmp, ensure_ascii=False, indent=2, sort_keys=True)
            else:
                save_pkl(values, tmp)
            replace_file(tmp, path)
        finally:
            delete_file(tmp)

    def _delete_record(self, entity_id: str, row_id: str) -> None:
        path = self._record_path(entity_id, row_id)
        if exists_path(path):
            delete_file(path)

    @backend_locked
    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Apply row mutations to memory and persisted record files.

        Args:
            rows: Backend row mutations. Upserts rewrite one record file; deletes remove
                the record file if it exists.

        Returns:
            None: This function does not return a value.
        """
        ns = self.data.setdefault(self.ws_id, {})
        for row in rows:
            self._ensure_loaded(row.entity_id)
            entity_rows = ns.setdefault(row.entity_id, {})
            if row.is_delete():
                entity_rows.pop(row.object_id, None)
                self._delete_record(row.entity_id, str(row.object_id))
                continue
            item = row.to_row()
            entity_rows[row.object_id] = item
            self._save_record(row.entity_id, str(row.object_id), item)

    @backend_locked
    def scan(self, entity_id: str) -> List[Dict[str, Any]]:
        """Load and return all rows for one entity.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            List[Dict[str, Any]]: Row fragments loaded from the entity folder.
        """
        entity_id = check_entity_id(entity_id)
        self.data.setdefault(self.ws_id, {})[entity_id] = self._load_entity(entity_id)
        self._loaded_entities.setdefault(self.ws_id, set()).add(entity_id)
        return super().scan(entity_id)

    @backend_locked
    def get_many(self, entity_id: str, object_ids: Iterable[Any]) -> List[Optional[Dict[str, Any]]]:
        """Return requested rows by reading only the needed record files.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to read.

        Returns:
            List[Optional[Dict[str, Any]]]: Row fragments aligned to ``object_ids``.
                Missing files produce ``None``.
        """
        entity_id = check_entity_id(entity_id)
        out: List[Optional[Dict[str, Any]]] = []
        bucket = self.data.setdefault(self.ws_id, {}).setdefault(entity_id, {})
        for object_id in object_ids:
            path = self._record_path(entity_id, str(object_id))
            row = self._load_record(path) if exists_path(path) else None
            if row is not None:
                row.setdefault("object_id", object_id)
                bucket[row["object_id"]] = row
                out.append(dict(row))
            else:
                bucket.pop(object_id, None)
                out.append(None)
        return out

    @backend_locked
    def exists_many(self, entity_id: str, object_ids: Iterable[Any]) -> List[bool]:
        """Return existence flags without loading the whole entity folder.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to test.

        Returns:
            List[bool]: Boolean flags aligned to ``object_ids``.
        """
        entity_id = check_entity_id(entity_id)
        bucket = self.data.setdefault(self.ws_id, {}).setdefault(entity_id, {})
        out = []
        for object_id in object_ids:
            exists = exists_path(self._record_path(entity_id, str(object_id)))
            if not exists:
                bucket.pop(object_id, None)
            out.append(exists)
        return out

    @backend_locked
    def count(self, entity_id: str) -> int:
        """Return row count without loading every record body.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            int: Number of record files for the entity.
        """
        entity_id = check_entity_id(entity_id)
        entity_dir = self._entity_dir(entity_id)
        if not exists_path(entity_dir):
            return 0
        return sum(1 for _ in list_files(entity_dir, ext=self.suffix[1:], abs=True))

    def to_dict(self) -> dict[str, Any]:
        """Return file backend metadata.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend name, backend type, active path, and record format.
        """
        return {"name": self.name, "type": self.type, "path": self.path, "fmt": self.fmt}
