"""Redis backend handler role."""

from .runtime import register_handlers

__all__ = ["register_handlers"]
