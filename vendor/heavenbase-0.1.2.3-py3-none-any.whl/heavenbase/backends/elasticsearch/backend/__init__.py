"""Elasticsearch Backend role."""

from .runtime import ElasticsearchBackend

__all__ = ["ElasticsearchBackend"]
