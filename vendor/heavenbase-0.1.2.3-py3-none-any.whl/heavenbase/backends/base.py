"""Physical backend runtime protocol."""

from __future__ import annotations

__all__ = ["Backend", "backend_locked"]

import threading
from functools import wraps

from heavenbase.utils import Any, Callable, Iterable, Mapping, Sequence

from ..execution.frame.result import ResultFrame
from ..execution.contracts import QueryFragment, RowOp
from ..modules import ModuleResolver, ResolvedTagValue, TagView, module_resolver
from ..modules.tags import tag as module_tag, tags as module_tags
from ..schema.model import EntitySchema
from ..types import logical_type_from_any
from ..utils.ids import check_id, check_workspace_id
from heavenbase.utils.registry import class_identifier
from .capabilities import ScalarIndexSpec
from .mcp import BackendMCP
from .strategy import StrategyAdapter


def backend_locked(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Run a backend method under the instance re-entrant lock.

    Args:
        fn: Backend instance method to guard with ``self._lock``.

    Returns:
        Callable[..., Any]: Wrapped backend method.
    """

    @wraps(fn)
    def _wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        with self._lock:
            return fn(self, *args, **kwargs)

    return _wrapped


class Backend:
    """Thin physical adapter that executes fragments without parsing query specs.

    Provider adapters subclass ``Backend`` to implement physical row storage and
    compiled-fragment execution. Static behavior is declared on the published
    Backend-type record; construction and live values stay instance-local.

    Args:
        name: Workspace backend instance name.
        ws_id: Optional workspace namespace to bind at construction time.
    """

    identifier = "backend"
    aliases: Sequence[str] = ()

    def __init__(
        self,
        name: str,
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> None:
        """Create a backend instance.

        Args:
            name: Workspace backend instance name.
            ws_id: Optional workspace namespace. Passing ``None`` leaves the backend unbound.
            resolver: Context-owned module authority. ``None`` retains an
                unresolved binding for direct bootstrap or standalone use.
            config: Config authority used by provider construction and runtime policy.

        Returns:
            None: This function does not return a value.
        """
        if config is not None and not callable(getattr(config, "get", None)):
            raise TypeError("Backend config authority must provide get(path, default)")
        self._module_resolver = resolver
        self._config = config
        self.name = check_id(name, "backend instance name")
        self.type = type(self).identifier
        self._ws_id: str | None = None
        self.ws_id = ws_id
        self._lock = threading.RLock()
        self._strategy_adapters: dict[str, StrategyAdapter] = {}

    @property
    def module_resolver(self) -> ModuleResolver:
        """Return the module authority bound to this live backend.

        Fully unbound standalone backends use the default Context resolver.
        A Backend with explicit config but no resolver is the private Context
        bootstrap state and cannot be consumed until Context finalizes it.
        Workspace registries bind both authorities before exposing a Backend.

        Returns:
            ModuleResolver: Bound or standalone-default module authority.

        Raises:
            RuntimeError: If a deferred Context bootstrap Backend escaped
                before its ModuleService was bound.
        """
        if self._module_resolver is None and self._config is not None:
            raise RuntimeError("Context bootstrap Backend is not yet bound to its ModuleService")
        return module_resolver(self._module_resolver)

    @property
    def config(self) -> Any:
        """Return the configuration authority bound to this live backend.

        Returns:
            Any: Bound ConfigManager-compatible object, or the process default
                for a standalone backend.
        """
        if self._config is not None:
            return self._config
        from heavenbase.utils.config import CM_HVNB

        return CM_HVNB

    def _construction_config_get(self, path: str, default: Any = None) -> Any:
        """Read policy safely while direct control bootstrap has no Registry.

        Ordinary Backends consult their explicitly bound config authority.
        The direct control Backend must use that manager's immutable default
        layer until its Registry-backed scope store has opened, preventing the
        persistence Backend from recursively querying itself.
        """
        if self._module_resolver is None and self._config is not None:
            values = getattr(self._config, "default", None)
            if isinstance(values, Mapping):
                from ..utils.config.data import dget

                return dget(values, path, default)
        return self.config.get(path, default=default)

    @property
    def ws_id(self) -> str:
        """Return the bound workspace id.

        Returns:
            str: Bound workspace id, or ``""`` when this backend is unbound.
        """
        return self._ws_id or ""

    @ws_id.setter
    def ws_id(self, value: str | None) -> None:
        """Set the bound workspace id.

        Args:
            value: Workspace id to validate and store, or ``None`` to clear binding.

        Returns:
            None: This function does not return a value.
        """
        self._ws_id = check_workspace_id(value) if value else None

    @staticmethod
    def locked(fn: Callable[..., Any]) -> Callable[..., Any]:
        """Run a backend method under the instance re-entrant lock.

        Args:
            fn: Backend instance method to wrap.

        Returns:
            Callable[..., Any]: Wrapped backend method.
        """
        return backend_locked(fn)

    @classmethod
    def from_config(
        cls,
        name: str,
        data: Mapping[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "Backend":
        """Build a backend instance from a config mapping.

        Args:
            name: Workspace backend instance name.
            data: Backend-specific config with optional ``ws_id``.
            resolver: Context-owned module authority.
            config: Config authority used by provider construction and runtime policy.

        Returns:
            Backend: Configured backend instance.
        """
        cfg = dict(data or {})
        return cls(name, ws_id=cfg.pop("ws_id", None), resolver=resolver, config=config, **cfg)

    @classmethod
    def register(
        cls,
        *,
        identifier: str | None = None,
        tags: Mapping[str, Any] | None = None,
        aliases: Sequence[str] | None = None,
        factory: Callable[[str, Mapping[str, Any]], "Backend"] | None = None,
        resolver: ModuleResolver | None = None,
    ) -> type["Backend"]:
        """Register this backend class and its config builder.

        Args:
            identifier: Optional canonical backend identifier. Defaults to the backend class's own
                ``identifier`` or a class-name-derived identifier.
            tags: Optional raw static Tag claims copied to the published Backend-type record.
            aliases: Optional identifier aliases. Defaults to aliases declared directly on ``cls``.
            factory: Optional importable `BackendFactory`. Defaults to
                adapting `cls.from_config` at resolution time.
            resolver: Context-owned module resolver. The default Context is
                selected when omitted. Backend registration requires the
                selected resolver to be a `ModuleService`.

        Returns:
            type[Backend]: The registered backend class.
        """
        from .registry import BackendType

        ident = identifier or class_identifier(cls, label="backend identifier")
        alias_values = tuple(cls.__dict__.get("aliases", ()) if aliases is None else aliases)
        return BackendType._register(
            cls,
            tags={} if tags is None else tags,
            aliases=alias_values,
            identifier=ident,
            factory=factory,
            resolver=module_resolver(resolver),
        )

    @classmethod
    def indexable(cls, dtype: Any, *, resolver: ModuleResolver | None = None) -> bool:
        """Return whether this backend's default value index can represent a logical type.

        Args:
            dtype: Logical type class, instance, identifier, alias, or descriptor.
            resolver: Context-owned module resolver. The default Context is
                selected when omitted.

        Returns:
            True when the backend's scalar equality/property index policy accepts the type.
        """
        selected = module_resolver(resolver)
        result = module_tag(selected, "backend_type", cls.identifier, "indexable-types")
        if result is None:
            return False
        if result.value is None or not isinstance(result.value, Sequence) or isinstance(result.value, (str, bytes)):
            raise TypeError(f"Backend {cls.identifier!r} indexable-types tag must be a sequence")
        return type(logical_type_from_any(dtype, resolver=selected)).identifier in result.value

    def _adopt_process_defaults(self) -> None:
        """Bind a fully unbound standalone Backend to process-default authorities.

        This is the only post-construction adoption contract. Explicit
        construction bindings are immutable, and custom Context registries
        must receive Backends built with their resolver and config directly.
        """
        if self._module_resolver is not None or self._config is not None:
            raise ValueError("Only a fully unbound standalone Backend can adopt process-default authorities")
        from heavenbase.utils.config import CM_HVNB

        resolver = module_resolver()
        self._module_resolver = resolver
        self._config = CM_HVNB

    def _finalize_bootstrap_resolver(self, resolver: ModuleResolver) -> None:
        """Complete the direct control Backend's one deferred authority binding.

        Direct Context bootstrap constructs its persistence Backend before the
        module catalog can exist. The owning root Context calls this seam once
        after creating that catalog. Ordinary and workspace Backends must bind
        their resolver during construction instead.
        """
        if resolver is None:
            raise TypeError("Bootstrap resolver finalization requires a concrete module authority")
        if self._module_resolver is resolver:
            return
        if self._module_resolver is not None:
            raise ValueError("The control Backend is already bound to a different module resolver")
        if self._config is None:
            raise ValueError("Bootstrap resolver finalization requires an explicitly bound config authority")
        self._module_resolver = resolver

    @staticmethod
    def _physical_name(*parts: str, sep: str = "_") -> str:
        """Return a transparent provider name from already-validated id parts.

        This is intentionally a small backend helper, not a collision-resolution system. It only normalizes
        HeavenBase's public ``-`` / ``_`` separators to the provider separator and joins multiple parts. Users
        remain responsible for choosing logical ids that are unique, short enough, and portable for the
        backends they operate directly.
        """
        return sep.join(str(part).replace("-", sep).replace("_", sep) for part in parts)

    def schema_warnings(self, schema: EntitySchema, bindings: Sequence[Any]) -> list[str]:
        """Return optional backend-specific warnings for a schema before physical ensure.

        Backends override this when they can cheaply detect provider naming anti-patterns such as reserved
        identifiers, length limits, or normalized-name collisions. The default is intentionally silent.

        Args:
            schema: Entity schema being registered.
            bindings: Storage bindings routed to this backend.

        Returns:
            list[str]: User-facing warning messages.
        """
        return []

    def warn_schema(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Emit optional backend-specific schema warnings for user-facing schemas.

        Args:
            schema: Entity schema being registered.
            bindings: Storage bindings routed to this backend.

        Returns:
            None: This function does not return a value.
        """
        import warnings

        if "system" in schema.tags or self._is_internal_entity_id(schema.entity_id):
            return
        for message in self.schema_warnings(schema, bindings):
            warnings.warn(message, UserWarning, stacklevel=4)

    @staticmethod
    def _is_internal_entity_id(entity_id: str) -> bool:
        """Return whether an entity identifier is owned by HeavenBase internals."""
        return str(entity_id).startswith("sys-")

    def _physical_name_warnings(
        self,
        names: Sequence[tuple[str, str]],
        *,
        kind: str,
        max_length: int | None = None,
        reserved: Iterable[str] = (),
        case_sensitive: bool = True,
    ) -> list[str]:
        """Return warnings for provider-name length, reserved-word, and collision risks."""
        out: list[str] = []
        reserved_names = {str(name).lower() for name in reserved}
        pairs = [(str(logical), str(physical)) for logical, physical in names]
        for logical, physical in pairs:
            if max_length is not None and len(physical) > max_length:
                out.append(
                    f"Backend {self.name!r} ({self.type}) maps {kind} {logical!r} to provider name {physical!r} "
                    f"({len(physical)} chars), above limit {max_length}"
                )
            if physical.lower() in reserved_names:
                out.append(f"Backend {self.name!r} ({self.type}) maps {kind} {logical!r} to reserved provider name {physical!r}")
        seen: dict[str, list[tuple[str, str]]] = {}
        for logical, physical in pairs:
            key = physical if case_sensitive else physical.lower()
            seen.setdefault(key, []).append((logical, physical))
        for matches in seen.values():
            if len(matches) > 1:
                details = ", ".join(f"{logical!r}->{physical!r}" for logical, physical in matches)
                out.append(f"Backend {self.name!r} ({self.type}) maps multiple {kind} names to the same provider name: {details}")
        return out

    def bind_workspace(self, ws_id: str) -> "Backend":
        """Bind this backend instance to a validated workspace namespace.

        Args:
            ws_id: Workspace namespace to bind.

        Returns:
            Backend: This backend instance for chained setup.
        """
        with self._lock:
            next_id = check_workspace_id(ws_id)
            if self._ws_id != next_id:
                self._ws_id = next_id
                self._refresh_workspace()
        return self

    def _refresh_workspace(self) -> None:
        """Refresh state derived from the workspace namespace."""
        return None

    def drop(self) -> None:
        """Drop this backend's current workspace namespace, if it has one.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        return None

    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Prepare storage for an entity schema and its bindings.

        Args:
            schema: Entity schema to create or refresh in physical storage.
            bindings: Storage bindings routed to this backend.

        Returns:
            None: This function does not return a value.
        """
        return None

    def ensure_plan(self, schema: EntitySchema, storage_plan: Any) -> None:
        """Prepare storage from a resolved plan while preserving the legacy ensure seam.

        Backends that implement configurable scalar indexes override this method.
        Other providers continue receiving the historical storage-binding sequence.

        Args:
            schema: Entity schema to create or refresh in physical storage.
            storage_plan: Resolved placement, index, and constraint plan.

        Returns:
            None: This function does not return a value.
        """
        self.ensure(schema, storage_plan.bindings)
        self.ensure_indexes(schema, storage_plan)

    def ensure_indexes(self, schema: EntitySchema, storage_plan: Any) -> None:
        """Reconcile configurable scalar indexes after structural ensure.

        Args:
            schema: Entity schema whose resolved index plan is active.
            storage_plan: Resolved placement, index, and constraint plan.

        Returns:
            None: Providers without configurable scalar indexes do nothing.
        """
        return None

    @staticmethod
    def ordered_row_op_batches(rows: Sequence[RowOp]) -> Iterable[tuple[str, bool, list[RowOp]]]:
        """Yield efficient mutation batches without changing observable input order.

        A batch contains adjacent operations for one entity and one operation kind.
        Repeating an object id starts a new batch so adapters that implement replacement
        with ``delete + insert`` still preserve sequential same-key semantics.

        Args:
            rows (Sequence[RowOp]): Ordered backend mutations.

        Yields:
            tuple[str, bool, list[RowOp]]: Entity id, delete flag, and a non-empty
                same-kind batch with unique object ids.
        """
        entity_id: str | None = None
        is_delete = False
        batch: list[RowOp] = []
        object_ids: set[str] = set()
        for row in rows:
            row_is_delete = row.is_delete()
            object_id = str(row.object_id)
            if batch and (row.entity_id != entity_id or row_is_delete != is_delete or object_id in object_ids):
                assert entity_id is not None
                yield entity_id, is_delete, batch
                batch = []
                object_ids = set()
            if not batch:
                entity_id = row.entity_id
                is_delete = row_is_delete
            batch.append(row)
            object_ids.add(object_id)
        if batch:
            assert entity_id is not None
            yield entity_id, is_delete, batch

    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Apply replacement upserts and idempotent deletes for backend row fragments.

        Args:
            rows: Row mutations for this backend. Each ``RowOp`` has an ``entity_id``,
                ``object_id``, backend-ready encoded ``values``, and an ``op`` of either
                ``"upsert"`` or ``"delete"``. Use ``row.is_upsert()``,
                ``row.is_delete()``, and ``row.to_row()`` for dispatch and replacement
                row construction.

        Returns:
            None: This function does not return a value.

        Raises:
            NotImplementedError: If called on the base backend contract instead of a provider
                implementation.

        Notes:
            ``"upsert"`` replaces the stored fragment for ``(entity_id, object_id)`` with
            ``row.to_row()``. ``"delete"`` removes that fragment if present and succeeds when
            it is already absent. Callers may order mutations to preserve referential safety
            across a non-transactional apply. A provider must preserve that observable order;
            it may reorder only inside a batch whose failure is atomic.
        """
        raise NotImplementedError

    def compare_upsert(
        self,
        row: RowOp,
        *,
        revision_field: str,
        expected_revision: int | None,
    ) -> bool:
        """Conditionally create or replace one row by revision.

        Providers that qualify for shared persistent Registry writes override
        this method with one atomic native operation. There is deliberately no
        read-then-upsert fallback because it would lose concurrent writes.

        Args:
            row (RowOp): Replacement upsert containing the next revision.
            revision_field (str): Row field holding the current integer revision.
            expected_revision (int | None): Required current revision. `None`
                requires the row to be absent.

        Returns:
            bool: `True` when the replacement won; `False` when the expected
            state did not match and no mutation occurred.

        Raises:
            NotImplementedError: If this Backend has not qualified atomic CAS.
        """
        raise NotImplementedError(f"Backend {self.type!r} does not support atomic compare_upsert")

    def delete(self, entity_id: str, object_ids: Iterable[Any]) -> None:
        """Delete object ids for one entity through the ``upsert`` mutation funnel.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to remove.

        Returns:
            None: This function does not return a value.
        """
        self.upsert([RowOp(entity_id, object_id, op="delete") for object_id in object_ids])

    def get_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[dict[str, Any] | None]:
        """Return rows for object ids in input order, using scan as the portable fallback.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to read.

        Returns:
            list[dict[str, Any] | None]: Row fragments aligned to the input ids. Missing rows are ``None``.
        """
        ordered_ids = list(object_ids)
        wanted = set(ordered_ids)
        rows = {row.get("object_id"): row for row in self.scan(entity_id) if row.get("object_id") in wanted}
        return [rows.get(row_id) for row_id in ordered_ids]

    def exists_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[bool]:
        """Return existence flags for object ids in input order.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to test.

        Returns:
            list[bool]: Boolean flags aligned to the input ids.
        """
        return [row is not None for row in self.get_many(entity_id, object_ids)]

    def count(self, entity_id: str) -> int:
        """Return row count for one entity.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            int: Number of row fragments stored for the entity.
        """
        return len(self.scan(entity_id))

    def exact_count(self, entity_id: str) -> int:
        """Return an exact row-fragment count suitable for integrity proofs.

        The default derives the proof from the exhaustive :meth:`scan`
        contract. A lookup-only backend must explicitly override this method;
        an ordinary provider count is never assumed exact by default.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            int: Exact number of row fragments stored for the entity.

        Raises:
            NotImplementedError: If this backend cannot prove an exact count.
        """
        return len(self.scan(entity_id))

    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute a compiled query fragment with the portable scan fallback.

        Args:
            fragment: Backend-ready query fragment.

        Returns:
            ResultFrame: Rows matched by the fragment.

        Raises:
            NotImplementedError: If the backend does not implement ``scan``.
        """
        from .scanning import execute_scan

        return execute_scan(self, fragment)

    def scan(self, entity_id: str) -> list[dict[str, Any]]:
        """Return all rows for one entity as dictionaries.

        This is an exhaustive integrity contract, not a best-effort page. Providers
        must paginate to exhaustion or raise when completeness cannot be guaranteed.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            list[dict[str, Any]]: Backend row fragments.

        Raises:
            NotImplementedError: If the backend does not implement scanning.
        """
        raise NotImplementedError

    def iter_scan(self, entity_id: str, *, batch_size: int) -> Iterable[dict[str, Any]]:
        """Iterate all unique row fragments with bounded transient memory.

        Args:
            entity_id (str): Logical entity identifier.
            batch_size (int): Positive maximum provider page size.

        Returns:
            Iterable[dict[str, Any]]: Exhaustive detached row fragments.

        Raises:
            NotImplementedError: If the provider has no bounded scan. Implement
                this contract explicitly; wrapping a materialized scan is not
                a bounded implementation.

        Notes:
            This is not a cross-backend transaction or immutable snapshot.
            Callers must keep the source stable during exhaustive enumeration.
        """
        raise NotImplementedError(f"{type(self).__name__} does not support bounded iter_scan")

    def to_dict(self) -> dict[str, Any]:
        """Return backend metadata suitable for system catalog rows.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend instance metadata.
        """
        return {"name": self.name, "type": self.type}

    def _construction_tag_claims(self) -> dict[str, Any]:
        """Return construction-derived tag values for this concrete instance.

        Args:
            None.

        Returns:
            dict[str, Any]: Whole-value construction overlays.
        """
        return {}

    def _live_tag_claims(self) -> dict[str, Any]:
        """Return best-effort live tag values for this concrete instance.

        Args:
            None.

        Returns:
            dict[str, Any]: Whole-value live overlays.
        """
        return {"strategy-adapters": [adapter.to_dict() for adapter in self._strategy_adapters.values()]}

    def tags(self) -> TagView:
        """Return this concrete Backend's effective snapshot-bound Tag view.

        Args:
            None.

        Returns:
            TagView: Static record claims overlaid by construction and live values.
        """
        view = module_tags(self.module_resolver, "backend_type", self.type)
        construction = self._construction_tag_claims()
        if construction:
            view = view.overlay(construction, source="construction", instance=self)
        live = self._live_tag_claims()
        if live:
            view = view.overlay(live, source="live", instance=self)
        return view

    def tag(self, identifier: str) -> ResolvedTagValue | None:
        """Return one effective Tag result for this concrete Backend.

        Args:
            identifier: Canonical Tag identifier, alias, or unknown raw key.

        Returns:
            ResolvedTagValue | None: Snapshot-bound effective value, or `None`
                when neither a claim nor an applicable definition default exists.
        """
        return self.tags().get(identifier)

    def graph_incoming_sources(
        self,
        entity_id: str,
        field_name: str,
        target_entity: str,
        target_ids: Sequence[Any],
    ) -> list[str]:
        """Return a complete superset of source ids referencing typed targets.

        The workspace hydrates and rechecks returned sources before mutation, so false
        positives are safe but false negatives violate the capability contract.

        Args:
            entity_id (str): Logical entity that owns the GraphEdge field.
            field_name (str): GraphEdge field whose incoming references are requested.
            target_entity (str): Logical entity type of every requested target.
            target_ids (Sequence[Any]): Target object ids whose incoming sources are needed.

        Returns:
            list[str]: Source object ids containing every matching incoming reference;
                additional false-positive candidates are permitted.

        Raises:
            NotImplementedError: If native incoming lookup is not supported.
        """
        del entity_id, field_name, target_entity, target_ids
        raise NotImplementedError(f"{type(self).__name__} does not support native GraphEdge incoming lookup")

    def graph_traverse_refs(
        self,
        entity_id: str,
        start_id: Any,
        field_name: str,
        *,
        min_hops: int = 1,
        max_hops: int = 1,
        direction: str = "out",
        endpoint_preds: Sequence[tuple] | None = None,
    ) -> list[tuple[str, str]]:
        """Run native GraphEdge traversal and return typed node refs.

        Args:
            entity_id: Source entity identifier.
            start_id: Source object id.
            field_name: GraphEdge field name.
            min_hops: Minimum traversal depth.
            max_hops: Maximum traversal depth.
            direction: Traversal direction. Supported values are backend-defined but normally ``"out"``, ``"in"``, or ``"both"``.
            endpoint_preds: Optional endpoint predicates already proven pushable by the route planner.

        Returns:
            list[tuple[str, str]]: ``(entity_id, object_id)`` refs reached by traversal.

        Raises:
            NotImplementedError: If the backend does not support native GraphEdge traversal.
        """
        raise NotImplementedError(f"{type(self).__name__} does not support native GraphEdge traversal")

    def graph_traverse(
        self,
        entity_id: str,
        start_id: Any,
        field_name: str,
        *,
        min_hops: int = 1,
        max_hops: int = 1,
        direction: str = "out",
        endpoint_preds: Sequence[tuple] | None = None,
    ) -> list[str]:
        """Run native GraphEdge traversal and return object ids for self-referential callers.

        Args:
            entity_id: Source entity identifier.
            start_id: Source object id.
            field_name: GraphEdge field name.
            min_hops: Minimum traversal depth.
            max_hops: Maximum traversal depth.
            direction: Traversal direction.
            endpoint_preds: Optional endpoint predicates already proven pushable by the route planner.

        Returns:
            list[str]: Reached object ids when the traversal stays inside one entity.
        """
        return [
            object_id
            for _entity, object_id in self.graph_traverse_refs(
                entity_id,
                start_id,
                field_name,
                min_hops=min_hops,
                max_hops=max_hops,
                direction=direction,
                endpoint_preds=endpoint_preds,
            )
        ]

    def graph_shortest_path_refs(
        self,
        entity_id: str,
        start_id: Any,
        end_id: Any,
        field_name: str,
        *,
        max_hops: int = 10,
        direction: str = "out",
    ) -> list[tuple[str, str]] | None:
        """Run native GraphEdge shortest-path search and return typed node refs.

        Args:
            entity_id: Source entity identifier.
            start_id: Source object id.
            end_id: Target object id.
            field_name: GraphEdge field name.
            max_hops: Maximum path length to search.
            direction: Traversal direction.

        Returns:
            list[tuple[str, str]] | None: Path refs, or ``None`` when no path exists.

        Raises:
            NotImplementedError: If the backend does not support native GraphEdge traversal.
        """
        raise NotImplementedError(f"{type(self).__name__} does not support native GraphEdge traversal")

    def graph_shortest_path(
        self,
        entity_id: str,
        start_id: Any,
        end_id: Any,
        field_name: str,
        *,
        max_hops: int = 10,
        direction: str = "out",
    ) -> list[str] | None:
        """Run native GraphEdge shortest-path search and return object ids for self-referential callers.

        Args:
            entity_id: Source entity identifier.
            start_id: Source object id.
            end_id: Target object id.
            field_name: GraphEdge field name.
            max_hops: Maximum path length to search.
            direction: Traversal direction.

        Returns:
            list[str] | None: Path object ids, or ``None`` when no path exists.
        """
        refs = self.graph_shortest_path_refs(entity_id, start_id, end_id, field_name, max_hops=max_hops, direction=direction)
        return [object_id for _entity, object_id in refs] if refs is not None else None

    def register_strategy_adapter(self, adapter: StrategyAdapter, *, replace: bool = False) -> StrategyAdapter:
        """Register a backend-local adapter for one storage strategy.

        Args:
            adapter (StrategyAdapter): Backend-local strategy adapter owned by this
                instance.
            replace (bool): Replace a different adapter for the same strategy.

        Returns:
            StrategyAdapter: The registered adapter.

        Raises:
            TypeError: If `adapter` is not a complete `StrategyAdapter` implementation.
            ValueError: If the adapter belongs to another backend or its strategy is
                already owned, or its identifier conflicts with another strategy.
        """
        if not isinstance(adapter, StrategyAdapter):
            raise TypeError(f"Expected StrategyAdapter, got {type(adapter).__name__}")
        if adapter.backend is not self:
            raise ValueError(f"Strategy adapter {adapter.identifier!r} belongs to a different backend")
        missing = [name for name in ("ensure", "upsert") if getattr(type(adapter), name) is getattr(StrategyAdapter, name)]
        if missing:
            raise TypeError(f"Strategy adapter {adapter.identifier!r} must implement {', '.join(missing)}")
        for registered in self._strategy_adapters.values():
            if registered.identifier == adapter.identifier and registered.strategy != adapter.strategy:
                raise ValueError(f"Backend {self.name!r} already has strategy adapter identifier {adapter.identifier!r}")
        existing = self._strategy_adapters.get(adapter.strategy)
        if existing is adapter:
            return adapter
        if existing is not None and not replace:
            raise ValueError(f"Backend {self.name!r} already has an adapter for strategy {adapter.strategy!r}")
        if existing is not None:
            existing.reset()
        self._strategy_adapters[adapter.strategy] = adapter
        return adapter

    def strategy_adapter(self, strategy: Any) -> StrategyAdapter | None:
        """Return the adapter registered for a strategy, if any.

        Args:
            strategy (Any): Storage strategy class, instance, identifier, alias,
                or serialized spec.

        Returns:
            StrategyAdapter | None: Registered adapter, or ``None`` when no adapter owns the strategy.
        """
        from ..strategies import StorageStrategy

        return self._strategy_adapters.get(StorageStrategy.identifier_of(strategy, resolver=self.module_resolver))

    def strategy_adapter_for_fragment(self, fragment: QueryFragment) -> StrategyAdapter | None:
        """Return the adapter that owns a compiled fragment, if any.

        Args:
            fragment (QueryFragment): Backend-ready query fragment.

        Returns:
            StrategyAdapter | None: Adapter that can execute the fragment, or ``None``.
        """
        for adapter in self._strategy_adapters.values():
            if adapter.can_execute(fragment):
                return adapter
        return None

    def supports_strategy(self, schema: EntitySchema, binding: Any) -> bool:
        """Return whether this backend has an adapter for one storage binding.

        Args:
            schema (EntitySchema): Entity schema being registered or queried.
            binding (Any): Storage binding to test.

        Returns:
            bool: True when a registered strategy adapter supports the binding.
        """
        adapter = self.strategy_adapter(getattr(binding, "strategy", None))
        return bool(adapter and adapter.supports(schema, binding))

    def candidate_id_fragment(self, object_ids: Sequence[Any]) -> QueryFragment:
        """Return a backend-local object-id filter fragment for candidate prefiltering.

        Args:
            object_ids: Candidate object ids to retain.

        Returns:
            QueryFragment: Python-scan fragment that filters rows by ``object_id``.
        """
        id_set = set(object_ids)

        def _payload(row: dict) -> bool:
            return row.get("object_id") in id_set

        return QueryFragment(self.name, "in", "object_id", _payload, notes={"mode": "py_scan", "row_payload": _payload, "candidate_ids": list(object_ids)})

    def scalar_index(self) -> ScalarIndexSpec:
        """Return the effective ``scalar-index`` Tag as a typed Backend facade.

        Args:
            None.

        Returns:
            ScalarIndexSpec: Effective scalar-index policy for this backend instance.
        """
        result = self.tag("scalar-index")
        return ScalarIndexSpec() if result is None else ScalarIndexSpec.load(result.value)

    def defaults_scalar_index(self, dtype: Any) -> bool:
        """Return whether this backend indexes one scalar type by default.

        Args:
            dtype: Logical type class, instance, identifier, alias, or descriptor.

        Returns:
            bool: Whether an undeclared field receives a provider-default index.
        """
        identifier = type(logical_type_from_any(dtype, resolver=self.module_resolver)).identifier
        caps = self.scalar_index()
        return caps.value and identifier in caps.default_types and self.indexable(dtype, resolver=self.module_resolver)

    def supports_scalar_index(self, schema: EntitySchema, fields: Sequence[str], *, unique: bool = False) -> bool:
        """Return whether this backend can honor one resolved scalar declaration.

        Args:
            schema: Entity schema owning the fields.
            fields: Ordered logical field names.
            unique: Whether the declaration is a correctness constraint.

        Returns:
            bool: Whether the type, arity, and requested semantics are supported.
        """
        caps = self.scalar_index()
        composite = len(fields) > 1
        if unique:
            if not caps.unique or (composite and not caps.composite_unique):
                return False
        elif not caps.value or (composite and not caps.composite):
            return False
        return all(
            type(schema.get(field_name).dtype).identifier in caps.supported_types
            and self.indexable(schema.get(field_name).dtype, resolver=self.module_resolver)
            for field_name in fields
        )

    def mcp(self) -> BackendMCP:
        """Return the complete backend MCP surface for this backend instance.

        Backend subclasses should override this method, call ``super().mcp()``, and add provider-specific
        tools/profiles to the returned ``BackendMCP`` object. This keeps callables, prompts/descriptions,
        profiles, default selection, and serializer configuration in one backend-owned contract.

        Args:
            None.

        Returns:
            BackendMCP: MCP specification containing generic backend inspection tools and profile defaults.

        Examples:
            Add a provider-specific read-only probe::

                def mcp(self) -> BackendMCP:
                    spec = super().mcp()
                    spec.tool("provider_probe", self.provider_probe, desc="Inspect provider-specific state.")
                    spec.profile("inspect", ("describe_backend", "backend_tags", "provider_probe"))
                    return spec
        """

        def describe_backend() -> dict[str, Any]:
            """Describe this backend instance.

            Args:
                None.

            Returns:
                dict[str, Any]: Backend metadata, effective Tag values, and
                registered backend MCP profiles.
            """
            return {
                "backend": self.to_dict(),
                "tags": backend_tags(),
                "profiles": spec.profile_summary(),
            }

        def backend_tags() -> dict[str, Any]:
            """Return effective Backend Tag metadata.

            Args:
                None.

            Returns:
                dict[str, Any]: Tag values with status, source, and snapshot evidence.
            """
            from ..utils.config.data import to_mutable_data

            return {
                identifier: {
                    "value": to_mutable_data(result.value),
                    "raw": to_mutable_data(result.raw),
                    "status": result.status,
                    "source": result.source,
                    "diagnostics": list(result.diagnostics),
                    "subject": list(result.subject),
                    "snapshot": result.snapshot,
                }
                for identifier, result in self.tags().items()
            }

        spec = BackendMCP(
            desc=f"HeavenBase backend {self.name!r} ({self.type}). Inspect physical backend metadata and provider-specific tools.",
            default_profile="inspect",
        )
        spec.tool(
            "describe_backend",
            describe_backend,
            desc="Describe the backend instance, provider type, effective Tags, and profiles.",
        )
        spec.tool("backend_tags", backend_tags, desc="Return effective Backend Tags with provenance and diagnostics.")
        spec.profile("inspect", ("describe_backend", "backend_tags"), desc="Read-only backend metadata inspection.")
        spec.profile("full", tuple(spec.tools), desc="All backend MCP tools.")
        return spec

    def to_mcp(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        profile: Any = None,
        tools: Iterable[str] | None = None,
    ) -> Any:
        """Return a native Toolkit bound to this backend instance.

        Args:
            name: Optional Toolkit name. Defaults to ``backend-<backend.name>`` or the configured
                ``heavenbase.mcp.backend_toolkit`` value.
            description: Optional Toolkit description override. Defaults to the description from
                ``self.mcp()`` plus the selected tool list.
            profile: Optional backend MCP profile selection. Accepts ``None`` for the backend default,
                a registered profile name, ``BackendMCPProfile``, or a mapping with ``name`` / ``tools`` /
                ``desc`` / ``description`` / ``prompt`` keys.
            tools: Optional explicit tool allowlist. When supplied, this overrides ``profile`` and creates
                an ad-hoc custom profile.

        Returns:
            Any: Runtime-only ``Toolkit`` bound to this backend instance.

        Examples:
            Expose only Tag inspection::

                toolkit = backend.to_mcp(tools=["backend_tags"])
        """
        from heavenbase.extensions.contributions import resolve_contribution

        backend_toolkit = resolve_contribution(
            "toolkit_function",
            "backend_toolkit",
            resolver=self.module_resolver,
            callable_only=True,
        )

        return backend_toolkit(
            self,
            name=name,
            description=description,
            profile=profile,
            tools=tools,
            resolver=self.module_resolver,
        )

    def to_mcp_json(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        profile: Any = None,
        tools: Iterable[str] | None = None,
        transport: str | None = None,
        host: str | None = None,
        port: int | None = None,
    ) -> str:
        """Return MCP client config JSON for this backend instance.

        Args:
            name: Optional Toolkit/server name.
            description: Optional Toolkit description override.
            profile: Optional backend MCP profile selection accepted by ``to_mcp``.
            tools: Optional explicit tool allowlist.
            transport: MCP transport. Defaults through ``heavenbase.mcp.transport``.
            host: HTTP host included in generated MCP client config.
            port: HTTP port included in generated MCP client config.

        Returns:
            str: Serialized MCP client configuration JSON.
        """
        from heavenbase.extensions.contributions import resolve_contribution

        mcp_transport = resolve_contribution("toolkit_function", "mcp_transport", resolver=self.module_resolver, callable_only=True)
        mcp_host = resolve_contribution("toolkit_function", "mcp_host", resolver=self.module_resolver, callable_only=True)
        mcp_port = resolve_contribution("toolkit_function", "mcp_port", resolver=self.module_resolver, callable_only=True)

        return self.to_mcp(name=name, description=description, profile=profile, tools=tools).to_mcp_json(
            transport=mcp_transport(transport, config=self.config),
            host=mcp_host(host, config=self.config),
            port=mcp_port(port, config=self.config),
        )

    def serve(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        profile: Any = None,
        tools: Iterable[str] | None = None,
        transport: str | None = None,
        host: str | None = None,
        port: int | None = None,
        **server_kwargs: Any,
    ) -> Any:
        """Serve this backend instance as an MCP server.

        Args:
            name: Optional Toolkit/server name.
            description: Optional Toolkit description override.
            profile: Optional backend MCP profile selection accepted by ``to_mcp``.
            tools: Optional explicit tool allowlist.
            transport: MCP transport. Defaults through ``heavenbase.mcp.transport``.
            host: HTTP host. Defaults through ``heavenbase.mcp.host``.
            port: HTTP port. Defaults through ``heavenbase.mcp.port``.
            **server_kwargs: Additional keyword arguments forwarded to FastMCP ``run``.

        Returns:
            Any: FastMCP result after the blocking server lifecycle completes.
        """
        from heavenbase.extensions.contributions import resolve_contribution

        mcp_transport = resolve_contribution("toolkit_function", "mcp_transport", resolver=self.module_resolver, callable_only=True)
        mcp_host = resolve_contribution("toolkit_function", "mcp_host", resolver=self.module_resolver, callable_only=True)
        mcp_port = resolve_contribution("toolkit_function", "mcp_port", resolver=self.module_resolver, callable_only=True)

        return self.to_mcp(name=name, description=description, profile=profile, tools=tools).serve(
            transport=mcp_transport(transport, config=self.config),
            host=mcp_host(host, config=self.config),
            port=mcp_port(port, config=self.config),
            **server_kwargs,
        )
