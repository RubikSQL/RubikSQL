"""TinyDB Backend role."""

from .runtime import TinyDBBackend

__all__ = ["TinyDBBackend"]
