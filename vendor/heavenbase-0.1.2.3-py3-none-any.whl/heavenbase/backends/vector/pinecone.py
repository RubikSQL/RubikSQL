"""Pinecone vector backend."""

from __future__ import annotations

__all__ = [
    "PineconeBackend",
]

from heavenbase.utils import Any, Iterable, Mapping, Sequence, safe_error
from ...execution.frame.result import ResultFrame
from ...modules import ModuleResolver
from ...schema.model import EntitySchema
from ..base import Backend, backend_locked
from heavenbase.execution.contracts import QueryFragment, RowOp

PINECONE_INDEX_MAX_LENGTH = 45
PINECONE_FETCH_MAX_IDS = 1000


def _is_local_host(host: Any) -> bool:
    text = str(host).lower()
    return text.startswith(("http://localhost", "https://localhost", "localhost", "http://127.0.0.1", "https://127.0.0.1", "127.0.0.1"))


class PineconeBackend(Backend):
    """Pinecone provider adapter with native vector search and metadata filters.

    Uses the Pinecone client for persistence, row lookup, native ``near``
    search, and metadata filtering through provider storage only.
    """

    identifier = "pinecone"
    provider_max_name_length = PINECONE_INDEX_MAX_LENGTH

    @classmethod
    def from_config(
        cls,
        name: str,
        data: Mapping[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "PineconeBackend":
        """Build the Pinecone backend from a config mapping.

        Args:
            name (str): Workspace backend instance name.
            data (Mapping[str, Any]): Backend config mapping. Supported keys are Pinecone
                constructor parameters, including ``host``, ``api_key``, and ``ws_id``.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.

        Returns:
            PineconeBackend: Configured Pinecone backend instance.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        return cls(name, cfg.pop("host", None), cfg.pop("api_key", None), ws_id=ws_id, resolver=resolver, config=config, **cfg)

    def __init__(
        self,
        name: str = "pinecone",
        host: str | None = None,
        api_key: str | None = None,
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a Pinecone backend.

        Args:
            name (str): Workspace backend instance name.
            host (str | None): Pinecone control-plane host. When omitted, uses configured
                backend defaults.
            api_key (str | None): Pinecone API key. Local hosts default to ``pclocal`` when
                no key is configured.
            ws_id (str | None): Optional workspace namespace used to prefix index names.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.
            **kwargs (Any): Extra keyword arguments passed to ``Pinecone(...)``.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(name, ws_id=ws_id, resolver=resolver, config=config)
        self.host = host or self._construction_config_get("heavenbase.backend_defaults.pinecone.host", default="http://localhost:5080")
        local = _is_local_host(self.host)
        configured_api_key = self._construction_config_get("heavenbase.backend_defaults.pinecone.api_key", default="")
        self.api_key = api_key or configured_api_key or ("pclocal" if local else "")
        default_ssl = not (str(self.host).startswith("http://") or local)
        kwargs.setdefault(
            "ssl_verify",
            self._construction_config_get("heavenbase.backend_defaults.pinecone.ssl_verify", default=default_ssl),
        )
        self._client_kwargs = dict(kwargs)
        self._schemas: dict[str, EntitySchema] = {}
        self._indexes: dict[str, str] = {}
        self.project_name = self._project_name()
        self.client_error = ""
        self._connect()

    def _project_name(self) -> str:
        if "project_name" in self._client_kwargs:
            return str(self._client_kwargs["project_name"])
        return self._ws_prefix()

    def _ws_prefix(self) -> str:
        # Workspace namespace used to prefix and reap this workspace's indexes. Derived from ws_id alone
        # (not the user-supplied client project_name) so client scoping and index ownership stay separate.
        return self._physical_name(self.ws_id, sep="-") if self.ws_id else ""

    def _connect(self) -> None:
        try:
            from pinecone import Pinecone

            kwargs = dict(self._client_kwargs)
            self.project_name = self._project_name()
            if self.project_name and "project_name" not in kwargs:
                kwargs["project_name"] = self.project_name
            self.client = Pinecone(api_key=self.api_key, host=self.host, **kwargs)
            self.client.list_indexes()
        except Exception as exc:
            self.client = None
            self.client_error = safe_error(exc)

    def _refresh_workspace(self) -> None:
        self._indexes.clear()
        self._connect()

    def _listed_index_names(self) -> list[str]:
        if self.client is None:
            return []
        indexes = self.client.list_indexes()
        if hasattr(indexes, "names"):
            return [str(name) for name in indexes.names()]
        if hasattr(indexes, "indexes"):
            indexes = indexes.indexes
        names = []
        for item in indexes or []:
            if isinstance(item, str):
                names.append(item)
            elif hasattr(item, "get") and item.get("name") is not None:
                names.append(str(item.get("name")))
            elif getattr(item, "name", None) is not None:
                names.append(str(item.name))
        return names

    @backend_locked
    def drop(self) -> None:
        """Drop this Pinecone project or workspace-prefixed indexes.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        try:
            if self.client is None:
                return
            delete_project = getattr(self.client, "delete_project", None)
            if delete_project is not None and self.project_name:
                try:
                    delete_project(name=self.project_name)
                except TypeError:
                    delete_project(self.project_name)
                return
            names = set(self._indexes.values())
            prefix = f"{self._ws_prefix()}-" if self.ws_id else ""
            if prefix:
                names.update(name for name in self._listed_index_names() if name.startswith(prefix))
            delete_index = getattr(self.client, "delete_index", None)
            if delete_index is not None:
                for name in sorted(names):
                    delete_index(name)
        finally:
            self._schemas.clear()
            self._indexes.clear()
            self.client = None

    def _need_client(self) -> None:
        if self.client is None:
            detail = f": {self.client_error}" if self.client_error else ""
            raise RuntimeError(f"Pinecone backend {self.name!r} is unavailable{detail}")

    def _index_name(self, entity_id: str) -> str:
        prefix = self._ws_prefix()
        if not prefix:
            return self._indexes.setdefault(entity_id, self._physical_name(entity_id, sep="-"))
        entity_part = self._physical_name(entity_id, sep="-")
        return self._indexes.setdefault(entity_id, f"{prefix}-{entity_part}")

    def schema_warnings(self, schema: EntitySchema, bindings: Sequence[Any]) -> list[str]:
        """Return Pinecone index-name warnings for this schema.

        Args:
            schema (EntitySchema): Entity schema being registered.
            bindings (Sequence[Any]): Storage bindings for the entity.

        Returns:
            list[str]: Provider naming warnings for physical index names.
        """
        warnings = super().schema_warnings(schema, bindings)
        warnings.extend(
            self._physical_name_warnings(
                [(schema.entity_id, self._index_name(schema.entity_id))],
                kind="Pinecone index",
                max_length=self.provider_max_name_length,
                case_sensitive=False,
            )
        )
        return warnings

    def _vector_field(self, entity_id: str) -> Any:
        schema = self._schemas.get(entity_id)
        if schema is None:
            return None
        return next((field_schema for field_schema in schema.fields.values() if type(field_schema.dtype).identifier == "vector"), None)

    def _dim(self, entity_id: str) -> int:
        vector = self._vector_field(entity_id)
        return vector.dtype.dim if vector is not None else 0

    def _index(self, name: str) -> Any:
        host = self.client.describe_index(name).host
        if "://" not in host:
            scheme = "http" if str(self.host).startswith("http://") or _is_local_host(self.host) else "https"
            host = f"{scheme}://{host}"
        kwargs = {"host": host}
        if str(host).startswith("http://"):
            kwargs["ssl_verify"] = False
        return self.client.Index(**kwargs)

    def _has_index(self, name: str) -> bool:
        return bool(self.client and self.client.has_index(name))

    def _degrade(self, exc: BaseException) -> None:
        self.client_error = safe_error(exc)
        self.client = None
        raise RuntimeError(f"Pinecone operation failed: {self.client_error}") from exc

    def _metadata(self, entity_id: str, values: dict[str, Any]) -> dict[str, Any]:
        schema = self._schemas.get(entity_id)
        out: dict[str, Any] = {}
        for key, value in values.items():
            if key == "object_id" or value is None:
                continue
            field_schema = schema.fields.get(key) if schema else None
            if field_schema is not None and type(field_schema.dtype).identifier == "array":
                if self._is_metadata_string_array(field_schema, value):
                    out[key] = value
                continue
            if not isinstance(value, (str, int, float, bool)):
                continue
            if field_schema is not None and type(field_schema.dtype).identifier in ("json", "hyper-g", "vector"):
                continue
            out[key] = value
        return out or {"_hb": True}

    def _is_metadata_string_array(self, field_schema: Any, value: Any) -> bool:
        item_type = getattr(field_schema.dtype, "item_type", None)
        return (
            item_type is not None
            and type(item_type).identifier in ("identifier", "long-text", "medium-text", "short-text")
            and isinstance(value, list)
            and bool(value)
            and all(isinstance(item, str) for item in value)
        )

    @backend_locked
    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Ensure a Pinecone index for the entity's vector field.

        Args:
            schema (EntitySchema): Entity schema to store in Pinecone.
            bindings (Sequence[Any]): Storage bindings supplied by the workspace.

        Returns:
            None: This function does not return a value.
        """
        self._schemas[schema.entity_id] = schema
        if self.client is None:
            return
        index_name = self._index_name(schema.entity_id)
        if self._has_index(index_name):
            return
        vector = self._vector_field(schema.entity_id)
        if vector is None:
            return
        metric = str(self.config.get("heavenbase.backend_defaults.pinecone.metric", default="cosine")).lower()
        from pinecone import ServerlessSpec

        cloud = self.config.get("heavenbase.backend_defaults.pinecone.serverless.cloud", default="aws")
        region = self.config.get("heavenbase.backend_defaults.pinecone.serverless.region", default="us-east-1")
        self.client.create_index(
            name=index_name,
            dimension=vector.dtype.dim,
            metric=metric,
            spec=ServerlessSpec(cloud=cloud, region=region),
        )

    @backend_locked
    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Upsert vector records into Pinecone.

        Args:
            rows (Sequence[RowOp]): Row mutations to apply. ``delete`` operations remove
                vectors; other operations upsert vector values and metadata.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the Pinecone client is unavailable or an operation fails.
        """
        self._need_client()
        for entity_id, is_delete, ops in self.ordered_row_op_batches(rows):
            index_name = self._index_name(entity_id)
            if not self._has_index(index_name):
                continue
            vector = self._vector_field(entity_id)
            if vector is None:
                continue
            try:
                index = self._index(index_name)
                if is_delete:
                    index.delete(ids=[str(row.object_id) for row in ops])
                    continue
                vectors = []
                for row in ops:
                    vec = row.values.get(vector.name)
                    if vec is None:
                        continue
                    vectors.append({"id": str(row.object_id), "values": vec, "metadata": self._metadata(entity_id, row.values)})
                if vectors:
                    index.upsert(vectors=vectors)
            except Exception as exc:
                self._degrade(exc)

    def _hit_rows(self, res: Any, entity_id: str) -> list[dict[str, Any]]:
        rows = []
        matches = res.get("matches") if hasattr(res, "get") else getattr(res, "matches", [])
        for match in matches or []:
            row_id = match.get("id") if hasattr(match, "get") else getattr(match, "id", None)
            metadata = match.get("metadata") if hasattr(match, "get") else getattr(match, "metadata", {})
            row = dict(metadata or {})
            row["object_id"] = str(row_id)
            row["score"] = match.get("score", 0.0) if hasattr(match, "get") else getattr(match, "score", 0.0)
            rows.append(row)
        return rows

    @backend_locked
    def scan(self, entity_id: str) -> list[dict[str, Any]]:
        """Reject unbounded scans because Pinecone has no row scan API.

        Args:
            entity_id (str): Entity identifier that would be scanned.

        Returns:
            list[dict[str, Any]]: This method never returns rows.

        Raises:
            RuntimeError: If the Pinecone client is unavailable.
            NotImplementedError: Always raised for reachable clients.
        """
        self._need_client()
        raise NotImplementedError("Pinecone scan is unsupported; use fetch(ids=...) or native near search")

    def _vector_map(self, res: Any) -> dict[str, Any]:
        vectors = res.get("vectors") if hasattr(res, "get") else getattr(res, "vectors", {})
        return dict(vectors or {})

    def _fetch_vector_map(self, index: Any, object_ids: Sequence[str]) -> dict[str, Any]:
        """Fetch unique vector ids in provider-sized batches."""
        unique_ids = list(dict.fromkeys(object_ids))
        vectors = {}
        for offset in range(0, len(unique_ids), PINECONE_FETCH_MAX_IDS):
            batch = unique_ids[offset : offset + PINECONE_FETCH_MAX_IDS]
            vectors.update(self._vector_map(index.fetch(ids=batch)))
        return vectors

    def _vector_item_get(self, item: Any, key: str, default: Any = None) -> Any:
        return item.get(key, default) if hasattr(item, "get") else getattr(item, key, default)

    def _row_from_vector(self, entity_id: str, object_id: Any, item: Any) -> dict[str, Any]:
        row = dict(self._vector_item_get(item, "metadata", {}) or {})
        row["object_id"] = str(object_id)
        vector = self._vector_field(entity_id)
        values = self._vector_item_get(item, "values")
        if vector is not None and values is not None:
            row[vector.name] = values.tolist() if hasattr(values, "tolist") else list(values)
        return row

    @backend_locked
    def get_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[dict[str, Any] | None]:
        """Return rows through Pinecone fetch.

        Args:
            entity_id (str): Entity identifier whose vectors should be loaded.
            object_ids (Iterable[Any]): Object identifiers to fetch in caller order.

        Returns:
            list[dict[str, Any] | None]: Rows aligned with ``object_ids``. Missing vectors
            are returned as ``None``.

        Raises:
            RuntimeError: If the Pinecone client is unavailable or fetch fails.
        """
        ordered_ids = [str(object_id) for object_id in object_ids]
        if not ordered_ids:
            return []
        index_name = self._index_name(entity_id)
        self._need_client()
        if not self._has_index(index_name):
            return [None for _ in ordered_ids]
        try:
            vectors = self._fetch_vector_map(self._index(index_name), ordered_ids)
            rows_by_id = {str(row_id): self._row_from_vector(entity_id, row_id, item) for row_id, item in vectors.items()}
            return [rows_by_id.get(row_id) for row_id in ordered_ids]
        except Exception as exc:
            self._degrade(exc)

    @backend_locked
    def exists_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[bool]:
        """Return existence flags through Pinecone fetch.

        Args:
            entity_id (str): Entity identifier whose vectors should be checked.
            object_ids (Iterable[Any]): Object identifiers to check in caller order.

        Returns:
            list[bool]: Existence flags aligned with ``object_ids``.

        Raises:
            RuntimeError: If the Pinecone client is unavailable or fetch fails.
        """
        ordered_ids = [str(object_id) for object_id in object_ids]
        if not ordered_ids:
            return []
        index_name = self._index_name(entity_id)
        self._need_client()
        if not self._has_index(index_name):
            return [False for _ in ordered_ids]
        try:
            found = {str(row_id) for row_id in self._fetch_vector_map(self._index(index_name), ordered_ids)}
            return [row_id in found for row_id in ordered_ids]
        except Exception as exc:
            self._degrade(exc)

    @backend_locked
    def count(self, entity_id: str) -> int:
        """Return Pinecone's provider-reported count without materializing vectors.

        Args:
            entity_id (str): Entity identifier whose index should be counted.

        Returns:
            int: Provider-reported total vector count, or ``0`` when the index is absent.

        Raises:
            RuntimeError: If the Pinecone client is unavailable or stats lookup fails.

        Notes:
            Pinecone is eventually consistent, so this value is not used as an
            exhaustive logical-identity proof by portable query folds.
        """
        index_name = self._index_name(entity_id)
        self._need_client()
        if not self._has_index(index_name):
            return 0
        try:
            stats = self._index(index_name).describe_index_stats()
            return int(stats.get("total_vector_count", 0) if hasattr(stats, "get") else getattr(stats, "total_vector_count", 0) or 0)
        except Exception as exc:
            self._degrade(exc)

    def exact_count(self, entity_id: str) -> int:
        """Reject use of eventually consistent Pinecone stats as an exact proof.

        Args:
            entity_id: Logical entity identifier whose fragments would be counted.

        Returns:
            int: This method never returns a count.

        Raises:
            NotImplementedError: Always, because provider stats are eventually consistent.
        """
        raise NotImplementedError(f"Pinecone cannot prove an exact fragment count for {entity_id!r}")

    def _live_tag_claims(self) -> dict[str, Any]:
        """Return live tag claims derived from Pinecone availability.

        Args:
            None.

        Returns:
            dict[str, Any]: Live Backend tag claims.
        """
        return {
            **super()._live_tag_claims(),
            "backend-availability": "ready" if self.client is not None else "unavailable",
        }

    def _find_near_child(self, fragment: QueryFragment) -> QueryFragment | None:
        if fragment.op == "near" and fragment.kind() == "pinecone_search":
            return fragment
        if fragment.op in ("and", "or"):
            for child in fragment.children():
                found = self._find_near_child(child)
                if found is not None:
                    return found
        return None

    def _is_pinecone_filter_child(self, fragment: QueryFragment) -> bool:
        if fragment.kind() == "pinecone_filter":
            return True
        if fragment.op in ("and", "or"):
            return all(self._is_pinecone_filter_child(child) for child in fragment.children())
        return False

    def _to_pinecone_filter(self, fragment: QueryFragment) -> dict:
        if fragment.kind() == "pinecone_filter":
            return fragment.payload
        if fragment.op == "and":
            return {"$and": [self._to_pinecone_filter(child) for child in fragment.children()]}
        if fragment.op == "or":
            return {"$or": [self._to_pinecone_filter(child) for child in fragment.children()]}
        raise TypeError(f"Cannot compile {fragment.op!r} to Pinecone filter")

    def _build_filter(self, fragments: list[QueryFragment]) -> dict | None:
        if not fragments:
            return None
        if len(fragments) == 1:
            return self._to_pinecone_filter(fragments[0])
        return {"$and": [self._to_pinecone_filter(f) for f in fragments]}

    def _query(self, index_name: str, near_fragment: QueryFragment, filter_dict: dict | None = None, entity_id: str = "") -> ResultFrame:
        index = self._index(index_name)
        params = near_fragment.payload
        kwargs = {"vector": params["vector"], "top_k": params["top_k"], "include_metadata": True}
        if filter_dict:
            kwargs["filter"] = filter_dict
        res = index.query(**kwargs)
        return ResultFrame.from_rows(self._hit_rows(res, entity_id))

    @backend_locked
    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute Pinecone-native near and filter fragments when possible.

        Args:
            fragment (QueryFragment): Backend-ready query fragment compiled by the handler layer.

        Returns:
            ResultFrame: Matching rows and object identifiers.

        Raises:
            LookupError: If the fragment requires standalone non-near execution.
            NotImplementedError: If a near query carries a non-native filter fragment.
            RuntimeError: If the Pinecone client is unavailable or the provider operation fails.
        """
        entity_id = fragment.entity_id()
        index_name = self._index_name(entity_id) if entity_id else ""
        self._need_client()
        if fragment.op == "near" and fragment.kind() == "pinecone_search" and self._has_index(index_name):
            filt = fragment.filter_fragment()
            if filt is not None and not self._is_pinecone_filter_child(filt):
                raise NotImplementedError(f"Pinecone cannot execute non-native filter fragment {filt.op!r}")
            try:
                return self._query(index_name, fragment, filter_dict=self._to_pinecone_filter(filt) if filt is not None else None, entity_id=entity_id)
            except Exception as exc:
                self._degrade(exc)
        if fragment.op == "and" and entity_id and self._has_index(index_name):
            near_child = self._find_near_child(fragment)
            if near_child is not None:
                other_children = [child for child in fragment.children() if child is not near_child]
                if all(self._is_pinecone_filter_child(child) for child in other_children):
                    filter_dict = self._build_filter(other_children)
                    try:
                        return self._query(index_name, near_child, filter_dict=filter_dict, entity_id=entity_id)
                    except Exception as exc:
                        self._degrade(exc)
        if entity_id and not self._has_index(index_name):
            return ResultFrame.empty()
        raise LookupError(f"Pinecone does not support standalone {fragment.op!r} queries without a near vector query.")

    def to_dict(self) -> dict[str, Any]:
        """Return Pinecone backend metadata and connection state.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend metadata, host, project, and current provider connection
            status.
        """
        return {
            "name": self.name,
            "type": self.type,
            "host": self.host,
            "project": self.project_name,
            "connected": self.client is not None,
            "error": self.client_error,
        }
