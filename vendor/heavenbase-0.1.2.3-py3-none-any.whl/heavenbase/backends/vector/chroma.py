"""ChromaDB vector backend."""

from __future__ import annotations

__all__ = [
    "ChromaBackend",
]

from heavenbase.utils import Any, Iterable, Mapping, Sequence, safe_error

from heavenbase.utils.files import file_uri_to_path, touch_dir
from ...execution.frame.result import ResultFrame
from ...modules import ModuleResolver
from ...schema.model import EntitySchema
from ..base import Backend, backend_locked
from heavenbase.execution.contracts import LOGICAL_OPS, QueryFragment, RowOp

CHROMA_MAX_NAME_LENGTH = 512


class ChromaBackend(Backend):
    """ChromaDB provider adapter with native vector search and metadata filters.

    Uses the Chroma client for persistence, row lookup, native ``near`` search,
    and metadata filtering through provider storage only.
    """

    identifier = "chroma"
    provider_max_name_length = CHROMA_MAX_NAME_LENGTH

    @classmethod
    def from_config(
        cls,
        name: str,
        data: Mapping[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "ChromaBackend":
        """Build the Chroma backend from a config mapping.

        Args:
            name (str): Workspace backend instance name.
            data (Mapping[str, Any]): Backend config mapping. Supported keys are Chroma
                constructor parameters, including ``path`` and ``ws_id``.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.

        Returns:
            ChromaBackend: Configured Chroma backend instance.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        return cls(name, cfg.pop("path", None), ws_id=ws_id, resolver=resolver, config=config, **cfg)

    def __init__(
        self,
        name: str = "chroma",
        path: str | None = None,
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a Chroma backend.

        Args:
            name (str): Workspace backend instance name.
            path (str | None): Optional local persistence directory. Passing ``None`` uses
                Chroma's ephemeral client.
            ws_id (str | None): Optional workspace namespace for Chroma database selection.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.
            **kwargs (Any): Extra keyword arguments passed to the Chroma client. ``database``
                may be supplied to override the workspace-derived database name.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(name, ws_id=ws_id, resolver=resolver, config=config)
        self.path = None if path is None else file_uri_to_path(path, home=self.config.root)
        self._database_override = kwargs.pop("database", None)
        self._client_kwargs = dict(kwargs)
        self.client_error = ""
        self._schemas: dict[str, EntitySchema] = {}
        self._collections: dict[str, str] = {}
        self.database = self._database_name()
        self._connect()

    def _database_name(self) -> str | None:
        return self._database_override or (self._physical_name(self.ws_id) if self.ws_id else None)

    def _connect(self) -> None:
        try:
            import chromadb

            kwargs = dict(self._client_kwargs)
            self.database = self._database_name()
            if self.database:
                self._ensure_database(chromadb, self.database)
                kwargs.setdefault("database", self.database)
            self.client = chromadb.EphemeralClient(**kwargs) if self.path is None else chromadb.PersistentClient(path=touch_dir(self.path), **kwargs)
        except Exception as exc:
            self.client = None
            self.client_error = safe_error(exc)

    def _admin_client(self, chromadb: Any) -> Any:
        admin_cls = getattr(chromadb, "AdminClient", None)
        if admin_cls is None:
            return None
        settings = None
        if self.path is not None:
            from chromadb.config import Settings

            settings = Settings(is_persistent=True, persist_directory=touch_dir(self.path))
        return admin_cls(settings) if settings is not None else admin_cls()

    def _ensure_database(self, chromadb: Any, database: str) -> None:
        try:
            admin = self._admin_client(chromadb)
            if admin is None:
                return
            get_database = getattr(admin, "get_database", None)
            create_database = getattr(admin, "create_database", None)
            if create_database is None:
                return
            if get_database is not None:
                try:
                    get_database(database)
                    return
                except Exception:
                    pass
            try:
                create_database(name=database)
            except TypeError:
                create_database(database)
        except Exception:
            pass

    def _refresh_workspace(self) -> None:
        self._collections.clear()
        self._connect()

    def _delete_collection(self, name: str) -> None:
        if self.client is None:
            return
        delete_collection = getattr(self.client, "delete_collection", None)
        if delete_collection is None:
            return
        try:
            delete_collection(name=name)
        except TypeError:
            delete_collection(name)

    @backend_locked
    def drop(self) -> None:
        """Drop the current Chroma database or known collections.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        try:
            if self.database:
                import chromadb

                admin = self._admin_client(chromadb)
                delete_database = getattr(admin, "delete_database", None) if admin is not None else None
                if delete_database is not None:
                    try:
                        delete_database(name=self.database)
                    except TypeError:
                        delete_database(self.database)
                    return
            for name in list(self._collections.values()):
                self._delete_collection(name)
        finally:
            self._schemas.clear()
            self._collections.clear()
            self.client = None

    def _need_client(self) -> None:
        if self.client is None:
            detail = f": {self.client_error}" if self.client_error else ""
            raise RuntimeError(f"Chroma backend {self.name!r} is unavailable{detail}")

    def _collection_name(self, entity_id: str) -> str:
        return self._collections.setdefault(entity_id, self._physical_name(entity_id))

    def schema_warnings(self, schema: EntitySchema, bindings: Sequence[Any]) -> list[str]:
        """Return Chroma collection-name warnings for this schema.

        Args:
            schema (EntitySchema): Entity schema being registered.
            bindings (Sequence[Any]): Storage bindings for the entity.

        Returns:
            list[str]: Provider naming warnings for physical collection names.
        """
        warnings = super().schema_warnings(schema, bindings)
        warnings.extend(
            self._physical_name_warnings(
                [(schema.entity_id, self._collection_name(schema.entity_id))],
                kind="Chroma collection",
                max_length=self.provider_max_name_length,
                case_sensitive=False,
            )
        )
        return warnings

    def _collection(self, entity_id: str) -> Any:
        name = self._collection_name(entity_id)
        metric = str(self.config.get("heavenbase.backend_defaults.chroma.metric", default="cosine")).lower()
        return self.client.get_or_create_collection(name=name, metadata={"hnsw:space": metric})

    def _vector_field(self, entity_id: str) -> Any:
        schema = self._schemas.get(entity_id)
        if schema is None:
            return None
        return next((field_schema for field_schema in schema.fields.values() if type(field_schema.dtype).identifier == "vector"), None)

    def _metadata(self, entity_id: str, values: dict[str, Any]) -> dict[str, Any]:
        schema = self._schemas.get(entity_id)
        out: dict[str, Any] = {}
        for key, value in values.items():
            if key == "object_id" or value is None:
                continue
            field_schema = schema.fields.get(key) if schema else None
            if field_schema is not None and type(field_schema.dtype).identifier == "array":
                if self._is_metadata_array(value):
                    out[key] = value
                continue
            if not isinstance(value, (str, int, float, bool)):
                continue
            if field_schema is not None and type(field_schema.dtype).identifier in ("json", "hyper-g", "vector"):
                continue
            out[key] = value
        return out or {"_hb": True}

    def _is_metadata_array(self, value: Any) -> bool:
        if not isinstance(value, list) or not value:
            return False
        first_type = type(value[0])
        if first_type not in (str, int, float, bool):
            return False
        return all(type(item) is first_type for item in value)

    def _document(self, values: dict[str, Any], object_id: Any) -> str:
        parts = [str(value) for value in values.values() if isinstance(value, str) and value]
        return "\n".join(parts) or str(object_id)

    @backend_locked
    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Ensure a Chroma collection for the entity.

        Args:
            schema (EntitySchema): Entity schema to store in Chroma.
            bindings (Sequence[Any]): Storage bindings supplied by the workspace.

        Returns:
            None: This function does not return a value.
        """
        self._schemas[schema.entity_id] = schema
        if self.client is None:
            return
        self._collection(schema.entity_id)

    @backend_locked
    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Upsert vectors and metadata into Chroma.

        Args:
            rows (Sequence[RowOp]): Row mutations to apply. ``delete`` operations remove
                documents; other operations upsert document text, metadata, and vectors.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the Chroma client is unavailable.
        """
        self._need_client()
        for entity_id, is_delete, ops in self.ordered_row_op_batches(rows):
            collection = self._collection(entity_id)
            if is_delete:
                collection.delete(ids=[str(row.object_id) for row in ops])
                continue
            values = ops
            vector = self._vector_field(entity_id)
            embeddings = [row.values.get(vector.name) for row in values] if vector is not None else []
            payload = {
                "ids": [str(row.object_id) for row in values],
                "metadatas": [self._metadata(entity_id, row.values) for row in values],
                "documents": [self._document(row.values, row.object_id) for row in values],
            }
            if embeddings and all(value is not None for value in embeddings):
                payload["embeddings"] = embeddings
            collection.upsert(**payload)

    def _rows_from_chroma(
        self,
        entity_id: str,
        object_ids: Sequence[Any],
        metadatas: Sequence[Any] | None = None,
        embeddings: Sequence[Any] | None = None,
        distances: Sequence[Any] | None = None,
    ) -> list[dict[str, Any]]:
        rows = []
        metadatas = metadatas or []
        for pos, object_id in enumerate(object_ids):
            embedding = embeddings[pos] if embeddings is not None and pos < len(embeddings) else None
            row = self._row_from_chroma(entity_id, object_id, metadatas[pos] if pos < len(metadatas) else None, embedding)
            if distances is not None:
                distance = distances[pos] or 0.0
                row["score"] = 1.0 - float(distance)
            rows.append(row)
        return rows

    def _row_from_chroma(self, entity_id: str, object_id: Any, metadata: Any = None, embedding: Any = None) -> dict[str, Any]:
        row = dict(metadata or {})
        row["object_id"] = str(object_id)
        vector = self._vector_field(entity_id)
        if vector is not None and embedding is not None:
            row[vector.name] = embedding.tolist() if hasattr(embedding, "tolist") else list(embedding)
        return row

    @backend_locked
    def scan(self, entity_id: str) -> list[dict[str, Any]]:
        """Return rows from Chroma provider storage.

        Args:
            entity_id (str): Entity identifier whose collection should be scanned.

        Returns:
            list[dict[str, Any]]: Rows reconstructed from Chroma metadata and embeddings.

        Raises:
            RuntimeError: If the client is unavailable or the scan request fails.
        """
        self._need_client()
        try:
            rows = self._collection(entity_id).get(include=["metadatas", "embeddings"])
            return self._rows_from_chroma(entity_id, rows.get("ids", []), rows.get("metadatas") or [], rows.get("embeddings"))
        except Exception as exc:
            self.client_error = safe_error(exc)
            raise RuntimeError(f"Chroma scan failed for {entity_id!r}: {self.client_error}") from exc

    def iter_scan(self, entity_id: str, *, batch_size: int) -> Iterable[dict[str, Any]]:
        """Iterate an unchanged Chroma collection in bounded provider pages.

        Args:
            entity_id (str): Logical entity identifier.
            batch_size (int): Positive maximum page size.

        Yields:
            dict[str, Any]: Row fragment with metadata and embedding.

        Raises:
            ValueError: If the page size is not positive.
            RuntimeError: If the provider read fails.

        Notes:
            Offset enumeration requires a stable collection during the scan.
        """
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")
        offset = 0
        while True:
            with self._lock:
                self._need_client()
                try:
                    page = self._collection(entity_id).get(limit=batch_size, offset=offset, include=["metadatas", "embeddings"])
                    rows = self._rows_from_chroma(entity_id, page.get("ids", []), page.get("metadatas") or [], page.get("embeddings"))
                except Exception as exc:
                    self.client_error = safe_error(exc)
                    raise RuntimeError(f"Chroma iter_scan failed for {entity_id!r}: {self.client_error}") from exc
            if not rows:
                return
            offset += len(rows)
            yield from rows

    @backend_locked
    def get_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[dict[str, Any] | None]:
        """Return rows through Chroma object-id lookup.

        Args:
            entity_id (str): Entity identifier whose rows should be loaded.
            object_ids (Iterable[Any]): Object identifiers to fetch in caller order.

        Returns:
            list[dict[str, Any] | None]: Rows aligned with ``object_ids``. Missing documents
            are returned as ``None``.

        Raises:
            RuntimeError: If the client is unavailable or the lookup request fails.
        """
        ordered_ids = [str(object_id) for object_id in object_ids]
        if not ordered_ids:
            return []
        self._need_client()
        try:
            rows = self._collection(entity_id).get(ids=list(dict.fromkeys(ordered_ids)), include=["metadatas", "embeddings"])
            found_ids = rows.get("ids", [])
            rows_by_id = {
                str(row["object_id"]): row for row in self._rows_from_chroma(entity_id, found_ids, rows.get("metadatas") or [], rows.get("embeddings"))
            }
            return [rows_by_id.get(row_id) for row_id in ordered_ids]
        except Exception as exc:
            self.client_error = safe_error(exc)
            raise RuntimeError(f"Chroma get_many failed for {entity_id!r}: {self.client_error}") from exc

    @backend_locked
    def exists_many(self, entity_id: str, object_ids: Iterable[Any]) -> list[bool]:
        """Return existence flags through Chroma object-id lookup.

        Args:
            entity_id (str): Entity identifier whose rows should be checked.
            object_ids (Iterable[Any]): Object identifiers to check in caller order.

        Returns:
            list[bool]: Existence flags aligned with ``object_ids``.

        Raises:
            RuntimeError: If the client is unavailable or the lookup request fails.
        """
        ordered_ids = [str(object_id) for object_id in object_ids]
        if not ordered_ids:
            return []
        self._need_client()
        try:
            rows = self._collection(entity_id).get(ids=list(dict.fromkeys(ordered_ids)), include=[])
            found = {str(row_id) for row_id in rows.get("ids", [])}
            return [row_id in found for row_id in ordered_ids]
        except Exception as exc:
            self.client_error = safe_error(exc)
            raise RuntimeError(f"Chroma exists_many failed for {entity_id!r}: {self.client_error}") from exc

    @backend_locked
    def count(self, entity_id: str) -> int:
        """Return Chroma collection count without scanning row bodies.

        Args:
            entity_id (str): Entity identifier whose collection should be counted.

        Returns:
            int: Number of stored Chroma documents for the entity.

        Raises:
            RuntimeError: If the client is unavailable or the count request fails.
        """
        self._need_client()
        try:
            return int(self._collection(entity_id).count())
        except Exception as exc:
            self.client_error = safe_error(exc)
            raise RuntimeError(f"Chroma count failed for {entity_id!r}: {self.client_error}") from exc

    def _live_tag_claims(self) -> dict[str, Any]:
        """Return live tag claims derived from Chroma availability.

        Args:
            None.

        Returns:
            dict[str, Any]: Live Backend tag claims.
        """
        return {
            **super()._live_tag_claims(),
            "backend-availability": "ready" if self.client is not None else "unavailable",
        }

    def _is_chroma_fragment(self, fragment: QueryFragment) -> bool:
        if fragment.kind() == "chroma_where":
            return True
        if fragment.op in ("and", "or"):
            return all(self._is_chroma_fragment(child) for child in fragment.children())
        return False

    def _where(self, fragment: QueryFragment) -> dict:
        if fragment.kind() == "chroma_where":
            return fragment.payload
        if fragment.op == "and":
            return {"$and": [self._where(child) for child in fragment.children()]}
        if fragment.op == "or":
            return {"$or": [self._where(child) for child in fragment.children()]}
        raise TypeError(f"Cannot compile {fragment.op!r} to Chroma where")

    @backend_locked
    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute Chroma-native search and filter fragments when possible.

        Args:
            fragment (QueryFragment): Backend-ready query fragment compiled by the handler layer.

        Returns:
            ResultFrame: Matching rows and object identifiers.

        Raises:
            NotImplementedError: If the fragment cannot be executed natively or by scan fallback.
            RuntimeError: If the client is unavailable or the provider request fails.
        """
        entity_id = fragment.entity_id()
        self._need_client()
        if fragment.mode() == "py_scan":
            return super().execute(fragment)
        if entity_id and fragment.kind() == "chroma_search" and fragment.op == "near":
            params = fragment.payload
            filt = fragment.filter_fragment()
            if filt is not None and not self._is_chroma_fragment(filt):
                return super().execute(fragment)
            try:
                kwargs = {"query_embeddings": [params["vector"]], "n_results": params["top_k"], "include": ["distances", "metadatas", "embeddings"]}
                if filt is not None:
                    kwargs["where"] = self._where(filt)
                rows = self._collection(entity_id).query(**kwargs)
                return ResultFrame.from_rows(
                    self._rows_from_chroma(
                        entity_id,
                        rows.get("ids", [[]])[0],
                        (rows.get("metadatas") or [[]])[0],
                        (rows.get("embeddings") or [[]])[0] if rows.get("embeddings") is not None else None,
                        rows.get("distances", [[]])[0],
                    )
                )
            except Exception as exc:
                self.client_error = safe_error(exc)
                raise RuntimeError(f"Chroma query failed for {entity_id!r}: {self.client_error}") from exc
        if entity_id and (fragment.kind() == "chroma_where" or fragment.op in LOGICAL_OPS):
            if not self._is_chroma_fragment(fragment):
                return super().execute(fragment)
            try:
                rows = self._collection(entity_id).get(where=self._where(fragment), include=["metadatas", "embeddings"])
                return ResultFrame.from_rows(self._rows_from_chroma(entity_id, rows.get("ids", []), rows.get("metadatas") or [], rows.get("embeddings")))
            except Exception as exc:
                self.client_error = safe_error(exc)
                raise RuntimeError(f"Chroma filter failed for {entity_id!r}: {self.client_error}") from exc
        raise NotImplementedError(f"Chroma cannot execute fragment {fragment.op!r}")

    def to_dict(self) -> dict[str, Any]:
        """Return Chroma backend metadata and connection state.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend metadata, storage path, database name, and current
            provider connection status.
        """
        return {
            "name": self.name,
            "type": self.type,
            "path": self.path,
            "database": self.database,
            "connected": self.client is not None,
            "error": self.client_error,
        }
