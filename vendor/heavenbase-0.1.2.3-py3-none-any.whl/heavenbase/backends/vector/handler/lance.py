"""LanceDB-native operation compilers."""

from __future__ import annotations

__all__ = [
    "lance_near_handler",
    "lance_filter_handler",
    "register_handlers",
    "register_reasons",
]

from heavenbase.utils import Any

from heavenbase.execution.contracts import HandlerContext
from heavenbase.execution.contracts import QueryFragment
from heavenbase.filters.ops import OP_EQ, OP_NEAR
from heavenbase.strategies import VectorIndex
from heavenbase.types import cosine_score
from heavenbase.execution.handlers.filters import filter_handler, normalize_filter_value

BACKEND_IDENTIFIER = "lance"
LANCE_NATIVE_OPS = {"eq": "=", "ne": "!=", "lt": "<", "lte": "<=", "gt": ">", "gte": ">=", "in": "IN"}
LANCE_SCAN_TYPES = ("array", "json", "hyper-g", "vector")


def _lit(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, (int, float)):
        return repr(value)
    text = str(value).replace("'", "''")
    return f"'{text}'"


def lance_near_handler(field_schema: Any, value: Any, ctx: HandlerContext) -> QueryFragment:
    """Return a LanceDB-native vector near fragment with dimension validation.

    Args:
        field_schema (Any): Routed vector field schema.
        value (Any): Query vector validated against the field dtype.
        ctx (HandlerContext): Selected backend and strategy context.

    Returns:
        QueryFragment: Native LanceDB vector near fragment.

    Raises:
        ValueError: If the query dimension does not match the field dtype.
    """
    query = field_schema.dtype.validate(value)
    expected_dim = getattr(field_schema.dtype, "dim", None)
    if expected_dim is not None and len(query) != expected_dim:
        raise ValueError(f"LanceDB near query dimension mismatch: expected {expected_dim}, got {len(query)}")

    def _payload(row: dict) -> float:
        vec = row.get(field_schema.name)
        return cosine_score(vec, query) if vec is not None else 0.0

    return QueryFragment(
        ctx.backend,
        "near",
        field_schema.name,
        {"vector": query, "top_k": ctx.top_k, "metric": ctx.metric},
        returns=["score"],
        notes={"kind": "lance_search", "mode": "native", "top_k": ctx.top_k, "row_payload": _payload},
    )


def lance_filter_handler(op: str):
    """Return a LanceDB scalar filter handler for one operation.

    Args:
        op (str): Filter operation identifier.

    Returns:
        Callable[[Any, Any, HandlerContext], QueryFragment]: Compiler that
        produces native or scan-marked LanceDB filter fragments.
    """

    def _compile(field_schema: Any, value: Any, ctx: HandlerContext) -> QueryFragment:
        value = normalize_filter_value(field_schema.dtype, op, value, resolver=ctx.resolver)
        py_fragment = filter_handler(op)(field_schema, value, ctx)
        if op not in LANCE_NATIVE_OPS or type(field_schema.dtype).identifier in LANCE_SCAN_TYPES:
            reason = ctx.fallback_reason(op, type(field_schema.dtype).identifier)
            return py_fragment.mark_scan(reason)
        if op == "in":
            payload = f"{field_schema.name} IN ({', '.join(_lit(item) for item in value)})"
        else:
            payload = f"{field_schema.name} {LANCE_NATIVE_OPS[op]} {_lit(value)}"
        return QueryFragment(ctx.backend, op, field_schema.name, payload, notes={"kind": "lance_where", "mode": "native", "row_payload": py_fragment.payload})

    return _compile


def register_reasons(fallback: Any, _unsupported: Any, *, resolver: Any = None) -> None:
    """Register LanceDB-specific fallback reasons.

    Args:
        fallback: Reason registry receiving fallback explanations.
        _unsupported: Unsupported-operation registry (unused for LanceDB).
        resolver (Any | None): Optional module resolver for backend discovery.

    Returns:
        None: Fallback reasons are registered in place.
    """
    fallback.register(BACKEND_IDENTIFIER, "*", "array", "*", "LanceDB does not support Array field native filtering; using Python scan fallback.")
    fallback.register(BACKEND_IDENTIFIER, "*", "json", "*", "LanceDB does not support Json field native filtering; using Python scan fallback.")
    fallback.register(BACKEND_IDENTIFIER, "*", "hyper-g", "*", "LanceDB does not support HyperG field native filtering; using Python scan fallback.")


def register_handlers(registry: Any, ctx: Any) -> None:
    """Register LanceDB-native handlers.

    Args:
        registry: Workspace handler registry receiving descriptors.
        ctx: Shared Registry-derived handler vocabulary.

    Returns:
        None: The supplied workspace registry is updated in place.
    """
    for dtype in ctx.filter_types:
        for strategy in ctx.filter_strategies:
            for op in ctx.filter_ops(dtype):
                ctx.handler(dtype, op, BACKEND_IDENTIFIER, strategy, lance_filter_handler(op)).register(registry, replace=True)
    for dtype in ctx.vector_types:
        ctx.handler(dtype, OP_NEAR, BACKEND_IDENTIFIER, VectorIndex.identifier, lance_near_handler).register(registry, replace=True)
        ctx.handler(dtype, OP_EQ, BACKEND_IDENTIFIER, VectorIndex.identifier, lance_filter_handler(OP_EQ)).register(registry, replace=True)
