"""ChromaDB-native operation compilers."""

from __future__ import annotations

__all__ = [
    "chroma_filter_handler",
    "chroma_near_handler",
    "register_handlers",
    "register_reasons",
]

from heavenbase.utils import Any

from heavenbase.execution.contracts import HandlerContext
from heavenbase.execution.contracts import QueryFragment
from heavenbase.filters.ops import OP_EQ, OP_NEAR
from heavenbase.strategies import InlineColumn, VectorIndex
from heavenbase.types import cosine_score
from heavenbase.execution.handlers.filters import filter_handler, normalize_filter_value

BACKEND_IDENTIFIER = "chroma"
CHROMA_NATIVE_OPS = {"eq": "$eq", "ne": "$ne", "lt": "$lt", "lte": "$lte", "gt": "$gt", "gte": "$gte", "in": "$in"}
CHROMA_SCALAR_TYPES = (str, int, float, bool)
CHROMA_SCAN_TYPES = ("json", "hyper-g", "vector")


def _is_scalar(value: Any) -> bool:
    return isinstance(value, CHROMA_SCALAR_TYPES)


def chroma_near_handler(field_schema: Any, value: Any, ctx: HandlerContext) -> QueryFragment:
    """Return a Chroma-native vector near fragment with dimension validation.

    Args:
        field_schema (Any): Routed vector field schema.
        value (Any): Query vector validated against the field dtype.
        ctx (HandlerContext): Selected backend and strategy context.

    Returns:
        QueryFragment: Native Chroma vector near fragment.

    Raises:
        ValueError: If the query dimension does not match the field dtype.
    """
    query = field_schema.dtype.validate(value)
    expected_dim = getattr(field_schema.dtype, "dim", None)
    if expected_dim is not None and len(query) != expected_dim:
        raise ValueError(f"Chroma near query dimension mismatch: expected {expected_dim}, got {len(query)}")

    def _payload(row: dict) -> float:
        vec = row.get(field_schema.name)
        return cosine_score(vec, query) if vec is not None else 0.0

    return QueryFragment(
        ctx.backend,
        "near",
        field_schema.name,
        {"vector": query, "top_k": ctx.top_k, "metric": ctx.metric},
        returns=["score"],
        notes={"kind": "chroma_search", "mode": "native", "top_k": ctx.top_k, "row_payload": _payload},
    )


def chroma_filter_handler(op: str):
    """Return a Chroma metadata filter handler for one operation.

    Args:
        op (str): Filter operation identifier.

    Returns:
        Callable[[Any, Any, HandlerContext], QueryFragment]: Compiler that
        produces native or scan-marked Chroma metadata fragments.
    """

    def _compile(field_schema: Any, value: Any, ctx: HandlerContext) -> QueryFragment:
        value = normalize_filter_value(field_schema.dtype, op, value, resolver=ctx.resolver)
        py_fragment = filter_handler(op)(field_schema, value, ctx)
        if op == "array_contains" and type(field_schema.dtype).identifier == "array" and _is_scalar(value):
            payload = {field_schema.name: {"$contains": value}}
            return QueryFragment(
                ctx.backend, op, field_schema.name, payload, notes={"kind": "chroma_where", "mode": "native", "row_payload": py_fragment.payload}
            )
        if op not in CHROMA_NATIVE_OPS or type(field_schema.dtype).identifier in (*CHROMA_SCAN_TYPES, "array"):
            reason = ctx.fallback_reason(op, type(field_schema.dtype).identifier)
            return py_fragment.mark_scan(reason)
        if op == "in":
            if not isinstance(value, (list, tuple, set)):
                raise TypeError("in filter expects a list, tuple, or set")
            payload = {field_schema.name: {"$in": list(value)}}
        else:
            payload = {field_schema.name: {CHROMA_NATIVE_OPS[op]: value}}
        return QueryFragment(ctx.backend, op, field_schema.name, payload, notes={"kind": "chroma_where", "mode": "native", "row_payload": py_fragment.payload})

    return _compile


def register_reasons(fallback: Any, _unsupported: Any, *, resolver: Any = None) -> None:
    """Register ChromaDB-specific fallback reasons.

    Args:
        fallback: Reason registry receiving fallback explanations.
        _unsupported: Unsupported-operation registry (unused for ChromaDB).
        resolver (Any | None): Optional module resolver for backend discovery.

    Returns:
        None: Fallback reasons are registered in place.
    """
    fallback.register(BACKEND_IDENTIFIER, "*", "json", "*", "ChromaDB does not support Json field native filtering; using Python scan fallback.")
    fallback.register(BACKEND_IDENTIFIER, "*", "hyper-g", "*", "ChromaDB does not support HyperG field native filtering; using Python scan fallback.")
    fallback.register(BACKEND_IDENTIFIER, "*", "vector", InlineColumn.identifier, f"ChromaDB requires {VectorIndex.__name__} strategy for vector operations.")


def register_handlers(registry: Any, ctx: Any) -> None:
    """Register ChromaDB-native handlers.

    Args:
        registry: Workspace handler registry receiving descriptors.
        ctx: Shared Registry-derived handler vocabulary.

    Returns:
        None: The supplied workspace registry is updated in place.
    """
    for dtype in ctx.filter_types:
        for strategy in ctx.filter_strategies:
            for op in ctx.filter_ops(dtype):
                ctx.handler(dtype, op, BACKEND_IDENTIFIER, strategy, chroma_filter_handler(op)).register(registry, replace=True)
    for dtype in ctx.vector_types:
        ctx.handler(dtype, OP_NEAR, BACKEND_IDENTIFIER, VectorIndex.identifier, chroma_near_handler).register(registry, replace=True)
        ctx.handler(dtype, OP_EQ, BACKEND_IDENTIFIER, VectorIndex.identifier, chroma_filter_handler(OP_EQ)).register(registry, replace=True)
