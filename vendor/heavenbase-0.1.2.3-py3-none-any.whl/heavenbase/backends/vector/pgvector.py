"""PgVector backend: PostgreSQL storage selected as a vector backend type."""

from __future__ import annotations

__all__ = [
    "PgVectorBackend",
]

from heavenbase.utils import Any, Mapping, Sequence

from ...execution.frame.result import ResultFrame
from ...modules import ModuleResolver
from ...schema.model import EntitySchema
from heavenbase.execution.contracts import QueryFragment
from ..base import backend_locked
from ..sql._scoped import ScopedSQLTableMixin
from ..sql.capabilities import register_sql_dialect
from ..sql.dialect import SQLDialectSpec
from ..sql.base import SQLBackend, _sa_col
from ..sql.postgres import PostgresBackend
from ..sql._utils import default_database


def _pgvector_col(dtype: Any, dialect_spec: Any, *, max_chars: int) -> Any:
    if type(dtype).identifier != "vector":
        return _sa_col(dtype, dialect_spec, max_chars=max_chars)
    from pgvector.sqlalchemy import Vector as PgVectorType

    return PgVectorType(dtype.dim)


class PgVectorBackend(ScopedSQLTableMixin, PostgresBackend):
    """PostgreSQL backend with pgvector-native near search."""

    identifier = "pgvector"
    aliases = ()

    @classmethod
    def from_config(
        cls,
        name: str,
        data: Mapping[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "PgVectorBackend":
        """Build the PgVector backend from a config mapping.

        Args:
            name (str): Workspace backend instance name.
            data (Mapping[str, Any]): Backend config mapping. Supported keys are inherited
                PostgreSQL constructor parameters, plus ``database``, ``ws_id``, and
                ``shared_database``.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.

        Returns:
            PgVectorBackend: Configured pgvector backend instance.

        Raises:
            TypeError: If ``shared_database`` is not Boolean.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        shared_database = cfg.pop("shared_database", False)
        db = cfg.pop("database", None) or default_database(ws_id, cfg) or "postgres"
        return cls(
            name,
            db,
            ws_id=ws_id,
            shared_database=shared_database,
            resolver=resolver,
            config=config,
            **cfg,
        )

    def __init__(
        self,
        name: str = "pgvector",
        database: str | None = None,
        ws_id: str | None = None,
        *,
        shared_database: bool = False,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a PostgreSQL backend with pgvector-native near search.

        Args:
            name (str): Workspace backend instance name.
            database (str | None): PostgreSQL database name or configured database route.
            ws_id (str | None): Optional workspace namespace for database materialization.
            shared_database (bool): Keep ``database`` fixed and scope physical tables by
                workspace and backend name instead of creating a workspace database.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.
            **kwargs (Any): Additional PostgreSQL backend constructor options.

        Returns:
            None: This function does not return a value.

        Raises:
            TypeError: If ``shared_database`` is not Boolean.
        """
        if not isinstance(shared_database, bool):
            raise TypeError("PgVector shared_database must be Boolean")
        self.shared_database = shared_database
        super().__init__(name, database, ws_id=ws_id, resolver=resolver, config=config, **kwargs)
        self.type = "pgvector"

    def _construction_tag_claims(self) -> dict[str, Any]:
        """Overlay the physical namespace contract selected at construction."""
        return {
            **super()._construction_tag_claims(),
            "workspace-database-namespace": not self.shared_database,
        }

    def _uses_workspace_database(self) -> bool:
        """Use the configured database when shared table scoping is enabled."""
        return False if self.shared_database else super()._uses_workspace_database()

    def _table_name(self, entity_id: str) -> str:
        """Return a scoped or database-local main-table name."""
        if self.shared_database:
            return ScopedSQLTableMixin._table_name(self, entity_id)
        return SQLBackend._table_name(self, entity_id)

    def _side_table_name(self, entity_id: str, field_name: str) -> str:
        """Return a scoped or database-local side-table name."""
        if self.shared_database:
            return ScopedSQLTableMixin._side_table_name(self, entity_id, field_name)
        return SQLBackend._side_table_name(self, entity_id, field_name)

    def _refresh_workspace(self) -> None:
        """Refresh the selected database or shared table scope."""
        if self.shared_database:
            ScopedSQLTableMixin._refresh_workspace(self)
        else:
            SQLBackend._refresh_workspace(self)

    def _install_strategy_adapters(self) -> None:
        """Keep shared pgvector databases free of global strategy tables."""
        if self.shared_database:
            self._strategy_adapters.clear()
        else:
            SQLBackend._install_strategy_adapters(self)

    @backend_locked
    def drop(self) -> None:
        """Drop only this backend's tables in shared-database mode.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        if not self.shared_database:
            SQLBackend.drop(self)
            return
        if self.db is None:
            return
        try:
            self._drop_owned_tables(self.db)
        finally:
            self.db.close()
            self._reset_storage_state()
            self.db = None

    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Ensure the pgvector extension and vector-capable SQL table.

        Args:
            schema (EntitySchema): Entity schema to store in PostgreSQL.
            bindings (Sequence[Any]): Storage bindings supplied by the workspace.

        Returns:
            None: This function does not return a value.
        """
        if schema.entity_id in self.tables:
            return
        from ...types import Identifier
        from sqlalchemy import Column, Table

        owned_fields = {binding.field_name for binding in bindings if binding.backend == self.name}
        self.db.execute("CREATE EXTENSION IF NOT EXISTS vector", readonly=False)
        max_chars = self._sql_long_text_max_chars
        cols = [Column("object_id", _sa_col(Identifier(), self.db.dialect_spec, max_chars=max_chars), primary_key=True)]
        for field_schema in schema.fields.values():
            if field_schema.name != "object_id" and field_schema.name in owned_fields:
                cols.append(
                    Column(
                        field_schema.name,
                        _pgvector_col(field_schema.dtype, self.db.dialect_spec, max_chars=max_chars),
                        nullable=not field_schema.required,
                    )
                )
        table = Table(self._table_name(schema.entity_id), self.metadata, *cols, extend_existing=True)
        self.tables[schema.entity_id] = table
        self.db.create_table(table)
        self._sync_columns(table)

    def _distance(self, column: Any, query: list, metric: str) -> Any:
        metric = (metric or "cosine").lower()
        if metric in ("l2", "euclidean"):
            return column.l2_distance(query)
        if metric in ("ip", "inner", "inner_product"):
            return column.max_inner_product(query)
        return column.cosine_distance(query)

    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute pgvector near fragments or delegate to SQL execution.

        Args:
            fragment (QueryFragment): Backend-ready query fragment compiled by the handler layer.

        Returns:
            ResultFrame: Matching rows and object identifiers.
        """
        if fragment.kind() == "pgvector_search" and fragment.op == "near":
            entity_id = fragment.entity_id()
            table = self.tables.get(entity_id) if entity_id else None
            if table is None:
                return ResultFrame.empty()
            filt = fragment.filter_fragment()
            if filt is not None and not self._is_sql_fragment(filt):
                return super().execute(fragment)
            from sqlalchemy import select

            params = fragment.payload
            dist = self._distance(table.c[fragment.field], params["vector"], params.get("metric", "cosine")).label("_distance")
            stmt = select(*self._select_cols(entity_id, table), dist).order_by(dist).limit(params["top_k"])
            if filt is not None:
                stmt = stmt.where(self._where(filt, table, entity_id))
            rows = self.db.orm_execute(stmt, readonly=True).to_dicts()
            for row in rows:
                distance = row.pop("_distance", 0.0) or 0.0
                row["score"] = 1.0 - distance if (params.get("metric") or "cosine").lower() == "cosine" else -distance
            return ResultFrame.from_rows(self._decode_side_rows(entity_id, rows))
        return super().execute(fragment)
