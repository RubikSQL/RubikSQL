"""Shared SQLAlchemy backend over :class:`heavenbase.database.Database`."""

from __future__ import annotations

__all__ = [
    "SQLBackend",
]

from heavenbase.utils import Any, Dict, Iterable, List, Optional, Sequence
from heavenbase.utils import dataclass
from heavenbase.utils.files import delete_file, file_uri_to_path
from heavenbase.utils.hash import md5hash
from heavenbase.utils.serialize import loads_json

from ...execution.frame.result import ResultFrame
from ...database.config import DBEngine
from ...modules import ModuleResolver
from ...strategies import SideTable
from ...schema.model import EntitySchema
from ...types import LongText
from ...types.storage import stores_as_integer
from ...database.dialect.spec import DatabaseDialectSpec
from ...utils.ids import sql_index_name
from ..base import Backend, backend_locked
from heavenbase.execution.contracts import LOGICAL_OPS, QueryFragment, RowOp
from .capabilities import register_sql_dialect, sql_dialect_spec
from .dialect import SQLDialectSpec
from ._utils import default_database


def _sa_col(dtype: Any, dialect_spec: DatabaseDialectSpec | None = None, *, max_chars: int = 65535):
    from heavenbase.database.types import (
        DatabaseBigIntegerType,
        DatabaseBlobType,
        DatabaseBooleanType,
        DatabaseIntegerType,
        DatabaseJsonType,
        DatabaseTextType,
        DatabaseVectorType,
    )
    from sqlalchemy import Float

    identifier = type(dtype).identifier
    if identifier == "categorical":
        return DatabaseIntegerType() if dtype.base == "integer" else DatabaseTextType(length=dtype.max_chars, dialect_spec=dialect_spec, max_chars=max_chars)
    if identifier in ("timestamp", "duration"):
        return DatabaseBigIntegerType()
    if identifier == "date":
        return DatabaseTextType(length=dtype.max_chars, dialect_spec=dialect_spec, max_chars=max_chars)
    if identifier in ("identifier", "short-text", "medium-text", "long-text"):
        return DatabaseTextType(length=dtype.max_chars, dialect_spec=dialect_spec, max_chars=max_chars)
    if identifier == "integer":
        return DatabaseIntegerType()
    if identifier == "float":
        return Float()
    if identifier == "boolean":
        return DatabaseBooleanType()
    if identifier == "artifact":
        return DatabaseBlobType(dialect_spec=dialect_spec, max_chars=max_chars)
    if identifier == "vector":
        return DatabaseVectorType(dialect_spec=dialect_spec, max_chars=max_chars)
    return DatabaseJsonType(dialect_spec=dialect_spec, max_chars=max_chars)


def _table_name(entity_id: str) -> str:
    return Backend._physical_name(entity_id)


def _side_table_name(entity_id: str, field_name: str) -> str:
    return f"{_table_name(entity_id)}_{field_name}"


def _side_present_column(field_name: str) -> str:
    """Return the parent-table column recording whether a side field was set.

    A side table holds one row per item, so an absent value and an empty list
    both store nothing and read back the same. This column keeps the difference.
    The leading underscore cannot collide with a declared field: `check_py_name`
    rejects those names.

    Args:
        field_name (str): Side-routed field name.

    Returns:
        str: Physical marker column name.
    """
    return f"_present_{field_name}"


def _norm_cols(cols: Iterable[Any]) -> tuple[str, ...]:
    return tuple(str(getattr(col, "name", col)).lower() for col in cols)


def _index_already_exists_error(exc: Exception) -> bool:
    """Return whether a provider reported the desired existing-index state."""
    message = str(exc).lower()
    original = getattr(exc, "orig", None)
    args = getattr(original, "args", ())
    return "already exists" in message or "duplicate key name" in message or (bool(args) and args[0] == 1061)


_HYPERG_INDEX_TYPES = {"identifier", "short-text", "integer", "float", "categorical", "timestamp", "duration", "date"}


def _batches(values: Sequence[Any], size: int) -> Iterable[Sequence[Any]]:
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


@dataclass
class _SideTableSpec:
    field_schema: Any
    table: Any

    @property
    def name(self) -> str:
        """Return the source field name for this side table."""
        return self.field_schema.name

    @property
    def dtype_identifier(self) -> str:
        """Return the logical type identifier stored in this side table."""
        return type(self.field_schema.dtype).identifier

    def rows(self, object_id: Any, value: Any) -> list[dict[str, Any]]:
        """Lower an Array or HyperG value into side-table row dictionaries.

        Args:
            object_id: Owner row object id.
            value: Logical field value to decompose into side-table rows.

        Returns:
            list[dict[str, Any]]: Backend-ready side-table row dictionaries.

        Raises:
            TypeError: If the side-table field logical type is unsupported.
            ValueError: If the value is not list-shaped.
        """
        items = value or []
        if not isinstance(items, list):
            raise ValueError(f"{self.name} SideTable expects a list")
        if self.dtype_identifier == "array":
            return [self._array_row(object_id, idx, item) for idx, item in enumerate(items)]
        if self.dtype_identifier == "hyper-g":
            return [self._hyperg_row(object_id, idx, item) for idx, item in enumerate(items)]
        raise TypeError(f"SideTable does not support {self.dtype_identifier}")

    def group(self, records: Any) -> Dict[Any, list]:
        """Group side-table records back by owning ``object_id``.

        Args:
            records: SQLAlchemy result records from the side table.

        Returns:
            Dict[Any, list]: Side-table values grouped by owner object id.
        """
        grouped: Dict[Any, list] = {}
        for record in records:
            data = record._mapping
            grouped.setdefault(data["object_id"], []).append(self._value(data))
        return grouped

    def select_cols(self) -> list[Any]:
        """Return SQL columns needed to rebuild this side-table field.

        Args:
            None.

        Returns:
            list[Any]: SQLAlchemy columns required for reconstruction.
        """
        if self.dtype_identifier == "array":
            return [self.table.c.object_id, self.table.c.idx, self.table.c.item]
        return [self.table.c.object_id, self.table.c.idx, *[self.table.c[field.name] for field in self.field_schema.dtype.fields]]

    def order_cols(self) -> list[Any]:
        """Return stable ordering columns for side-table scans.

        Args:
            None.

        Returns:
            list[Any]: SQLAlchemy columns used for deterministic side-table ordering.
        """
        return [self.table.c.object_id, self.table.c.idx]

    def json_expr(self, main_table: Any, dialect: str, *, resolver: ModuleResolver) -> Any:
        """Return a correlated JSON aggregation expression for SELECT projection.

        Args:
            main_table: SQLAlchemy table for the owning entity.
            dialect: SQL dialect identifier used to resolve JSON expression metadata.
            resolver: Module authority that owns the SQL dialect record.

        Returns:
            Any: SQLAlchemy scalar subquery labeled with the logical field name.
        """
        from sqlalchemy import select

        dialect_spec = sql_dialect_spec(dialect, resolver=resolver)
        payload = (
            self.table.c.item
            if self.dtype_identifier == "array"
            else dialect_spec.side_table_json_object_expression(tuple((field.name, self.table.c[field.name]) for field in self.field_schema.dtype.fields))
        )
        aggregate = dialect_spec.side_table_json_agg_expression(payload, self.table.c.idx)
        stmt = select(aggregate).where(self.table.c.object_id == main_table.c.object_id)
        return stmt.scalar_subquery().label(self.name)

    def decode(self, value: Any) -> list:
        """Decode a projected JSON value back to a Python list.

        Args:
            value: Projected aggregate value from a SQL SELECT.

        Returns:
            list: Decoded logical field value.
        """
        if value in (None, ""):
            return []
        data = value if isinstance(value, list) else loads_json(value)
        return data if self.dtype_identifier == "array" else [self._value(item) for item in data]

    def _side_row_id(self, object_id: Any, idx: int) -> str:
        return str(md5hash([self.table.name, object_id, idx]))

    def _array_row(self, object_id: Any, idx: int, item: Any) -> dict[str, Any]:
        return {"_id": self._side_row_id(object_id, idx), "object_id": object_id, "idx": idx, "item": item}

    def _hyperg_row(self, object_id: Any, idx: int, item: Any) -> dict[str, Any]:
        return {"_id": self._side_row_id(object_id, idx), "object_id": object_id, "idx": idx, **self._hyperg_item(item)}

    def _hyperg_item(self, item: Any) -> dict[str, Any]:
        data = self.field_schema.dtype.validate([item])[0]
        return {field.name: data.get(field.name) for field in self.field_schema.dtype.fields}

    def _value(self, data: Any) -> Any:
        if self.dtype_identifier == "array":
            return data["item"]
        out = {}
        for field in self.field_schema.dtype.fields:
            value = data.get(field.name)
            if value is None and not field.required:
                continue
            out[field.name] = loads_json(value) if type(field.dtype).identifier == "json" and isinstance(value, str) else value
        return out


class SQLBackend(Backend):
    """SQLAlchemy backend using HeavenBase ``Database`` for connection lifecycle.

    Args:
        name: Workspace backend instance name.
        provider: SQLAlchemy provider or dialect identifier.
        database: Optional database name, URL, or local database path.
        identifier: Optional HeavenBase backend type identifier. Defaults to ``provider``.
        ws_id: Optional workspace namespace.
        **kwargs: Provider-specific database connection options.
    """

    identifier = "sql"
    sql_name_warning_provider: str | None = None
    sql_reserved_words: Sequence[str] = ()
    sql_max_identifier_length: int | None = None

    @classmethod
    def from_config(
        cls,
        name: str,
        data: dict[str, Any],
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
    ) -> "SQLBackend":
        """Build a SQL backend from a config mapping.

        Args:
            name: Workspace backend instance name.
            data: Backend config mapping. Supports ``provider``, ``database``, optional
                ``ws_id``, and provider-specific database connection options.
            resolver: Context-owned module authority.
            config: Config authority used for backend defaults and database resolution.

        Returns:
            SQLBackend: Configured SQL backend instance.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        provider = str(cfg.pop("provider", "sqlite") or "sqlite").lower()
        database = default_database(ws_id, cfg)
        return cls(
            name,
            provider=provider,
            database=database,
            identifier=provider,
            ws_id=ws_id,
            resolver=resolver,
            config=config,
            **cfg,
        )

    def __init__(
        self,
        name: str = "sql",
        provider: str = "sqlite",
        database: str | None = None,
        identifier: str | None = None,
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
        config_engine: DBEngine | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a SQL backend instance.

        Args:
            name: Workspace backend instance name.
            provider: SQLAlchemy provider or dialect identifier.
            database: Optional database name, URL, or local database path.
            identifier: Optional HeavenBase backend type identifier. Defaults to ``provider``.
            ws_id: Optional workspace namespace.
            resolver: Context-owned module authority.
            config: Config authority used for backend defaults and database resolution.
            config_engine: Explicit database policy engine used by control-plane bootstrap.
            **kwargs: Provider-specific database connection options.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(name, ws_id=ws_id, resolver=resolver, config=config)
        from sqlalchemy import MetaData

        self._sql_id_lookup_batch_size = max(
            1,
            int(self._construction_config_get("heavenbase.backend_defaults.sql.id_lookup.batch_size", default=500)),
        )
        self._sql_long_text_max_chars = LongText.default_max_chars
        kwargs = self._database_config(dict(kwargs))
        self.provider = provider
        self.type = identifier or provider
        self._database_override = database
        self._database_config_engine = config_engine
        self._db_kwargs = dict(kwargs)
        self.database = self._database_name()
        self.db = None
        self.metadata = MetaData()
        self.tables: Dict[str, Any] = {}
        self._side_specs: Dict[str, Dict[str, _SideTableSpec]] = {}
        self._connect_database()
        # Standalone SQL backends resolve through the documented process
        # default and can install their adapters immediately.  The sole
        # deferred case is a Context control backend carrying config before
        # its ModuleService has been constructed.
        if self._module_resolver is not None or self._config is None:
            self._install_strategy_adapters()

    def _finalize_bootstrap_resolver(self, resolver: ModuleResolver) -> None:
        """Finalize control-plane resolver authority without rebuilding SQL state."""
        super()._finalize_bootstrap_resolver(resolver)
        if self.db is not None:
            self.db._finalize_bootstrap_resolver(resolver)
        if not self._strategy_adapters:
            self._install_strategy_adapters()

    def _database_config(self, values: dict[str, Any]) -> dict[str, Any]:
        """Return provider database values after backend-bound default resolution."""
        return values

    def _uses_workspace_database(self) -> bool:
        if not self.ws_id:
            return False
        if self._module_resolver is None and self._config is not None:
            if self._database_config_engine is None:
                raise RuntimeError("Direct SQL control bootstrap requires an explicit database config engine")
            value = self._database_config_engine.bootstrap_backend_tag("workspace-database-namespace", False)
        else:
            result = self.tag("workspace-database-namespace")
            value = False if result is None else result.value
        if not isinstance(value, bool):
            raise TypeError("Backend tag 'workspace-database-namespace' must be Boolean")
        return value

    def _database_name(self) -> str | None:
        if self._uses_workspace_database():
            return self._physical_name(self.ws_id)
        if self._database_override:
            return self._database_override
        return self._physical_name(self.ws_id) if self.ws_id else None

    def _connect_database(self) -> None:
        from heavenbase.database import Database

        self.database = self._database_name()
        kwargs = dict(self._db_kwargs)
        self.db = Database(
            database=self.database,
            provider=self.provider,
            resolver=self._module_resolver,
            config=self.config,
            config_engine=self._database_config_engine,
            **kwargs,
        )

    def _install_strategy_adapters(self) -> None:
        from .strategies import SQLSparseGramAdapter

        self._strategy_adapters.clear()
        SQLSparseGramAdapter(self).register()

    def _need_db(self) -> None:
        if self.db is None:
            raise RuntimeError(f"SQL backend {self.name!r} is unavailable after drop")

    @backend_locked
    def _refresh_workspace(self) -> None:
        next_database = self._database_name()
        if next_database == self.database:
            return
        self._reset_storage_state()
        self._connect_database()
        self._install_strategy_adapters()

    def _reset_storage_state(self) -> None:
        from sqlalchemy import MetaData

        self.metadata = MetaData()
        self.tables.clear()
        self._side_specs.clear()
        for adapter in self._strategy_adapters.values():
            adapter.reset()
        self._strategy_adapters.clear()

    def _delete_file_sidecars(self, database: str | None) -> None:
        if not database:
            return
        database = file_uri_to_path(database)
        for suffix in ("-wal", "-shm"):
            delete_file(f"{database}{suffix}")

    @backend_locked
    def drop(self) -> None:
        """Drop the current SQL workspace namespace.

        Args:
            None.

        Returns:
            None: This function does not return a value.

        Notes:
            Dialects without database-drop support fall back to dropping reflected tables.
        """
        if self.db is None:
            return
        from heavenbase.database import DatabaseEngineRegistry, drop_database

        spec = self.db.spec
        try:
            if spec.in_memory or not spec.database or not spec.dialect_spec.supports("database-drop"):
                self.db.drop()
                self.db.dispose()
            else:
                self.db.dispose()
                try:
                    drop_database(spec)
                except Exception:
                    # If server-side drop_database fails (e.g. missing superuser
                    # credentials), allow a fresh engine for the same existing
                    # database and fall back to dropping reflected tables.
                    DatabaseEngineRegistry.clear_disposed(spec, authority_id=self.db._authority_id)
                    self.db.drop()
                    self.db.dispose()
                if spec.dialect_spec.supports("database-local-path"):
                    self._delete_file_sidecars(spec.database)
        finally:
            self._reset_storage_state()
            self.db = None

    def _my_bindings(self, bindings: Sequence[Any]) -> Sequence[Any]:
        return [b for b in bindings if b.backend == self.name]

    def _column_type(self, dtype: Any) -> Any:
        """Return this backend's physical SQLAlchemy type for a logical type."""
        return _sa_col(
            dtype,
            self.db.dialect_spec if self.db is not None else None,
            max_chars=self._sql_long_text_max_chars,
        )

    def _column_constraints(self, name: str, dtype: Any) -> tuple[Any, ...]:
        """Return provider-owned constraints for one physical column."""
        return ()

    def _column(self, name: str, dtype: Any, *, primary_key: bool = False, nullable: bool = True) -> Any:
        """Build one SQLAlchemy column through provider-owned physical hooks."""
        from sqlalchemy import Column

        return Column(name, self._column_type(dtype), *self._column_constraints(name, dtype), primary_key=primary_key, nullable=nullable)

    def _table_name(self, entity_id: str) -> str:
        """Return the provider-owned physical main-table name."""
        return _table_name(entity_id)

    def _side_table_name(self, entity_id: str, field_name: str) -> str:
        """Return the provider-owned physical side-table name."""
        return _side_table_name(entity_id, field_name)

    def _table_args(self, *, order_by: Sequence[str]) -> tuple[Any, ...]:
        """Return provider-owned positional SQLAlchemy table arguments."""
        return ()

    def _side_table_fields(self, bindings: Sequence[Any]) -> Sequence[Any]:
        return [b for b in self._my_bindings(bindings) if b.strategy == SideTable.identifier]

    def _main_table_fields(self, bindings: Sequence[Any]) -> Sequence[Any]:
        return [b for b in self._my_bindings(bindings) if b.strategy != SideTable.identifier]

    def _adapter_fields(self, schema: EntitySchema, bindings: Sequence[Any]) -> Sequence[Any]:
        return [
            binding
            for binding in self._my_bindings(bindings)
            if (adapter := self._strategy_adapters.get(binding.strategy)) is not None and adapter.supports(schema, binding)
        ]

    def _sql_name_warning_rules(self) -> tuple[int | None, set[str], bool]:
        """Return SQL identifier warning rules: max length, reserved words, and case sensitivity."""
        dialect = getattr(getattr(self.db, "engine", None), "dialect", None) if self.db is not None else None
        max_length, reserved = self.db.dialect_spec.name_warning_rules(
            dialect=dialect,
            extra_reserved=self.sql_reserved_words,
        )
        if self.sql_max_identifier_length is not None:
            max_length = self.sql_max_identifier_length
        return max_length, reserved, False

    def schema_warnings(self, schema: EntitySchema, bindings: Sequence[Any]) -> List[str]:
        """Return optional SQL physical-name warnings for this schema.

        Args:
            schema: Entity schema being registered.
            bindings: Storage bindings routed to this backend.

        Returns:
            List[str]: User-facing warnings about SQL table or column names.
        """
        warnings = super().schema_warnings(schema, bindings)
        max_length, reserved, case_sensitive = self._sql_name_warning_rules()
        table_names = [
            (entity_id, table.name) for entity_id, table in self.tables.items() if entity_id != schema.entity_id and not self._is_internal_entity_id(entity_id)
        ]
        table_names.append((schema.entity_id, self._table_name(schema.entity_id)))
        table_names.extend(
            (f"{schema.entity_id}.{binding.field_name}", self._side_table_name(schema.entity_id, binding.field_name))
            for binding in self._side_table_fields(bindings)
        )
        warnings.extend(self._physical_name_warnings(table_names, kind="SQL table", max_length=max_length, reserved=reserved, case_sensitive=case_sensitive))
        main_field_names = {"object_id", *{binding.field_name for binding in self._main_table_fields(bindings)}}
        column_names = [(field_name, field_name) for field_name in sorted(main_field_names)]
        warnings.extend(
            self._physical_name_warnings(
                column_names,
                kind=f"SQL column for {schema.entity_id!r}",
                max_length=max_length,
                reserved=reserved,
                case_sensitive=case_sensitive,
            )
        )
        return warnings

    @backend_locked
    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Ensure main and side-table SQL storage for an entity.

        Args:
            schema: Entity schema being registered.
            bindings: Storage bindings routed to this backend.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
            TypeError: If a SideTable binding uses an unsupported logical type.
        """
        self._need_db()
        main_bindings = self._main_table_fields(bindings)
        side_bindings = self._side_table_fields(bindings)
        main_field_names = {b.field_name for b in main_bindings}

        if schema.entity_id not in self.tables:
            from ...types import Identifier
            from sqlalchemy import Table

            object_id = schema.fields.get("object_id")
            object_id_type = object_id.dtype if object_id is not None else Identifier()
            cols = [self._column("object_id", object_id_type, primary_key=True, nullable=False)]
            for field_schema in schema.fields.values():
                if field_schema.name != "object_id" and field_schema.name in main_field_names:
                    cols.append(self._column(field_schema.name, field_schema.dtype, nullable=not field_schema.required))
            table = Table(
                self._table_name(schema.entity_id),
                self.metadata,
                *cols,
                *self._table_args(order_by=("object_id",)),
                extend_existing=True,
            )
            self.tables[schema.entity_id] = table
            self.db.create_table(table)
            self._append_side_present_columns(table, side_bindings)
            self._sync_columns(table)
        else:
            table = self.tables[schema.entity_id]
            self._append_missing_columns(table, schema, main_field_names)
            self._append_side_present_columns(table, side_bindings)
            self._sync_columns(table)
        self._ensure_main_indexes(table, schema, main_field_names)

        for binding in side_bindings:
            field_schema = schema.get(binding.field_name)
            self._side_specs.setdefault(schema.entity_id, {})[field_schema.name] = self._side_spec(schema.entity_id, field_schema)
        if side_bindings:
            self.db.create_tables([spec.table for spec in self._side_specs.get(schema.entity_id, {}).values()])
            for spec in self._side_specs.get(schema.entity_id, {}).values():
                self._ensure_side_indexes(spec)

        for binding in self._adapter_fields(schema, bindings):
            adapter = self._strategy_adapters.get(binding.strategy)
            if adapter is not None:
                adapter.ensure(schema, binding)

    def _side_spec(self, entity_id: str, field_schema: Any) -> _SideTableSpec:
        from ...types import Identifier
        from sqlalchemy import Column, Integer, Table

        st_name = self._side_table_name(entity_id, field_schema.name)
        table = self.metadata.tables.get(st_name)
        if table is not None:
            return _SideTableSpec(field_schema, table)
        cols = [
            self._column("_id", Identifier(), primary_key=True, nullable=False),
            self._column("object_id", Identifier(), nullable=False),
        ]
        if type(field_schema.dtype).identifier == "array":
            item_dtype = getattr(field_schema.dtype, "item_type", None)
            cols.extend(
                [
                    Column("idx", Integer(), nullable=False),
                    self._column("item", item_dtype if item_dtype is not None else field_schema.dtype, nullable=False),
                ]
            )
        elif type(field_schema.dtype).identifier == "hyper-g":
            cols.append(Column("idx", Integer(), nullable=False))
            cols.extend([self._column(field.name, field.dtype, nullable=not field.required) for field in field_schema.dtype.fields])
        else:
            raise TypeError(f"SideTable does not support {type(field_schema.dtype).identifier}")
        table = Table(
            st_name,
            self.metadata,
            *cols,
            *self._table_args(order_by=("object_id", "idx")),
            extend_existing=True,
        )
        return _SideTableSpec(field_schema, table)

    def _add_index(self, table: Any, *cols: Any, unique: bool = False) -> str:
        from sqlalchemy import Index

        col_names = _norm_cols(cols)
        role = ("unique",) if unique else ()
        name = sql_index_name(table.name, *role, *[col.name for col in cols])
        if not col_names or all(getattr(col, "primary_key", False) for col in cols):
            return name
        declared_names = {str(index.name) for index in table.indexes}
        reflected = self.db.table_indexes(table)
        reflected_names = {str(item.get("name") or "") for item in reflected}
        if name in declared_names or name in reflected_names:
            return name
        external_covering = [
            item for item in reflected if _norm_cols(item.get("column_names") or []) == col_names and not str(item.get("name") or "").startswith("ix_")
        ]
        if unique:
            if any(item.get("unique") for item in external_covering):
                return name
        elif external_covering:
            return name
        options = sql_dialect_spec(self.type, resolver=self.module_resolver).unique_index_options(tuple(cols)) if unique else {}
        Index(name, *cols, unique=unique, **options)
        return name

    def _server_index_column_sets(self, table: Any) -> dict[tuple[str, ...], bool]:
        return self.db.index_column_sets(table)

    def _create_indexes(self, table: Any) -> None:
        """Create declared indexes despite incomplete provider reflection."""
        from sqlalchemy.exc import SQLAlchemyError

        existing = self.db.index_column_sets(table)
        for index in sorted(table.indexes, key=lambda item: str(item.name)):
            columns = _norm_cols(index.columns)
            satisfied = existing.get(columns, False) if index.unique else columns in existing
            if satisfied:
                continue
            try:
                self.db.create_index(index, checkfirst=True)
            except SQLAlchemyError as exc:
                if not _index_already_exists_error(exc):
                    raise
            existing[columns] = bool(index.unique)

    def _ensure_main_indexes(self, table: Any, schema: EntitySchema, field_names: set[str]) -> None:
        if "control-plane" in schema.tags:
            return
        if not self.scalar_index().value:
            return
        for field_schema in schema.fields.values():
            if (
                field_schema.name != "object_id"
                and field_schema.name in field_names
                and type(field_schema.dtype).identifier in ("identifier", "short-text", "integer", "float")
            ):
                self._add_index(table, table.c[field_schema.name])
        self._create_indexes(table)

    @backend_locked
    def ensure_indexes(self, schema: EntitySchema, storage_plan: Any) -> None:
        """Create and reconcile resolved main-table scalar indexes.

        Args:
            schema: Entity schema owning the SQL table.
            storage_plan: Resolved storage, index, and constraint plan.

        Returns:
            None: The server matches the resolved Heaven-owned index set.
        """
        if not self.scalar_index().value or schema.entity_id not in self.tables:
            return
        table = self.tables[schema.entity_id]
        desired: set[str] = set()
        for binding in storage_plan.backend_indexes(self.name):
            desired.add(self._add_index(table, *[table.c[name] for name in binding.fields]))
        for binding in storage_plan.backend_constraints(self.name):
            desired.add(self._add_index(table, *[table.c[name] for name in binding.fields], unique=True))
        self._create_indexes(table)
        for reflected in self.db.table_indexes(table):
            name = str(reflected.get("name") or "")
            if name.startswith("ix_") and len(name) == 45 and name not in desired:
                self.db.drop_index(table, name, reflected.get("column_names") or [])
                for index in list(table.indexes):
                    if index.name == name:
                        table.indexes.discard(index)

    def _ensure_side_indexes(self, spec: _SideTableSpec) -> None:
        self._add_index(spec.table, spec.table.c.object_id)
        if spec.dtype_identifier == "array":
            self._add_index(spec.table, spec.table.c.object_id, spec.table.c.idx)
            self._add_index(spec.table, spec.table.c.item, spec.table.c.object_id)
        if spec.dtype_identifier == "hyper-g":
            self._add_index(spec.table, spec.table.c.object_id, spec.table.c.idx)
            fields = [field for field in spec.field_schema.dtype.filterable_fields if type(field.dtype).identifier in _HYPERG_INDEX_TYPES]
            for field in fields:
                self._add_index(spec.table, spec.table.c[field.name], spec.table.c.object_id)
            if fields:
                self._add_index(spec.table, *[spec.table.c[field.name] for field in fields[:3]], spec.table.c.object_id)
        self._create_indexes(spec.table)

    def _append_missing_columns(self, table: Any, schema: EntitySchema, allowed_field_names: set[str]) -> None:
        for field_schema in schema.fields.values():
            if field_schema.name != "object_id" and field_schema.name in allowed_field_names and field_schema.name not in table.c:
                table.append_column(self._column(field_schema.name, field_schema.dtype, nullable=not field_schema.required))

    def _append_side_present_columns(self, table: Any, side_bindings: Sequence[Any]) -> None:
        """Attach one presence marker per side-routed field to the main table.

        Args:
            table (Any): Main SQLAlchemy table for the entity.
            side_bindings (Sequence[Any]): Bindings routed to a side table.

        Returns:
            None.
        """
        from sqlalchemy import Column, Integer

        for binding in side_bindings:
            name = _side_present_column(binding.field_name)
            if name not in table.c:
                table.append_column(Column(name, Integer(), nullable=True))

    def _sync_columns(self, table: Any) -> None:
        existing = set(self.db.columns(table.name, schema=table.schema))
        missing = [column for column in table.c if column.name not in existing]
        for column in missing:
            self.db.add_table_col(table, column)

    @backend_locked
    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Apply row mutations to SQL main tables and side tables.

        Args:
            rows: Backend row mutations. Upserts replace main-table row fragments and
                side-table rows; deletes remove both.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        from sqlalchemy import delete, insert

        with self.db.tx():
            for entity_id, is_delete, batch in self.ordered_row_op_batches(rows):
                table = self.tables[entity_id]
                self.db.orm_execute(delete(table).where(table.c.object_id.in_([row.object_id for row in batch])), readonly=False)
                if not is_delete:
                    side_names = tuple(self._side_specs.get(entity_id, {}))
                    payloads = []
                    for row in batch:
                        payload = row.to_row(fields=table.c.keys())
                        # the side table cannot tell an absent value from an empty
                        # list, so the main row carries the distinction
                        for field_name in side_names:
                            payload[_side_present_column(field_name)] = 0 if row.values.get(field_name) is None else 1
                        payloads.append(payload)
                    self.db.orm_execute(insert(table), payloads, readonly=False)

            for row in rows:
                for field_name, spec in self._side_specs.get(row.entity_id, {}).items():
                    self.db.orm_execute(delete(spec.table).where(spec.table.c.object_id == row.object_id), readonly=False)
                    if row.is_upsert():
                        side_rows = spec.rows(row.object_id, row.values.get(field_name) or [])
                        if side_rows:
                            self.db.orm_execute(insert(spec.table), side_rows, readonly=False)
            for adapter in self._strategy_adapters.values():
                adapter.upsert(rows)

    @backend_locked
    def scan(self, entity_id: str) -> list[dict[str, Any]]:
        """Return all rows for one SQL-backed entity.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            list[dict[str, Any]]: Decoded row fragments ordered by ``object_id``.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        if entity_id not in self.tables:
            return []
        from sqlalchemy import select

        table = self.tables[entity_id]
        rows = self.db.orm_execute(select(*self._select_cols(entity_id, table)).order_by(table.c.object_id), readonly=True).to_dicts()
        rows = self._decode_side_rows(entity_id, rows)
        rows.sort(key=lambda row: str(row.get("object_id")))
        return rows

    def iter_scan(self, entity_id: str, *, batch_size: int) -> Iterable[dict[str, Any]]:
        """Iterate SQL rows by bounded primary-key pages.

        Args:
            entity_id (str): Logical entity identifier.
            batch_size (int): Positive page size.

        Yields:
            dict[str, Any]: Decoded row fragment in database primary-key order.

        Raises:
            ValueError: If the page size is not positive.
            RuntimeError: If storage is unavailable.

        Notes:
            Keyset pagination avoids OFFSET growth. Concurrent external writes
            are not a snapshot; use an immutable source version when caching.
        """
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")
        from sqlalchemy import select

        last_id = None
        while True:
            with self._lock:
                self._need_db()
                if entity_id not in self.tables:
                    return
                table = self.tables[entity_id]
                stmt = select(*self._select_cols(entity_id, table)).order_by(table.c.object_id).limit(batch_size)
                if last_id is not None:
                    stmt = stmt.where(table.c.object_id > last_id)
                rows = self._decode_side_rows(entity_id, self.db.orm_execute(stmt, readonly=True).to_dicts())
            if not rows:
                return
            last_id = rows[-1]["object_id"]
            yield from rows

    @backend_locked
    def get_many(self, entity_id: str, object_ids: Iterable[Any]) -> List[Optional[Dict[str, Any]]]:
        """Return rows with batched ``WHERE object_id IN (...)`` lookups.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to read.

        Returns:
            List[Optional[Dict[str, Any]]]: Decoded row fragments aligned to ``object_ids``.
                Missing rows are ``None``.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        ordered_ids = list(object_ids)
        if not ordered_ids or entity_id not in self.tables:
            return [None for _ in ordered_ids]
        from sqlalchemy import select

        table = self.tables[entity_id]
        unique_ids = list(dict.fromkeys(ordered_ids))
        rows_by_id: Dict[Any, Dict[str, Any]] = {}
        for batch in _batches(unique_ids, self._sql_id_lookup_batch_size):
            rows = self.db.orm_execute(select(*self._select_cols(entity_id, table)).where(table.c.object_id.in_(batch)), readonly=True).to_dicts()
            for row in self._decode_side_rows(entity_id, rows):
                rows_by_id[row.get("object_id")] = row
        return [rows_by_id.get(row_id) for row_id in ordered_ids]

    @backend_locked
    def exists_many(self, entity_id: str, object_ids: Iterable[Any]) -> List[bool]:
        """Return existence flags using only the SQL object_id column.

        Args:
            entity_id: Logical entity identifier.
            object_ids: Object ids to test.

        Returns:
            List[bool]: Boolean flags aligned to ``object_ids``.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        ordered_ids = list(object_ids)
        if not ordered_ids or entity_id not in self.tables:
            return [False for _ in ordered_ids]
        from sqlalchemy import select

        table = self.tables[entity_id]
        found = set()
        for batch in _batches(list(dict.fromkeys(ordered_ids)), self._sql_id_lookup_batch_size):
            found.update(self.db.orm_execute(select(table.c.object_id).where(table.c.object_id.in_(batch)), readonly=True).column(0))
        return [row_id in found for row_id in ordered_ids]

    @backend_locked
    def count(self, entity_id: str) -> int:
        """Return row count without scanning SQL rows into Python.

        Args:
            entity_id: Logical entity identifier.

        Returns:
            int: Count of rows in the SQL table, or ``0`` when the entity is unknown.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        if entity_id not in self.tables:
            return 0
        from sqlalchemy import func, select

        table = self.tables[entity_id]
        return int(self.db.orm_execute(select(func.count()).select_from(table), readonly=True).scalar() or 0)

    def _select_cols(self, entity_id: str, table: Any) -> list[Any]:
        return [
            *list(table.c),
            *[spec.json_expr(table, self.db.dialect, resolver=self.module_resolver) for spec in self._side_specs.get(entity_id, {}).values()],
        ]

    def _decode_side_rows(self, entity_id: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for row in rows:
            for field_name, spec in self._side_specs.get(entity_id, {}).items():
                # a row written before this column existed has no marker; treat it
                # as present so stored values keep reading exactly as they did
                present = row.pop(_side_present_column(field_name), None)
                row[field_name] = None if present == 0 else spec.decode(row.get(field_name))
        return rows

    def _is_sql_fragment(self, fragment: QueryFragment) -> bool:
        if fragment.kind() in ("sql_where", "sql_array_contains", "sql_array_exact", "sql_hyperg_exists", "sql_hyperg_all"):
            return True
        if fragment.op in ("and", "or"):
            return all(self._is_sql_fragment(child) for child in fragment.children())
        if fragment.op == "not":
            return self._is_sql_fragment(fragment.children()[0])
        return False

    def _can_scan_fragment(self, fragment: QueryFragment) -> bool:
        """Return whether every leaf exposes a portable row predicate."""
        if fragment.op in LOGICAL_OPS:
            return all(self._can_scan_fragment(child) for child in fragment.children())
        if fragment.notes.get("strategy_adapter"):
            # Adapter-owned execution may apply strategy-specific normalization
            # that a generic row predicate cannot reproduce.
            return False
        if callable(fragment.notes.get("row_payload")):
            return True
        return fragment.mode() == "py_scan" and callable(fragment.payload)

    def _where(self, fragment: QueryFragment, table: Any, entity_id: str) -> Any:
        from sqlalchemy import and_, not_, or_

        if fragment.kind() == "sql_where":
            return fragment.payload(table)
        if fragment.kind() == "sql_array_contains":
            from sqlalchemy import exists, select

            field_name = fragment.field
            value = fragment.payload["value"]
            spec = self._side_specs.get(entity_id, {}).get(field_name)
            if spec is None or spec.dtype_identifier != "array":
                raise RuntimeError(f"No side table for {field_name}")
            return exists(select(1).where((spec.table.c.object_id == table.c.object_id) & (spec.table.c.item == value)))
        if fragment.kind() == "sql_array_exact":
            from sqlalchemy import exists, false, func, select

            field_name = fragment.field
            spec = self._side_specs.get(entity_id, {}).get(field_name)
            if spec is None or spec.dtype_identifier != "array":
                raise RuntimeError(f"No side table for {field_name}")

            def exact(candidate: Any) -> Any:
                """Return a SQL predicate for exact array equality.

                Args:
                    candidate: Candidate array value to compare with side-table rows.

                Returns:
                    Any: SQLAlchemy predicate matching rows whose side-table values exactly
                    equal ``candidate`` by length and ordinal item values.
                """
                if not isinstance(candidate, list):
                    return false()
                predicates = [
                    select(func.count()).where(spec.table.c.object_id == table.c.object_id).scalar_subquery() == len(candidate),
                ]
                for idx, item in enumerate(candidate):
                    predicates.append(
                        exists(
                            select(1).where(
                                (spec.table.c.object_id == table.c.object_id)
                                & (spec.table.c.idx == idx)
                                & (spec.table.c.item.is_(None) if item is None else spec.table.c.item == item)
                            )
                        )
                    )
                return and_(*predicates)

            if fragment.op == "in":
                clauses = [exact(candidate) for candidate in fragment.payload.get("values", [])]
                return or_(*clauses) if clauses else false()
            condition = exact(fragment.payload.get("value"))
            return not_(condition) if fragment.op == "ne" else condition
        if fragment.kind() == "sql_hyperg_exists":
            from sqlalchemy import exists, select

            field_name = fragment.field
            spec = self._side_specs.get(entity_id, {}).get(field_name)
            if spec is None or spec.dtype_identifier != "hyper-g":
                raise RuntimeError(f"No side table for {field_name}")
            predicates = [spec.table.c.object_id == table.c.object_id]
            for hyperg_field, ops in fragment.payload["predicates"].items():
                col = spec.table.c[hyperg_field]
                predicates.extend(self._hyperg_sql_predicate(col, op, value) for op, value in ops.items())
            return exists(select(1).where(and_(*predicates)))
        if fragment.kind() == "sql_hyperg_all":
            from sqlalchemy import exists, select

            field_name = fragment.field
            spec = self._side_specs.get(entity_id, {}).get(field_name)
            if spec is None or spec.dtype_identifier != "hyper-g":
                raise RuntimeError(f"No side table for {field_name}")
            predicates = [spec.table.c.object_id == table.c.object_id]
            for hyperg_field, ops in fragment.payload["where"].items():
                col = spec.table.c[hyperg_field]
                predicates.extend(self._hyperg_sql_predicate(col, op, value) for op, value in ops.items())
            failed = []
            for hyperg_field, ops in fragment.payload["then"].items():
                col = spec.table.c[hyperg_field]
                failed.extend(self._hyperg_sql_predicate(col, op, value) for op, value in ops.items())
            return not_(exists(select(1).where(and_(*predicates, not_(and_(*failed))))))
        if fragment.op == "and":
            return and_(*[self._where(child, table, entity_id) for child in fragment.children()])
        if fragment.op == "or":
            return or_(*[self._where(child, table, entity_id) for child in fragment.children()])
        if fragment.op == "not":
            return not_(self._where(fragment.children()[0], table, entity_id))
        raise TypeError(f"Cannot compile {fragment.op!r} to SQL")

    def _hyperg_sql_predicate(self, col: Any, op: str, value: Any) -> Any:
        from sqlalchemy import and_, false, or_

        if op == "eq":
            return col.is_(None) if value is None else and_(col.is_not(None), col == value)
        if op == "ne":
            return col.is_not(None) if value is None else or_(col.is_(None), col != value)
        if op == "lt":
            return and_(col.is_not(None), col < value)
        if op == "lte":
            return and_(col.is_not(None), col <= value)
        if op == "gt":
            return and_(col.is_not(None), col > value)
        if op == "gte":
            return and_(col.is_not(None), col >= value)
        if op == "in":
            values = list(value)
            non_null = [item for item in values if item is not None]
            clauses = []
            if non_null:
                clauses.append(col.in_(non_null))
            if any(item is None for item in values):
                clauses.append(col.is_(None))
            return or_(*clauses) if clauses else false()
        raise ValueError(f"Unsupported SQL HyperG predicate op {op}")

    @backend_locked
    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute SQL-native fragments or fall back to scanning.

        Args:
            fragment: Compiled query fragment.

        Returns:
            ResultFrame: Rows matched by SQL pushdown, strategy adapter execution, or
                portable scanning fallback.

        Raises:
            RuntimeError: If the backend has been dropped and not reconnected.
        """
        self._need_db()
        if fragment.kind() == "sql_aggregate":
            entity_id = fragment.entity_id()
            table = self.tables.get(entity_id) if entity_id else None
            if table is None:
                return ResultFrame.from_table(fragment.payload.get("empty_rows", ()), cols=fragment.payload.get("columns", ()))
            where_fragment = fragment.payload.get("where")
            where_clause = self._where(where_fragment, table, entity_id) if where_fragment is not None else None
            statement = fragment.payload["build"](table, where_clause)
            rows = self.db.orm_execute(statement, readonly=True).to_dicts()
            for row in rows:
                for name, cast in fragment.payload.get("casts", {}).items():
                    if row.get(name) is not None:
                        row[name] = int(row[name]) if cast == "int" else float(row[name])
            return ResultFrame.from_table(rows, cols=fragment.payload["columns"])
        adapter = self.strategy_adapter_for_fragment(fragment)
        if adapter is not None:
            return adapter.execute(fragment)
        if fragment.kind() in ("sql_where", "sql_array_contains", "sql_array_exact", "sql_hyperg_exists", "sql_hyperg_all") or fragment.op in LOGICAL_OPS:
            entity_id = fragment.entity_id()
            table = self.tables.get(entity_id) if entity_id else None
            if table is None:
                return ResultFrame.empty()
            if fragment.op in LOGICAL_OPS and fragment.uses_scan() and self._can_scan_fragment(fragment):
                # Evaluate the complete boolean tree against one exhaustive row
                # snapshot when every leaf exposes a portable predicate, so
                # built-in mixed trees do not need one scan per child.
                return super().execute(fragment)
            if not self._is_sql_fragment(fragment):
                if fragment.op in LOGICAL_OPS:
                    return fragment.execute(
                        self.execute, lambda item_entity_id: ResultFrame.from_rows(self.scan(item_entity_id)) if item_entity_id else ResultFrame.empty()
                    )
                return super().execute(fragment)
            from sqlalchemy import select

            stmt = select(*self._select_cols(entity_id, table)).where(self._where(fragment, table, entity_id)).order_by(table.c.object_id)
            rows = self._decode_side_rows(entity_id, self.db.orm_execute(stmt, readonly=True).to_dicts())
            rows.sort(key=lambda row: str(row.get("object_id")))
            return ResultFrame.from_rows(rows)
        return super().execute(fragment)

    def to_dict(self) -> dict[str, Any]:
        """Return SQL backend metadata.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend name, backend type, provider, and active database.
        """
        return {"name": self.name, "type": self.type, "provider": self.provider, "database": self.database}
