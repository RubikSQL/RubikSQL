"""StarRocks backend over the MySQL wire protocol."""

from __future__ import annotations

__all__ = [
    "StarRocksBackend",
]

from heavenbase.utils import Any, Sequence, safe_error

from ...modules import ModuleResolver
from ...database.resources.sql import SR_CREATE_DATABASE, SR_CREATE_OLAP_TABLE, SR_DROP_TABLE
from ...schema.model import EntitySchema
from ...types.registry import get_logical_type
from ...types.storage import stores_as_integer
from ...utils.ids import check_entity_id
from .base import SQLBackend, _sa_col, _table_name
from ._utils import default_database
from .capabilities import register_sql_dialect
from .dialect import (
    SQL_JSON_AGG_STYLE_ARRAYAGG,
    SQL_REGEX_STYLE_REGEXP_LIKE_CASE_SENSITIVE,
    SQLDialectSpec,
)


def _q(name: str) -> str:
    return f"`{str(name).replace('`', '``')}`"


def _sr_varchar_len(length: Any, config: Any) -> int:
    """Cap StarRocks VARCHAR widths to its configured hard limit."""
    max_len = int(config.get("heavenbase.backend_defaults.starrocks.varchar.max_length", default=65533))
    return min(int(length), max_len)


def _sr_type(dtype: Any, *, config: Any, resolver: ModuleResolver) -> str:
    cls = type(dtype)
    identifier = cls.identifier if "identifier" in cls.__dict__ else get_logical_type(getattr(dtype, "identifier", cls.__name__), resolver=resolver).identifier
    if identifier == "categorical":
        return "BIGINT" if dtype.base == "integer" else f"VARCHAR({_sr_varchar_len(dtype.max_chars, config)})"
    if stores_as_integer(dtype):
        return "BIGINT"
    if identifier == "date":
        return f"VARCHAR({_sr_varchar_len(dtype.max_chars, config)})"
    if identifier in ("identifier", "short-text", "medium-text", "long-text"):
        return f"VARCHAR({_sr_varchar_len(dtype.max_chars, config)})"
    if identifier == "float":
        return "DOUBLE"
    if identifier == "boolean":
        return "BOOLEAN"
    return f"VARCHAR({_sr_varchar_len(65533, config)})"


class StarRocksBackend(SQLBackend):
    """SQL backend for StarRocks using MySQL-compatible connectivity."""

    identifier = "starrocks"
    sql_name_warning_provider = "mysql"

    @classmethod
    def from_config(cls, name: str, data: dict[str, Any], *, resolver: ModuleResolver | None = None, config: Any | None = None) -> "StarRocksBackend":
        """Build the StarRocks backend from a config mapping.

        Args:
            name: Workspace backend instance name.
            data: Backend config mapping. Supports ``database``, optional ``ws_id``, and
                database connection options.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.

        Returns:
            StarRocksBackend: Configured StarRocks backend instance.
        """
        cfg = dict(data or {})
        ws_id = cfg.pop("ws_id", None)
        return cls(name, default_database(ws_id, cfg), ws_id=ws_id, resolver=resolver, config=config, **cfg)

    def __init__(
        self,
        name: str = "starrocks",
        database: str | None = None,
        ws_id: str | None = None,
        *,
        resolver: ModuleResolver | None = None,
        config: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a StarRocks SQL backend.

        Args:
            name: Workspace backend instance name.
            database: StarRocks database name or configured database route.
            ws_id: Optional workspace namespace used to derive workspace database names.
            resolver: Context-owned module authority.
            config: Config authority retained by the backend.
            **kwargs: Additional database connection options forwarded to ``SQLBackend``.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(name, "mysql", database, identifier="starrocks", ws_id=ws_id, resolver=resolver, config=config, **kwargs)

    def _database_config(self, values: dict[str, Any]) -> dict[str, Any]:
        """Resolve StarRocks connection defaults from this backend's config authority."""
        values.setdefault("driver", self._construction_config_get("heavenbase.backend_defaults.starrocks.driver", default="pymysql"))
        values.setdefault("host", self._construction_config_get("heavenbase.backend_defaults.starrocks.host", default="localhost"))
        values.setdefault("port", int(self._construction_config_get("heavenbase.backend_defaults.starrocks.port", default=9030)))
        values.setdefault("username", self._construction_config_get("heavenbase.backend_defaults.starrocks.username", default="root"))
        values.setdefault("password", self._construction_config_get("heavenbase.backend_defaults.starrocks.password", default=""))
        values.setdefault(
            "params",
            self._construction_config_get("heavenbase.backend_defaults.starrocks.params", default={"charset": "utf8mb4"}),
        )
        self._fallback_database = self._construction_config_get("heavenbase.backend_defaults.starrocks.database", default="heavenbase")
        self.client_error = ""
        return values

    def _database_name(self) -> str | None:
        database = self._database_override or (self._physical_name(self.ws_id) if self.ws_id else None) or self._fallback_database
        return check_entity_id(database) if database else None

    def _connect_database(self) -> None:
        database = self._database_name()
        try:
            self._ensure_database(database, self._db_kwargs)
        except Exception as exc:
            self.client_error = safe_error(exc)
        super()._connect_database()

    def _ensure_database(self, database: str | None, kwargs: dict) -> None:
        if not database:
            return
        from heavenbase.database import Database

        root = Database(provider="mysql", database=None, resolver=self._module_resolver, config=self.config, **kwargs)
        root.execute(SR_CREATE_DATABASE.render(database=_q(database)), readonly=False)

    def ensure(self, schema: EntitySchema, bindings: Sequence[Any]) -> None:
        """Ensure a StarRocks OLAP table for an entity.

        Args:
            schema: Entity schema being registered.
            bindings: Storage bindings routed to this backend. StarRocks stores all entity
                fields in its OLAP table shape.

        Returns:
            None: This function does not return a value.
        """
        if schema.entity_id in self.tables:
            return
        from ...types import Identifier
        from sqlalchemy import Column, Table

        max_chars = self._sql_long_text_max_chars
        cols = [Column("object_id", _sa_col(Identifier(), self.db.dialect_spec, max_chars=max_chars), primary_key=True)]
        for field_schema in schema.fields.values():
            if field_schema.name != "object_id":
                cols.append(
                    Column(
                        field_schema.name,
                        _sa_col(field_schema.dtype, self.db.dialect_spec, max_chars=max_chars),
                        nullable=not field_schema.required,
                    )
                )
        table = Table(_table_name(schema.entity_id), self.metadata, *cols, extend_existing=True)
        self.tables[schema.entity_id] = table
        object_id_len = _sr_varchar_len(
            self.config.get("heavenbase.backend_defaults.starrocks.object_id.max_length", default=Identifier().max_chars),
            self.config,
        )
        ddl_cols = [f"{_q('object_id')} VARCHAR({object_id_len}) NOT NULL"]
        ddl_cols += [
            f"{_q(field_schema.name)} {_sr_type(field_schema.dtype, config=self.config, resolver=self.module_resolver)} "
            f"{'NOT NULL' if field_schema.required else 'NULL'}"
            for field_schema in schema.fields.values()
            if field_schema.name != "object_id"
        ]
        buckets = int(self.config.get("heavenbase.backend_defaults.starrocks.buckets", default=1))
        replication = int(self.config.get("heavenbase.backend_defaults.starrocks.replication_num", default=1))
        ddl = SR_CREATE_OLAP_TABLE.render(
            table=_q(table.name), columns=", ".join(ddl_cols), object_id=_q("object_id"), buckets=buckets, replication=replication
        )
        self.db.execute(ddl, readonly=False)

    def drop(self) -> None:
        """Drop StarRocks tables and dispose the active engine.

        Args:
            None.

        Returns:
            None: This function does not return a value.

        Notes:
            StarRocks external root connections often lack ``DROP DATABASE`` privileges, so
            this provider drops tables individually.
        """
        if self.db is None:
            return
        try:
            if self.database:
                for table in list(self.tables.values()):
                    self.db.execute(SR_DROP_TABLE.render(table=_q(table.name)), readonly=False, safe=True)
        except Exception:
            pass
        self.db.dispose()
        self._reset_storage_state()
        self.db = None

    def to_dict(self) -> dict[str, Any]:
        """Return StarRocks backend metadata and connection state.

        Args:
            None.

        Returns:
            dict[str, Any]: Backend name, type, provider, database, and connection error text.
        """
        return {"name": self.name, "type": self.type, "provider": self.provider, "database": self.database, "error": self.client_error}
