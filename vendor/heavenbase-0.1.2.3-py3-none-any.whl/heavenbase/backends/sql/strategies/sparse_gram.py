"""SQL-hosted sparse-GRAM strategy adapter."""

from __future__ import annotations

__all__ = [
    "SQLSparseGramAdapter",
]

from contextlib import nullcontext

from heavenbase.utils import Any, Iterable, Sequence
from heavenbase.utils.hash import md5hash
from heavenbase.utils.ids import sql_index_name

from ....execution.frame.result import ResultFrame
from ....schema.model import EntitySchema
from ....strategies import SparseGramIndex
from ....types import ShortText
from heavenbase.execution.contracts import LOGICAL_OPS, QueryFragment, RowOp
from ...strategy import StrategyAdapter
from .gram.config import GramConfig
from .gram.runtime import GramKeywordRow, GramRowWrite, contained_in_matches_by_id, contained_in_probe_data, index_keyword_rows


def _batches(values: Sequence[Any], size: int) -> Iterable[Sequence[Any]]:
    for offset in range(0, len(values), size):
        yield values[offset : offset + size]


class _SQLGramIndex:
    """SQL table implementation for the SQL sparse-GRAM adapter."""

    def __init__(self, backend: Any, *, namespace: str, page_size: int = 500) -> None:
        """Create a SQL sparse-GRAM table manager.

        Args:
            backend: Owning SQL backend.
            namespace: Backend/workspace namespace used to isolate index rows.
            page_size: Maximum batch size for bulk reads and writes.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the owning SQL backend has been dropped and has no database.
        """
        from sqlalchemy import MetaData

        if backend.db is None:
            raise RuntimeError(f"SQL backend {backend.name!r} is unavailable after drop")
        self.backend = backend
        self.db = backend.db
        self.namespace = namespace
        self.page_size = max(1, int(page_size))
        self.metadata = MetaData()
        self._define_tables()

    def _define_tables(self) -> None:
        from heavenbase.database.types import DatabaseIntegerType, DatabaseTextType
        from sqlalchemy import Column, Index, Table

        dialect_spec = getattr(self.db, "dialect_spec", None)

        def text_id() -> Any:
            """Return the SQL type used for sparse-GRAM identifiers.

            Args:
                None.

            Returns:
                Any: Database text type sized for identifiers and hashes.
            """
            return DatabaseTextType(length=191, dialect_spec=dialect_spec)

        def text_long() -> Any:
            """Return the SQL type used for sparse-GRAM long text payloads.

            Args:
                None.

            Returns:
                Any: Database text type sized for keywords and masks.
            """
            return DatabaseTextType(length=65535, dialect_spec=dialect_spec)

        self.meta = Table(
            "hb_gram_meta",
            self.metadata,
            Column("ns", text_id(), primary_key=True),
            Column("key", text_id(), primary_key=True),
            Column("value", text_long(), nullable=False),
            extend_existing=True,
        )
        self.keywords = Table(
            "hb_gram_keywords",
            self.metadata,
            Column("ns", text_id(), nullable=False),
            Column("keyword_id", text_id(), primary_key=True),
            Column("entity_id", text_id(), nullable=False),
            Column("field_name", text_id(), nullable=False),
            Column("object_id", text_id(), nullable=False),
            Column("ordinal", DatabaseIntegerType(), nullable=False),
            Column("keyword", text_long(), nullable=False),
            Column("keyword_norm", text_long(), nullable=False),
            Column("keyword_len", DatabaseIntegerType(), nullable=True),
            Column("normalizer", text_id(), nullable=False),
            Column("full_mask", text_long(), nullable=False),
            Column("part_count", DatabaseIntegerType(), nullable=True),
            extend_existing=True,
        )
        self.postings = Table(
            "hb_gram_postings",
            self.metadata,
            Column("_id", text_id(), primary_key=True),
            Column("ns", text_id(), nullable=False),
            Column("entity_id", text_id(), nullable=False),
            Column("field_name", text_id(), nullable=False),
            Column("gram_hash", text_id(), nullable=False),
            Column("keyword_id", text_id(), nullable=False),
            Column("mask_bit", text_long(), nullable=False),
            extend_existing=True,
        )
        Index(sql_index_name(self.keywords.name, "ns", "entity_id", "field_name"), self.keywords.c.ns, self.keywords.c.entity_id, self.keywords.c.field_name)
        Index(sql_index_name(self.keywords.name, "object"), self.keywords.c.ns, self.keywords.c.entity_id, self.keywords.c.object_id)
        Index(
            sql_index_name(self.postings.name, "lookup"),
            self.postings.c.ns,
            self.postings.c.entity_id,
            self.postings.c.field_name,
            self.postings.c.gram_hash,
        )
        Index(sql_index_name(self.postings.name, "keyword"), self.postings.c.ns, self.postings.c.keyword_id)

    def ensure(self) -> None:
        """Prepare sparse-GRAM metadata, keyword, and posting tables.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        tables = [self.meta, self.keywords, self.postings]
        self.db.create_tables(tables)
        self._sync_columns(self.keywords)
        for table in tables:
            self.db.create_missing_indexes(table)

    def _sync_columns(self, table: Any) -> None:
        existing = set(self.db.columns(table.name, schema=table.schema))
        for column in table.c:
            if column.name not in existing:
                self.db.add_table_col(table, column)

    def _tx(self) -> Any:
        return nullcontext(self.db) if self.db.in_transaction() else self.db.tx()

    def set_meta(self, key: str, value: str) -> None:
        """Persist one namespace metadata value.

        Args:
            key: Metadata key within this sparse-GRAM namespace.
            value: Metadata value to store.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete, insert

        with self._tx():
            self.db.orm_execute(delete(self.meta).where((self.meta.c.ns == self.namespace) & (self.meta.c.key == key)), readonly=False)
            self.db.orm_execute(insert(self.meta).values(ns=self.namespace, key=key, value=value), readonly=False)

    def get_meta(self, key: str) -> str | None:
        """Return one namespace metadata value.

        Args:
            key: Metadata key within this sparse-GRAM namespace.

        Returns:
            str | None: Stored metadata value, or ``None`` when absent.
        """
        from sqlalchemy import select

        value = self.db.orm_execute(select(self.meta.c.value).where((self.meta.c.ns == self.namespace) & (self.meta.c.key == key)), readonly=True).scalar()
        return None if value is None else str(value)

    def upsert_rows(self, rows: Sequence[GramRowWrite]) -> None:
        """Replace sparse-GRAM keyword and posting rows in batches.

        Args:
            rows: Row write payloads containing keyword and posting records.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete, insert, select

        writes_by_key: dict[tuple[str, str], GramRowWrite] = {}
        for item in rows:
            writes_by_key[(str(item.entity_id), str(item.object_id))] = GramRowWrite(
                str(item.entity_id),
                str(item.object_id),
                item.row,
                item.keywords,
                item.postings,
            )
        writes = list(writes_by_key.values())
        if not writes:
            return

        object_ids_by_entity: dict[str, list[str]] = {}
        keyword_records: list[dict[str, Any]] = []
        posting_records: list[dict[str, Any]] = []
        for item in writes:
            object_ids_by_entity.setdefault(item.entity_id, []).append(item.object_id)
            keyword_records.extend(self._keyword_record(keyword) for keyword in item.keywords)
            posting_records.extend(self._posting_record(posting) for posting in item.postings)

        with self._tx():
            old_ids: list[str] = []
            for entity_id, object_ids in object_ids_by_entity.items():
                for batch in _batches(list(dict.fromkeys(object_ids)), self.page_size):
                    old_ids.extend(
                        str(keyword_id)
                        for keyword_id in self.db.orm_execute(
                            select(self.keywords.c.keyword_id).where(
                                (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.object_id.in_(batch))
                            ),
                            readonly=True,
                        ).column(0)
                    )
            self._delete_postings(old_ids)
            for entity_id, object_ids in object_ids_by_entity.items():
                for batch in _batches(list(dict.fromkeys(object_ids)), self.page_size):
                    self.db.orm_execute(
                        delete(self.keywords).where(
                            (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.object_id.in_(batch))
                        ),
                        readonly=False,
                    )
            for batch in _batches(keyword_records, self.page_size):
                self.db.orm_execute(insert(self.keywords), list(batch), readonly=False)
            for batch in _batches(posting_records, self.page_size):
                self.db.orm_execute(insert(self.postings), list(batch), readonly=False)

    def replace_field_rows(self, entity_id: str, field_name: str, rows: Sequence[GramRowWrite]) -> None:
        """Replace all keyword and posting rows for one entity field.

        Args:
            entity_id: Entity identifier whose field index should be replaced.
            field_name: Field name whose sparse-GRAM rows should be replaced.
            rows: Replacement row write payloads.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete, insert, select

        entity_id = str(entity_id)
        field_name = str(field_name)
        keyword_records: list[dict[str, Any]] = []
        posting_records: list[dict[str, Any]] = []
        for item in rows:
            keyword_records.extend(
                self._keyword_record(keyword) for keyword in item.keywords if str(keyword.entity_id) == entity_id and str(keyword.field_name) == field_name
            )
            posting_records.extend(
                self._posting_record(posting)
                for posting in item.postings
                if str(posting["entity_id"]) == entity_id and str(posting["field_name"]) == field_name
            )

        with self._tx():
            old_ids = [
                str(keyword_id)
                for keyword_id in self.db.orm_execute(
                    select(self.keywords.c.keyword_id).where(
                        (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.field_name == field_name)
                    ),
                    readonly=True,
                ).column(0)
            ]
            self._delete_postings(old_ids)
            self.db.orm_execute(
                delete(self.keywords).where(
                    (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.field_name == field_name)
                ),
                readonly=False,
            )
            for batch in _batches(keyword_records, self.page_size):
                self.db.orm_execute(insert(self.keywords), list(batch), readonly=False)
            for batch in _batches(posting_records, self.page_size):
                self.db.orm_execute(insert(self.postings), list(batch), readonly=False)

    def delete_objects(self, entity_id: str, object_ids: Iterable[str]) -> None:
        """Delete objects from sparse-GRAM keyword and posting tables.

        Args:
            entity_id: Entity identifier whose object rows should be removed.
            object_ids: Object identifiers to delete.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete, select

        ordered_ids = list(dict.fromkeys(str(object_id) for object_id in object_ids))
        if not ordered_ids:
            return
        with self._tx():
            old_ids: list[str] = []
            for batch in _batches(ordered_ids, self.page_size):
                old_ids.extend(
                    str(keyword_id)
                    for keyword_id in self.db.orm_execute(
                        select(self.keywords.c.keyword_id).where(
                            (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.object_id.in_(batch))
                        ),
                        readonly=True,
                    ).column(0)
                )
            self._delete_postings(old_ids)
            for batch in _batches(ordered_ids, self.page_size):
                self.db.orm_execute(
                    delete(self.keywords).where(
                        (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.object_id.in_(batch))
                    ),
                    readonly=False,
                )

    def delete_field(self, entity_id: str, field_name: str) -> None:
        """Delete all sparse-GRAM index rows for one entity field.

        Args:
            entity_id: Entity identifier whose field index should be removed.
            field_name: Field name to remove from the sparse-GRAM index.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete, select

        with self._tx():
            keyword_ids = [
                str(keyword_id)
                for keyword_id in self.db.orm_execute(
                    select(self.keywords.c.keyword_id).where(
                        (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.field_name == field_name)
                    ),
                    readonly=True,
                ).column(0)
            ]
            self._delete_postings(keyword_ids)
            self.db.orm_execute(
                delete(self.keywords).where(
                    (self.keywords.c.ns == self.namespace) & (self.keywords.c.entity_id == entity_id) & (self.keywords.c.field_name == field_name)
                ),
                readonly=False,
            )

    def lookup_candidates(self, entity_id: str, field_name: str, gram_hashes: Iterable[str]) -> list[GramKeywordRow]:
        """Return keyword candidates whose gram mask is covered by query grams.

        Args:
            entity_id: Entity identifier to search.
            field_name: Sparse-GRAM indexed field name.
            gram_hashes: Query gram hashes.

        Returns:
            list[GramKeywordRow]: Candidate keyword rows whose full mask is covered by
            the query grams.
        """
        from sqlalchemy import func, select

        hashes = list(dict.fromkeys(str(gram_hash) for gram_hash in gram_hashes))
        if not hashes:
            return []
        if len(hashes) > self.page_size:
            return self._lookup_candidates_mask(entity_id, field_name, hashes)
        cols = self._keyword_cols()
        join_expr = self.postings.join(self.keywords, (self.postings.c.ns == self.keywords.c.ns) & (self.postings.c.keyword_id == self.keywords.c.keyword_id))
        rows = self.db.orm_execute(
            select(*cols)
            .select_from(join_expr)
            .where(
                (self.postings.c.ns == self.namespace)
                & (self.postings.c.entity_id == entity_id)
                & (self.postings.c.field_name == field_name)
                & (self.postings.c.gram_hash.in_(hashes))
            )
            .group_by(*cols)
            .having(func.count(func.distinct(self.postings.c.mask_bit)) == self.keywords.c.part_count),
            readonly=True,
        ).to_dicts()
        out = [self._keyword_row(row) for row in rows]
        out.sort(key=lambda item: (item.object_id, item.field_name, item.ordinal, item.keyword_id))
        return out

    def posting_count(self, entity_id: str | None = None, field_name: str | None = None) -> int:
        """Return posting row count, optionally scoped to one entity field.

        Args:
            entity_id: Optional entity identifier to filter by.
            field_name: Optional field name to filter by.

        Returns:
            int: Posting row count for this namespace and optional scope.
        """
        from sqlalchemy import func, select

        stmt = select(func.count()).select_from(self.postings).where(self.postings.c.ns == self.namespace)
        if entity_id is not None:
            stmt = stmt.where(self.postings.c.entity_id == entity_id)
        if field_name is not None:
            stmt = stmt.where(self.postings.c.field_name == field_name)
        return int(self.db.orm_execute(stmt, readonly=True).scalar() or 0)

    def posting_hits(self, entity_id: str, field_name: str, gram_hashes: Iterable[str]) -> int:
        """Return posting rows hit by query gram hashes.

        Args:
            entity_id: Entity identifier to search.
            field_name: Sparse-GRAM indexed field name.
            gram_hashes: Query gram hashes.

        Returns:
            int: Number of posting rows hit by the query grams.
        """
        from sqlalchemy import func, select

        hashes = list(dict.fromkeys(str(gram_hash) for gram_hash in gram_hashes))
        if not hashes:
            return 0
        total = 0
        for batch in _batches(hashes, self.page_size):
            total += int(
                self.db.orm_execute(
                    select(func.count())
                    .select_from(self.postings)
                    .where(
                        (self.postings.c.ns == self.namespace)
                        & (self.postings.c.entity_id == entity_id)
                        & (self.postings.c.field_name == field_name)
                        & (self.postings.c.gram_hash.in_(batch))
                    ),
                    readonly=True,
                ).scalar()
                or 0
            )
        return total

    def posting_stats(self, entity_id: str | None = None, field_name: str | None = None, *, limit: int = 20) -> list[dict[str, Any]]:
        """Return the most common posting hashes for inspection.

        Args:
            entity_id: Optional entity identifier to filter by.
            field_name: Optional field name to filter by.
            limit: Maximum number of posting hash rows to return.

        Returns:
            list[dict[str, Any]]: Posting hash rows with ``gram_hash`` and ``posting_count``.
        """
        from sqlalchemy import func, select

        count_expr = func.count().label("posting_count")
        stmt = (
            select(self.postings.c.gram_hash, count_expr)
            .where(self.postings.c.ns == self.namespace)
            .group_by(self.postings.c.gram_hash)
            .order_by(count_expr.desc(), self.postings.c.gram_hash)
            .limit(max(1, int(limit)))
        )
        if entity_id is not None:
            stmt = stmt.where(self.postings.c.entity_id == entity_id)
        if field_name is not None:
            stmt = stmt.where(self.postings.c.field_name == field_name)
        rows = self.db.orm_execute(stmt, readonly=True).to_dicts()
        return [{"gram_hash": str(row["gram_hash"]), "posting_count": int(row["posting_count"])} for row in rows]

    def short_widths(self, entity_id: str, field_name: str, max_width: int) -> set[int]:
        """Return indexed keyword lengths up to ``max_width`` for one field.

        Args:
            entity_id: Entity identifier to inspect.
            field_name: Sparse-GRAM indexed field name.
            max_width: Inclusive maximum keyword width.

        Returns:
            set[int]: Indexed keyword lengths up to ``max_width``.
        """
        from sqlalchemy import select

        rows = self.db.orm_execute(
            select(self.keywords.c.keyword_len)
            .distinct()
            .where(
                (self.keywords.c.ns == self.namespace)
                & (self.keywords.c.entity_id == entity_id)
                & (self.keywords.c.field_name == field_name)
                & (self.keywords.c.keyword_len <= max_width)
            ),
            readonly=True,
        ).to_dicts()
        return {int(row["keyword_len"]) for row in rows if row.get("keyword_len") is not None}

    def drop(self) -> None:
        """Delete all sparse-GRAM rows in this backend namespace.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        from sqlalchemy import delete

        with self._tx():
            for table in (self.postings, self.keywords, self.meta):
                self.db.orm_execute(delete(table).where(table.c.ns == self.namespace), readonly=False)

    def _delete_postings(self, keyword_ids: Iterable[str]) -> None:
        from sqlalchemy import delete

        for batch in _batches(list(dict.fromkeys(str(keyword_id) for keyword_id in keyword_ids)), self.page_size):
            self.db.orm_execute(delete(self.postings).where((self.postings.c.ns == self.namespace) & (self.postings.c.keyword_id.in_(batch))), readonly=False)

    def _lookup_candidates_mask(self, entity_id: str, field_name: str, hashes: Sequence[str]) -> list[GramKeywordRow]:
        """Return candidates with a Python mask fallback for very large query hash sets."""
        from sqlalchemy import select

        mask_by_keyword: dict[str, int] = {}
        candidate_by_keyword: dict[str, GramKeywordRow] = {}
        join_expr = self.postings.join(self.keywords, (self.postings.c.ns == self.keywords.c.ns) & (self.postings.c.keyword_id == self.keywords.c.keyword_id))
        for batch in _batches(hashes, self.page_size):
            rows = self.db.orm_execute(
                select(self.postings.c.mask_bit, *self._keyword_cols())
                .select_from(join_expr)
                .where(
                    (self.postings.c.ns == self.namespace)
                    & (self.postings.c.entity_id == entity_id)
                    & (self.postings.c.field_name == field_name)
                    & (self.postings.c.gram_hash.in_(batch))
                ),
                readonly=True,
            ).to_dicts()
            for row in rows:
                keyword_id = str(row["keyword_id"])
                mask_by_keyword[keyword_id] = mask_by_keyword.get(keyword_id, 0) | int(row["mask_bit"])
                if keyword_id not in candidate_by_keyword:
                    candidate_by_keyword[keyword_id] = self._keyword_row(row)
        out = [
            candidate
            for keyword_id, candidate in candidate_by_keyword.items()
            if mask_by_keyword.get(keyword_id, 0) & candidate.full_mask == candidate.full_mask
        ]
        out.sort(key=lambda item: (item.object_id, item.field_name, item.ordinal, item.keyword_id))
        return out

    def _keyword_cols(self) -> list[Any]:
        return [
            self.keywords.c.entity_id,
            self.keywords.c.field_name,
            self.keywords.c.keyword_id,
            self.keywords.c.object_id,
            self.keywords.c.ordinal,
            self.keywords.c.keyword,
            self.keywords.c.keyword_norm,
            self.keywords.c.normalizer,
            self.keywords.c.full_mask,
            self.keywords.c.part_count,
        ]

    def _keyword_record(self, row: GramKeywordRow) -> dict[str, Any]:
        return {
            "ns": self.namespace,
            "entity_id": row.entity_id,
            "field_name": row.field_name,
            "keyword_id": row.keyword_id,
            "object_id": row.object_id,
            "ordinal": row.ordinal,
            "keyword": row.keyword,
            "keyword_norm": row.keyword_norm,
            "keyword_len": row.unit_count or len(row.keyword_norm),
            "normalizer": row.normalizer,
            "full_mask": str(row.full_mask),
            "part_count": row.part_count,
        }

    def _posting_record(self, row: dict[str, Any]) -> dict[str, Any]:
        keyword_id = str(row["keyword_id"])
        gram_hash = str(row["gram_hash"])
        mask_bit = str(row["mask_bit"])
        return {
            "_id": md5hash([self.namespace, keyword_id, gram_hash, mask_bit]),
            "ns": self.namespace,
            "entity_id": str(row["entity_id"]),
            "field_name": str(row["field_name"]),
            "gram_hash": gram_hash,
            "keyword_id": keyword_id,
            "mask_bit": mask_bit,
        }

    def _keyword_row(self, row: dict[str, Any]) -> GramKeywordRow:
        return GramKeywordRow(
            entity_id=str(row["entity_id"]),
            field_name=str(row["field_name"]),
            keyword_id=str(row["keyword_id"]),
            object_id=str(row["object_id"]),
            ordinal=int(row["ordinal"]),
            keyword=str(row["keyword"]),
            keyword_norm=str(row["keyword_norm"]),
            normalizer=str(row["normalizer"]),
            full_mask=int(row["full_mask"]),
            part_count=int(row.get("part_count") or int(row["full_mask"]).bit_count()),
            unit_count=int(row.get("keyword_len") or len(str(row["keyword_norm"]))),
        )


class SQLSparseGramAdapter(StrategyAdapter):
    """Maintain and query sparse-GRAM postings inside a SQL backend."""

    identifier = "sql_sparse_gram"
    strategy = SparseGramIndex

    def __init__(self, backend: Any) -> None:
        """Create a sparse-GRAM strategy adapter for a SQL backend.

        Args:
            backend (Any): Owning SQL backend instance.

        Returns:
            None: This function does not return a value.
        """
        super().__init__(backend)
        self._config: GramConfig | None = None
        self._index: _SQLGramIndex | None = None
        self._ensured_index: _SQLGramIndex | None = None
        self._fields: dict[str, dict[str, Any]] = {}
        self._configs: dict[tuple[str, str], GramConfig] = {}
        self._short_widths: dict[tuple[str, str], set[int]] = {}
        self._fingerprint_checked: set[str] = set()

    @property
    def config(self) -> GramConfig:
        """Return runtime sparse-GRAM defaults after Backend bootstrap.

        Returns:
            GramConfig: Defaults loaded lazily from `CM_HVNB`.
        """
        if self._config is None:
            self._config = GramConfig.load(manager=self.backend.config)
        return self._config

    def reset(self) -> None:
        """Clear cached state after the owning backend reconnects.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        self._config = None
        self._index = None
        self._ensured_index = None
        self._fields.clear()
        self._configs.clear()
        self._short_widths.clear()
        self._fingerprint_checked.clear()

    def supports(self, schema: EntitySchema, binding: Any) -> bool:
        """Return whether this adapter supports one SQL storage binding.

        Args:
            schema: Entity schema being registered.
            binding: Storage binding routed to the SQL backend.

        Returns:
            bool: True when the binding is an Array[ShortText] SparseGramIndex binding
                owned by this backend.
        """
        if binding.backend != self.backend.name or binding.strategy != SparseGramIndex.identifier or binding.field_name == schema.pk_name:
            return False
        field_schema = schema.get(binding.field_name)
        item_type = getattr(field_schema.dtype, "item_type", None)
        return item_type is not None and type(item_type).identifier == ShortText.identifier

    def ensure(self, schema: EntitySchema, binding: Any) -> None:
        """Ensure sparse-GRAM tables and field-specific strategy config.

        Args:
            schema: Entity schema being registered.
            binding: Sparse-GRAM storage binding.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the owning SQL backend has been dropped and not reconnected.
        """
        if not self.supports(schema, binding):
            return
        self._ensure_index()
        field_schema = schema.get(binding.field_name)
        self._fields.setdefault(schema.entity_id, {})[field_schema.name] = field_schema
        config = self.config.with_options(**dict(getattr(binding, "strategy_options", {}) or {}))
        self._configs[(schema.entity_id, field_schema.name)] = config
        self._ensure_fingerprint(schema.entity_id, field_schema.name, config)

    def _namespace(self) -> str:
        return f"{self.backend.ws_id or 'unbound'}:{self.backend.name}:{self.identifier}"

    def _connect_index(self) -> _SQLGramIndex:
        return _SQLGramIndex(
            self.backend,
            namespace=self._namespace(),
            page_size=self.config.posting_page_size,
        )

    def _need_index(self) -> _SQLGramIndex:
        if self.backend.db is None:
            raise RuntimeError(f"SQL backend {self.backend.name!r} is unavailable after drop")
        if self._index is None or self._index.db is not self.backend.db:
            self._index = self._connect_index()
        return self._index

    def _ensure_index(self) -> None:
        # Ensure fixed index tables once per backend connection. DuckDB and similar single-connection
        # engines reject nested DDL transactions when this runs inside the outer row-upsert transaction.
        index = self._need_index()
        if self._ensured_index is not index:
            index.ensure()
            self._ensured_index = index

    def _ensure_fingerprint(self, entity_id: str, field_name: str, config: GramConfig) -> None:
        key = f"fingerprint:{entity_id}:{field_name}"
        if key in self._fingerprint_checked:
            return
        index = self._need_index()
        fingerprint = config.fingerprint()
        existing = index.get_meta(key)
        if existing and existing != fingerprint:
            self._rebuild_field_index(entity_id, field_name)
        index.set_meta(key, fingerprint)
        self._fingerprint_checked.add(key)

    def _rebuild_field_index(self, entity_id: str, field_name: str) -> None:
        """Rebuild one field index from canonical SQL rows after strategy config changes."""
        field_schema = self._fields.get(entity_id, {}).get(field_name)
        if field_schema is None:
            self._need_index().delete_field(entity_id, field_name)
            self._short_widths.pop((entity_id, field_name), None)
            return

        writes = []
        for row in self.backend.scan(entity_id):
            object_id = row.get("object_id")
            if object_id is None:
                continue
            keywords, postings = index_keyword_rows(
                entity_id,
                str(object_id),
                row,
                {field_name: field_schema},
                self._config_for,
                resolver=self.backend.module_resolver,
            )
            writes.append(GramRowWrite(entity_id, str(object_id), {}, keywords, postings))
        self._need_index().replace_field_rows(entity_id, field_name, writes)
        self._short_widths.pop((entity_id, field_name), None)

    def upsert(self, rows: Sequence[RowOp]) -> None:
        """Apply SQL row mutations to sparse-GRAM index rows.

        Args:
            rows: Backend row mutations from the owning SQL backend.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the owning SQL backend has been dropped and not reconnected.
        """
        rows = [row for row in rows if row.entity_id in self._fields]
        if not rows:
            return
        self._ensure_index()
        writes_by_key: dict[tuple[str, str], GramRowWrite] = {}
        delete_keys: set[tuple[str, str]] = set()
        for row in rows:
            key = (row.entity_id, str(row.object_id))
            if row.is_delete():
                writes_by_key.pop(key, None)
                delete_keys.add(key)
                continue
            delete_keys.discard(key)
            keywords, postings = index_keyword_rows(
                row.entity_id,
                str(row.object_id),
                row.values,
                self._fields.get(row.entity_id, {}),
                self._config_for,
                resolver=self.backend.module_resolver,
            )
            writes_by_key[key] = GramRowWrite(row.entity_id, str(row.object_id), {}, keywords, postings)

        writes = list(writes_by_key.values())
        if writes:
            self._need_index().upsert_rows(writes)
            self._short_widths.clear()

        deletes_by_entity: dict[str, list[str]] = {}
        for entity_id, object_id in delete_keys:
            deletes_by_entity.setdefault(entity_id, []).append(object_id)
        for entity_id, object_ids in deletes_by_entity.items():
            self._need_index().delete_objects(entity_id, object_ids)
            self._short_widths.clear()

    def can_execute(self, fragment: QueryFragment) -> bool:
        """Return whether this adapter owns one compiled query fragment.

        Args:
            fragment: Compiled query fragment.

        Returns:
            bool: True when this adapter can execute the fragment without SQLBackend
                fallback.
        """
        if fragment.kind() == "sql_sparse_gram_contained_in":
            return True
        if fragment.op in ("and", "or"):
            return bool(fragment.children()) and all(self.can_execute(child) for child in fragment.children())
        if fragment.op == "not":
            return bool(fragment.children()) and self.can_execute(fragment.children()[0])
        return False

    def execute(self, fragment: QueryFragment) -> ResultFrame:
        """Execute sparse-GRAM fragments and sparse-GRAM-only logical trees.

        Args:
            fragment: Compiled sparse-GRAM query fragment.

        Returns:
            ResultFrame: Rows matched by sparse-GRAM candidate lookup plus exact verification.

        Raises:
            TypeError: If the fragment is not owned by this adapter.
            RuntimeError: If the owning SQL backend has been dropped and not reconnected.
        """
        if fragment.kind() == "sql_sparse_gram_contained_in":
            return self._execute_contained_in(fragment)
        if fragment.op in LOGICAL_OPS and self.can_execute(fragment):
            return fragment.execute(self.execute, lambda entity_id: ResultFrame.from_rows(self.backend.scan(entity_id)) if entity_id else ResultFrame.empty())
        raise TypeError(f"{self.identifier} cannot execute fragment kind={fragment.kind()!r} op={fragment.op!r}")

    def _execute_contained_in(self, fragment: QueryFragment) -> ResultFrame:
        entity_id = fragment.entity_id()
        if not entity_id:
            return ResultFrame.empty(metadata_columns={"match"})
        field_name = fragment.field
        config = self._config_for(entity_id, field_name)
        index = self._need_index()
        matches_by_id = contained_in_matches_by_id(
            entity_id,
            field_name,
            fragment.payload.get("query", ""),
            op=fragment.op,
            config=config,
            short_widths=self._indexed_short_widths(entity_id, field_name),
            candidates_for=lambda hashes: index.lookup_candidates(entity_id, field_name, hashes),
            resolver=self.backend.module_resolver,
        )
        if not matches_by_id:
            return ResultFrame.empty(metadata_columns={"match"})  # a miss declares the match column a hit carries, as the scan route does

        rows = self.backend.get_many(entity_id, sorted(matches_by_id))
        out = []
        for object_id, row in zip(sorted(matches_by_id), rows):
            payload = dict(row or {"object_id": object_id})
            payload["match"] = matches_by_id[object_id]
            out.append(payload)
        return ResultFrame.from_rows(out, metadata_columns={"match"})

    def contained_in_probe(self, entity_id: str, field_name: str, query: Any) -> dict[str, Any]:
        """Return exact-recall lookup metrics for one SQL-hosted sparse-GRAM field.

        Args:
            entity_id: Logical entity identifier.
            field_name: Sparse-GRAM field name.
            query: Query text to probe.

        Returns:
            dict[str, Any]: Candidate lookup and analyzer metrics.
        """
        config = self._config_for(entity_id, field_name)
        index = self._need_index()
        return contained_in_probe_data(
            entity_id,
            field_name,
            query,
            config=config,
            short_widths=self._indexed_short_widths(entity_id, field_name),
            candidates_for=lambda hashes: index.lookup_candidates(entity_id, field_name, hashes),
            posting_hits=lambda hashes: index.posting_hits(entity_id, field_name, hashes),
            resolver=self.backend.module_resolver,
        )

    def posting_count(self, entity_id: str | None = None, field_name: str | None = None) -> int:
        """Return adapter posting row count.

        Args:
            entity_id: Optional entity filter.
            field_name: Optional field filter.

        Returns:
            int: Number of sparse-GRAM posting rows.
        """
        return self._need_index().posting_count(entity_id, field_name)

    def posting_stats(self, entity_id: str | None = None, field_name: str | None = None, *, limit: int = 20) -> list[dict[str, Any]]:
        """Return hot posting hashes for adapter diagnostics.

        Args:
            entity_id: Optional entity filter.
            field_name: Optional field filter.
            limit: Maximum number of posting hash rows to return.

        Returns:
            list[dict[str, Any]]: Posting hash counts ordered by descending frequency.
        """
        return self._need_index().posting_stats(entity_id, field_name, limit=limit)

    def to_dict(self) -> dict[str, Any]:
        """Return the SQL sparse-GRAM ``strategy-adapters`` Tag envelope.

        Args:
            None.

        Returns:
            dict[str, Any]: Stable identity fields plus adapter-specific metadata.
        """
        return {
            "identifier": self.identifier,
            "strategy": self.strategy,
            "metadata": {
                "operations": ["contained_in"],
                "provider": self.backend.provider,
            },
        }

    def _config_for(self, entity_id: str, field_name: str) -> GramConfig:
        return self._configs.get((entity_id, field_name), self.config)

    def _indexed_short_widths(self, entity_id: str, field_name: str) -> set[int]:
        key = (entity_id, field_name)
        if key not in self._short_widths:
            self._short_widths[key] = self._need_index().short_widths(entity_id, field_name, self._config_for(entity_id, field_name).gram_width)
        return self._short_widths[key]
