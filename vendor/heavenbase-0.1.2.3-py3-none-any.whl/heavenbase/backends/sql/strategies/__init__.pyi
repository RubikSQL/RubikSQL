from .sparse_gram import SQLSparseGramAdapter as SQLSparseGramAdapter

__all__: list[str]
