"""Shared sparse-GRAM indexing and query execution helpers."""

from __future__ import annotations

__all__ = [
    "GramKeywordRow",
    "GramRowWrite",
    "contained_in_matches",
    "contained_in_matches_by_id",
    "contained_in_probe_data",
    "index_keyword_rows",
    "keyword_in_query",
    "match_spans",
    "raw_contained_in_matches",
]

from heavenbase.utils import Any, Callable, Mapping, Sequence, dataclass
from heavenbase.utils.hash import md5hash
from heavenbase.utils.text_match import (
    NormalizedText,
    keyword_in_query,
    match_spans,
    raw_contained_in_matches,
    contained_in_matches as _contained_in_matches,
)

from .....modules import ModuleResolver, module_resolver
from .config import GramConfig
from .normalizers import normalize_many, normalize_text
from .sparse import keyword_grams, query_grams, unit_count

ConfigFor = Callable[[str, str], GramConfig]


@dataclass(frozen=True)
class GramKeywordRow:
    """Stored normalized sparse-GRAM keyword candidate."""

    entity_id: str
    field_name: str
    keyword_id: str
    object_id: str
    ordinal: int
    keyword: str
    keyword_norm: str
    normalizer: str
    full_mask: int
    part_count: int
    unit_count: int = 0


@dataclass(frozen=True)
class GramRowWrite:
    """Complete sparse-GRAM index replacement payload for one object."""

    entity_id: str
    object_id: str
    row: dict[str, Any]
    keywords: Sequence[GramKeywordRow]
    postings: Sequence[dict[str, Any]]


def contained_in_matches(
    field: str,
    value: Any,
    query: Any,
    config: GramConfig | None = None,
    *,
    op: str = "contained_in",
    resolver: ModuleResolver | None = None,
) -> list[dict[str, Any]]:
    """Return reverse-containment match metadata using GRAM normalizer config.

    Args:
        field: Logical field name.
        value: Indexed field value to search inside the query.
        query: Query text that may contain indexed values.
        config: Optional sparse-GRAM runtime config. Defaults are loaded when omitted.
        op: Logical operation name attached to match metadata.
        resolver: Context-owned module resolver.

    Returns:
        list[dict[str, Any]]: Exact match metadata rows.
    """
    selected = module_resolver(resolver)
    config = config or GramConfig.load()
    return _contained_in_matches(field, value, query, normalize=lambda text: normalize_text(text, config, resolver=selected), op=op)


def index_keyword_rows(
    entity_id: str,
    object_id: str,
    values: Mapping[str, Any],
    fields: Mapping[str, Any],
    config_for: ConfigFor,
    *,
    resolver: ModuleResolver | None = None,
) -> tuple[list[GramKeywordRow], list[dict[str, Any]]]:
    """Build normalized keyword rows and sparse posting rows for one object.

    Args:
        entity_id: Logical entity identifier.
        object_id: User-facing row object id.
        values: Backend row values for the object.
        fields: Sparse-GRAM field schemas keyed by field name.
        config_for: Callable returning the field-specific sparse-GRAM config.
        resolver: Context-owned module resolver.

    Returns:
        tuple[list[GramKeywordRow], list[dict[str, Any]]]: Normalized keyword rows and
            posting rows for SQL persistence.
    """
    selected = module_resolver(resolver)
    keywords: list[GramKeywordRow] = []
    postings: list[dict[str, Any]] = []
    for field_name in sorted(fields):
        raw_values = values.get(field_name) or []
        if not isinstance(raw_values, list):
            continue
        source_values = ["" if value is None else str(value) for value in raw_values]
        config = config_for(entity_id, field_name)
        normalized = normalize_many(source_values, config, resolver=selected)
        for ordinal, (source, norm) in enumerate(zip(source_values, normalized)):
            parts = keyword_grams(norm.text, config, resolver=selected)
            if not parts:
                continue
            keyword_id = md5hash([entity_id, field_name, object_id, ordinal, norm.text, config.fingerprint()])
            full_mask = 0
            for part in parts:
                full_mask |= part.mask_bit
                postings.append(
                    {
                        "entity_id": entity_id,
                        "field_name": field_name,
                        "keyword_id": keyword_id,
                        "gram_hash": part.gram_hash,
                        "mask_bit": part.mask_bit,
                    }
                )
            keywords.append(
                GramKeywordRow(
                    entity_id=entity_id,
                    field_name=field_name,
                    keyword_id=keyword_id,
                    object_id=object_id,
                    ordinal=ordinal,
                    keyword=source,
                    keyword_norm=norm.text,
                    normalizer=norm.normalizer or config.normalizer_id(),
                    unit_count=unit_count(norm.text, config, resolver=selected),
                    full_mask=full_mask,
                    part_count=len(parts),
                )
            )
    return keywords, postings


def contained_in_matches_by_id(
    entity_id: str,
    field_name: str,
    query: Any,
    *,
    op: str,
    config: GramConfig,
    short_widths: set[int],
    candidates_for: Callable[[set[str]], list[GramKeywordRow]],
    resolver: ModuleResolver | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """Return exact-verified reverse-containment match metadata keyed by object id.

    Args:
        entity_id: Logical entity identifier.
        field_name: Sparse-GRAM field name.
        query: Query text that may contain indexed keywords.
        op: Logical operation name attached to match metadata.
        config: Field-specific sparse-GRAM config.
        short_widths: Short keyword widths observed in the index.
        candidates_for: Callable that loads candidate keyword rows for query gram hashes.
        resolver: Context-owned module resolver.

    Returns:
        dict[str, list[dict[str, Any]]]: Match metadata keyed by object id.
    """
    selected = module_resolver(resolver)
    query_source = "" if query is None else str(query)
    query_norm = normalize_text(query_source, config, resolver=selected)
    if not query_norm.text:
        return {}
    candidates = candidates_for(query_grams(query_norm.text, config, short_widths=short_widths, resolver=selected))
    matches_by_id: dict[str, list[dict[str, Any]]] = {}
    for candidate in candidates:
        if not keyword_in_query(candidate.keyword_norm, query_norm.text):
            continue
        keyword_norm = NormalizedText(candidate.keyword_norm, None, normalizer=candidate.normalizer, precision="normalized_only")
        matches = match_spans(field_name, op, candidate.keyword, keyword_norm, query_source, query_norm, candidate.ordinal)
        if matches:
            matches_by_id.setdefault(candidate.object_id, []).extend(matches)
    return matches_by_id


def contained_in_probe_data(
    entity_id: str,
    field_name: str,
    query: Any,
    *,
    config: GramConfig,
    short_widths: set[int],
    candidates_for: Callable[[set[str]], list[GramKeywordRow]],
    posting_hits: Callable[[set[str]], int],
    resolver: ModuleResolver | None = None,
) -> dict[str, Any]:
    """Return exact-recall lookup metrics for one sparse-GRAM field.

    Args:
        entity_id: Logical entity identifier.
        field_name: Sparse-GRAM field name.
        query: Query text to probe.
        config: Field-specific sparse-GRAM config.
        short_widths: Short keyword widths observed in the index.
        candidates_for: Callable that loads candidate keyword rows for query gram hashes.
        posting_hits: Callable that counts posting rows for query gram hashes.
        resolver: Context-owned module resolver.

    Returns:
        dict[str, Any]: Query units, hash counts, candidate counts, and analyzer metadata.
    """
    selected = module_resolver(resolver)
    query_source = "" if query is None else str(query)
    query_norm = normalize_text(query_source, config, resolver=selected)
    hashes = query_grams(query_norm.text, config, short_widths=short_widths, resolver=selected)
    candidates = candidates_for(hashes)
    exact = [candidate for candidate in candidates if keyword_in_query(candidate.keyword_norm, query_norm.text)]
    return {
        "query_units": unit_count(query_norm.text, config, resolver=selected),
        "query_hashes": len(hashes),
        "posting_hits": posting_hits(hashes),
        "candidates": len(candidates),
        "exact_matches": len(exact),
        "normalizer": config.normalizer_id(),
        "gram_unit": config.gram_unit,
        "tokenizer": config.tokenizer,
    }
