"""OpenSearch Backend role."""

from .runtime import OpenSearchBackend

__all__ = ["OpenSearchBackend"]
