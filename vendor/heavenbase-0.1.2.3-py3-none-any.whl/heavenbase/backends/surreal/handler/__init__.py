"""SurrealDB backend handler role."""

from .runtime import register_handlers, register_reasons, surreal_filter_handler, surreal_near_handler

__all__ = [
    "register_handlers",
    "register_reasons",
    "surreal_filter_handler",
    "surreal_near_handler",
]
