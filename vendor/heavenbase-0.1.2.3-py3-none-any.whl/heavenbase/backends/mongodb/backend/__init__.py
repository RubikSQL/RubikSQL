"""MongoDB Backend role."""

from .runtime import MongoDBBackend

__all__ = ["MongoDBBackend"]
