"""Module-folder installation, inspection, and resolution lifecycle."""

from __future__ import annotations

from heavenbase._lazy import _attach_lazy_exports

__all__ = [
    "EXECUTABLE_REF_KIND",
    "EXECUTABLE_REF_VERSION",
    "ExecutableRef",
    "InstallReceipt",
    "ModuleCatalog",
    "ModuleResolver",
    "ModuleService",
    "ResolvedTagValue",
    "TagDefinition",
    "TagView",
    "capsule_executable_ref",
    "module_resolver",
    "python_executable_ref",
    "tag",
    "tag_definition",
    "tags",
]

_LAZY_EXPORTS = {
    "EXECUTABLE_REF_KIND": (".executable", "EXECUTABLE_REF_KIND"),
    "EXECUTABLE_REF_VERSION": (".executable", "EXECUTABLE_REF_VERSION"),
    "ExecutableRef": (".executable", "ExecutableRef"),
    "InstallReceipt": (".manifest", "InstallReceipt"),
    "ModuleCatalog": (".service", "ModuleCatalog"),
    "ModuleResolver": (".base", "ModuleResolver"),
    "ModuleService": (".service", "ModuleService"),
    "ResolvedTagValue": (".tags", "ResolvedTagValue"),
    "TagDefinition": (".tags", "TagDefinition"),
    "TagView": (".tags", "TagView"),
    "capsule_executable_ref": (".executable", "capsule_executable_ref"),
    "module_resolver": (".base", "module_resolver"),
    "python_executable_ref": (".executable", "python_executable_ref"),
    "tag": (".tags", "tag"),
    "tag_definition": (".tags", "tag_definition"),
    "tags": (".tags", "tags"),
}

__getattr__, __dir__ = _attach_lazy_exports(__name__, globals(), _LAZY_EXPORTS, __all__)
