"""Reset package-owned local state coordinated by Context."""

from __future__ import annotations

__all__ = [
    "reset_default_local_state",
]

from heavenbase.utils import List, delete_file, dget, file_uri_to_path, normalize_file_uri
from heavenbase.utils.typing import Any, Mapping

from .runtime import DEFAULT_CONTEXT, Context, context_or_default


def reset_default_local_state(context: Context | None = None) -> None:
    """Remove package-owned local database files used by default services.

    Args:
        context: Context whose package-owned local resources should be reset.

    Returns:
        None: This function deletes package-owned local files in place.
    """
    selected = context_or_default(context)
    while selected.parent is not None:
        selected = selected.parent
    with selected._lock:
        selected._need_open()
        cm = selected.config
        paths = _default_local_db_paths(selected)
        backend = selected._backend
        modules = selected._modules
        hidden_stores = tuple(selected._hidden_stores.values())
        selected._hidden_stores.clear()
        if modules is not None:
            modules._need_retirable()
    for store in hidden_stores:
        store.drop()
    with selected._reset_authority() as previous_authority:
        try:
            if modules is not None:
                from ..llm.gateways._protocols import dispose_llm_clients

                modules._retire_authority()
                dispose_llm_clients(modules)
            db = getattr(backend, "db", None)
            if db is not None:
                db.dispose()
            from ..database.registry import DatabaseEngineRegistry

            DatabaseEngineRegistry.dispose_authority(previous_authority)
            for path in paths:
                for target in (path, f"{path}-wal", f"{path}-shm"):
                    delete_file(target)
        finally:
            with selected._lock:
                selected._backend = None
                selected._registries.clear()
                selected._registry_options.clear()
                selected._registry_store = None
                selected._modules = None
                for workspace_id in tuple(selected._workspace_registry):
                    selected._workspace_registry.delete(workspace_id)
                for workspace_id in tuple(selected._live_workspaces):
                    selected._live_workspaces.delete(workspace_id)
                selected._active_workspace_id = None
                if selected is DEFAULT_CONTEXT:
                    from ..entity.base import _set_default_workspace

                    _set_default_workspace(None)
                cm._registry = None
                cm._registry_factory = lambda: selected.registry("system-config")
                cm._setup_pending = True


def _default_local_db_paths(context: Context) -> List[str]:
    from heavenbase.database import DBEngine
    from heavenbase.database.dialect.registry import BootstrapDialectCatalog, ResolverDialectCatalog

    cm = context.config
    root = cm.load_default()
    bootstrap_backend = context.bootstrap.backend
    override = bootstrap_backend.get("_override") if isinstance(bootstrap_backend, Mapping) else None
    if isinstance(override, Mapping):
        database_config = _localize_file_aliases(override, cm)
        db_engine = DBEngine(
            config=database_config,
            manager=None,
            dialects=BootstrapDialectCatalog(database_config.get("dialects", {})),
        )
    else:
        database_config = _localize_file_aliases(dget(root, "heavenbase.db", default={}) or {}, cm)
        db_engine = DBEngine(
            config=database_config,
            manager=None,
            dialects=ResolverDialectCatalog(context.modules()),
        )
    paths: List[str] = []
    backend = getattr(context, "_backend", None)
    backend_spec = getattr(getattr(backend, "db", None), "spec", None)
    database = getattr(backend_spec, "database", None)
    if database is None:
        database = context.bootstrap.backend.get("database")
    if database not in (None, "", ":memory:"):
        paths.append(file_uri_to_path(str(database), home=cm.root))
    for key in ("heavenbase.capsule.registry", "heavenbase.llm.cache"):
        backends = dget(root, f"{key}.backend", default={}) or dget(root, f"{key}.backends", default={}) or {}
        for backend in backends.values():
            cfg = _localize_file_aliases(backend, cm)
            provider = cfg.pop("provider", None) or cfg.pop("type", None)
            if provider is not None:
                cfg["provider"] = provider
            spec = db_engine.resolve(cfg)
            if spec.database and str(spec.database).startswith("file://"):
                paths.append(file_uri_to_path(spec.database, home=cm.root))
    return sorted(set(paths))


def _localize_file_aliases(config: Mapping[str, Any], manager: Any) -> dict[str, Any]:
    """Expand reset-only file aliases against one Context's config roots."""
    localized = dict(config)
    resource = manager.pj("&", abs=True)
    for key in ("database", "local_root"):
        value = localized.get(key)
        if isinstance(value, str) and value.startswith("file://"):
            localized[key] = normalize_file_uri(value, home=manager.root, resource=resource)
    return localized
