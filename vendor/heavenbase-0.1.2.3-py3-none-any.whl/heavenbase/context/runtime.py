"""Context composition root for Backends, Registries, and configuration."""

from __future__ import annotations

from collections.abc import Callable, Hashable, Iterator, Mapping
from contextlib import contextmanager
from importlib import import_module
from pathlib import Path
import threading
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from heavenbase.utils.registry import Registry, RegistryStore, identifier_key

from .bootstrap import BootstrapSpec, load_bootstrap
from ..utils.config.manager import CM_HVNB, ConfigManager
from ..utils.ids import check_workspace_id

if TYPE_CHECKING:
    from ..modules import ModuleService

_ACTIVE_WORKSPACE_PATH = "heavenbase.registry.active.workspace"
_UNRESOLVED_ACTIVE_WORKSPACE = object()


class Context:
    """Own machine services and memoized persistent Registry namespaces.

    Backend construction remains lazy. A root Context owns its machine
    composition; child contexts are workspace-selection views over that exact
    Backend, ModuleService, and ConfigManager authority.

    Args:
        bootstrap (BootstrapSpec): Validated machine-service configuration.
        config (ConfigManager | None): ConfigManager to bind to this Context.
            HeavenBase constructs one below `bootstrap.root` when omitted.
        backend (Any): Optional already-constructed Backend for a child Context.
        modules (ModuleService | None): Module authority paired with a supplied
            child Backend.
        owns_backend (bool): Whether `close` disposes the supplied Backend.
        parent (Context | None): Parent Context when resources are inherited.
    """

    def __init__(
        self,
        bootstrap: BootstrapSpec,
        *,
        config: ConfigManager | None = None,
        backend: Any = None,
        modules: "ModuleService | None" = None,
        owns_backend: bool = True,
        parent: "Context | None" = None,
    ) -> None:
        """Construct one machine composition root or child workspace view.

        Returns:
            None: This initializer does not return a value.
        """
        self.bootstrap = bootstrap
        self.root = bootstrap.root
        self._bootstrap_workspace_id = check_workspace_id(bootstrap.workspace)
        self.identity_token = parent.identity_token if parent is not None else uuid4().hex
        self._authority_token = parent.authority_token if parent is not None else uuid4().hex
        self._active_workspace_id: str | None | object = self._bootstrap_workspace_id if parent is not None else _UNRESOLVED_ACTIVE_WORKSPACE
        self.parent = parent
        self.config = config or ConfigManager(root=self.root, setup=True)
        self._backend = backend
        self._owns_backend = owns_backend
        self._registries: dict[str, Registry[Any, Any]] = {}
        self._registry_options: dict[str, tuple[Any, ...]] = {}
        self._registry_store: RegistryStore | None = None
        self._modules: ModuleService | None = modules
        self._hidden_stores: dict[str, Any] = parent._hidden_stores if parent is not None else {}
        self._lock = parent._lock if parent is not None else threading.RLock()
        self._workspace_registry = Registry[str, Any](
            "live-workspaces",
            normalize=check_workspace_id,
            value_policy="process_identity",
        )
        self._live_workspaces = Registry[str, Any](
            "open-workspaces",
            normalize=check_workspace_id,
            value_policy="process_identity",
        )
        self._workspace_lock = threading.RLock()
        self._closed = False
        self._closing = False
        self._resetting = False
        self._lifecycle_condition = threading.Condition(self._lock)
        if parent is not None and self.config is not parent.config:
            raise ValueError("Child Contexts must share their parent's ConfigManager")
        owns_config = parent is None or self.config is not parent.config
        if owns_config:
            previous_owner = getattr(self.config, "_context", None)
            if previous_owner is not None and previous_owner is not self:
                raise ValueError("ConfigManager is already bound to another Context")
            self.config._context = self
        if owns_config and (self.config._registry is None or not len(self.config._registry)):
            self.config._bind_registry_factory(lambda: self.registry("system-config"))

    @classmethod
    def load(
        cls,
        bootstrap: Mapping[str, Any] | None = None,
        *,
        home_path: str | Path | None = None,
        config: ConfigManager | None = None,
    ) -> "Context":
        """Load a Context without opening its selected Backend.

        Args:
            bootstrap (Mapping[str, Any] | None): Explicit bootstrap mapping.
                When omitted, the home or packaged bootstrap is selected.
            home_path (str | Path | None): Optional bootstrap YAML file.
            config (ConfigManager | None): ConfigManager to bind lazily.

        Returns:
            Context: Lazily constructed machine-service composition root.

        Raises:
            ValueError: If the selected bootstrap configuration is invalid.
        """
        return cls(load_bootstrap(bootstrap, home_path=home_path), config=config)

    def _need_open(self) -> None:
        if self._closed:
            raise RuntimeError("Context is closed")
        if self._closing:
            raise RuntimeError("Context close is in progress")
        if self._resetting:
            raise RuntimeError("Context reset is in progress")
        if self.parent is not None:
            self.parent._need_open()
            if self._authority_token != self.parent.authority_token:
                raise RuntimeError("Context belongs to a retired parent authority generation")

    @property
    def authority_token(self) -> str:
        """Return the current root resource-generation identity."""
        return self._authority_token

    @property
    def active_workspace_id(self) -> str | None:
        """Return this Context's in-memory active-workspace projection.

        Root Contexts resolve the persisted profile selection once and retain
        that value for their lifetime. Child Contexts begin with their explicit
        local selection. Neither form polls for later profile changes.

        Returns:
            str | None: Explicitly active workspace id, or ``None`` when the
            configured default workspace is the effective fallback.
        """
        with self._lock:
            self._need_open()
            if self._active_workspace_id is _UNRESOLVED_ACTIVE_WORKSPACE:
                with self.config.scoped(self.config.base_scope):
                    value = self.config.get(_ACTIVE_WORKSPACE_PATH, default=None)
                self._active_workspace_id = None if value is None else check_workspace_id(str(value))
            return self._active_workspace_id

    @property
    def default_workspace_id(self) -> str:
        """Return the stable configured default-workspace identifier."""
        self._need_open()
        with self.config.scoped(self.config.base_scope):
            return check_workspace_id(self.config.get("heavenbase.registry.default_workspace", default="default"))

    @property
    def effective_workspace_id(self) -> str:
        """Return the active workspace id, falling back to the configured default."""
        return self.active_workspace_id or self.default_workspace_id

    def activate_workspace(self, workspace: str) -> str:
        """Select one registered workspace for this Context.

        The selection is persisted in the Context's configuration profile.
        Other already-running Context projections remain unchanged.

        Args:
            workspace: Registered workspace identifier to activate.

        Returns:
            str: Normalized active workspace identifier.

        Raises:
            KeyError: If the workspace is not durably registered.
        """
        self._need_open()
        clean_id = check_workspace_id(workspace)
        from ..workspace import WorkspaceSpec

        WorkspaceSpec.load(clean_id, context=self)
        with self._lock:
            self._need_open()
            self.config.set(_ACTIVE_WORKSPACE_PATH, clean_id, scope=self.config.base_scope)
            self._active_workspace_id = clean_id
            from ..workspace.setup.lifecycle import _sync_entity_default

            _sync_entity_default(self)
        return clean_id

    def deactivate_workspace(self) -> str | None:
        """Clear this Context's explicit active-workspace selection.

        Args:
            None.

        Returns:
            str | None: Previously active workspace identifier, if any.
        """
        with self._lock:
            self._need_open()
            previous = self.active_workspace_id
            self.config.set(_ACTIVE_WORKSPACE_PATH, None, scope=self.config.base_scope)
            self._active_workspace_id = None
            from ..workspace.setup.lifecycle import _sync_entity_default

            _sync_entity_default(self)
            return previous

    @contextmanager
    def _reset_authority(self) -> Iterator[str]:
        """Atomically rotate and exclusively reset the root resource lease."""
        if self.parent is not None:
            raise RuntimeError("Only a root Context can reset resource authority")
        with self._lock:
            self._need_open()
            previous = self.authority_token
            self._resetting = True
            self._authority_token = uuid4().hex
        try:
            yield previous
        finally:
            with self._lifecycle_condition:
                self._resetting = False
                self._lifecycle_condition.notify_all()

    def backend(self, name: str | None = None) -> Any:
        """Return the fully composed system Backend, constructing it lazily.

        Args:
            name (str | None): Expected configured Backend name. When supplied,
                a mismatch is rejected before construction.

        Returns:
            Any: Context-owned Backend instance.

        Raises:
            KeyError: If `name` does not match the configured Backend.
            RuntimeError: If the Context is closed.
            ValueError: If the configured module does not expose exactly one
                matching Backend implementation.
        """
        backend = self._control_backend(name)
        if backend._module_resolver is None:
            self.modules()
        return backend

    def _control_backend(self, name: str | None = None) -> Any:
        """Return the bootstrap Backend before module authority is available.

        This private seam exists only to break the composition cycle: the
        Backend persists the Registry that stores the module catalog, while
        the public :meth:`backend` surface must never expose that Backend until
        the catalog has been created and bound as its resolver.

        Args:
            name: Expected configured Backend name, when validation is needed.

        Returns:
            Any: Context-owned control Backend, possibly awaiting its one-shot
            ModuleService finalization.
        """
        self._need_open()
        expected = str(self.bootstrap.backend["name"])
        if name is not None and name != expected:
            raise KeyError(f"Unknown Context backend {name!r}; known={[expected]!r}")
        if self._backend is None:
            with self._lock:
                self._need_open()
                if self._backend is None:
                    with self.config.scoped(self.config.base_scope):
                        from ..backends.base import Backend
                        from ..backends._construction import adapt_backend_factory, construct_backend, normalize_backend_leaf

                        spec = dict(self.bootstrap.backend)
                        database_config = spec.pop("_override", None)
                        bootstrap_backend_tags = spec.pop("tags", {})
                        if database_config is not None:
                            if not isinstance(database_config, Mapping):
                                raise TypeError("Bootstrap backend _override must be a database config mapping")
                            from ..database.config import DBEngine
                            from ..database.dialect.registry import BootstrapDialectCatalog

                            definitions = database_config.get("dialects", {})
                            spec["config_engine"] = DBEngine(
                                config=database_config,
                                manager=None,
                                dialects=BootstrapDialectCatalog(definitions),
                                bootstrap_backend_tags=bootstrap_backend_tags,
                            )
                        request = normalize_backend_leaf(
                            str(spec.get("name") or "system"),
                            spec,
                            ws_id=self._bootstrap_workspace_id,
                            root=self.root,
                            require_module=True,
                        )
                        module = import_module(request.module or "")
                        candidates = tuple(
                            dict.fromkeys(
                                value
                                for value in vars(module).values()
                                if isinstance(value, type)
                                and issubclass(value, Backend)
                                and value is not Backend
                                and getattr(value, "identifier", None) == request.identifier
                            )
                        )
                        if len(candidates) != 1:
                            raise ValueError(f"Bootstrap module {request.module!r} must expose exactly one Backend " f"with identifier {request.identifier!r}")
                        candidate = candidates[0]
                        self._backend = construct_backend(
                            request,
                            adapt_backend_factory(candidate),
                            resolver=None,
                            config=self.config,
                        )
        return self._backend

    def registry(
        self,
        identifier: str,
        **options: Any,
    ) -> Registry[Any, Any]:
        """Open a caller-managed Registry namespace.

        The reserved `system-modules` namespace has one validated mutation
        protocol and is available only through :meth:`modules` and its
        read-only catalog.

        Args:
            identifier (str): Stable Registry namespace identifier.
            **options (Any): Optional codec, normalizer, and limit options
                forwarded to the underlying Registry loader.

        Returns:
            Registry[Any, Any]: Persistent Registry cached by namespace.

        Raises:
            ValueError: If ``identifier`` is ``system-modules`` or the
                namespace is already open with different options.
        """
        self._need_open()
        namespace = identifier_key(identifier, "registry identifier")
        if namespace == "system-modules":
            raise ValueError("Registry 'system-modules' is reserved; use Context.modules() and ModuleService.catalog")
        return self._open_registry(namespace, **options)

    def _open_registry(
        self,
        identifier: str,
        *,
        encode_key: Callable[[Any], Any] | None = None,
        decode_key: Callable[[Any], Any] | None = None,
        encode_value: Callable[[Any], Any] | None = None,
        decode_value: Callable[[Any], Any] | None = None,
        normalize: Callable[[Any], Any] | None = None,
        normalize_alias: Callable[[Any], Any] | None = None,
        normalize_group: Callable[[Hashable], Hashable] | None = None,
        max_items: int | None = None,
        max_bytes: int | None = None,
    ) -> Registry[Any, Any]:
        """Return one memoized persistent Registry namespace.

        Args:
            identifier (str): Stable Registry namespace identifier.
            encode_key (Callable[[Any], Any] | None): Optional JSON-safe key encoder.
            decode_key (Callable[[Any], Any] | None): Decoder paired with `encode_key`.
            encode_value (Callable[[Any], Any] | None): Optional JSON-safe value encoder.
            decode_value (Callable[[Any], Any] | None): Decoder paired with `encode_value`.
            normalize (Callable[[Any], Any] | None): Canonical key normalizer.
            normalize_alias (Callable[[Any], Any] | None): Alias normalizer.
            normalize_group (Callable[[Hashable], Hashable] | None): Group normalizer.
            max_items (int | None): Namespace item limit. `None` inherits the
                bootstrap policy, whose explicit `null` value is unbounded.
            max_bytes (int | None): Encoded snapshot limit. `None` inherits the
                bootstrap policy, whose explicit `null` value is unbounded.

        Returns:
            Registry[Any, Any]: Persistent Registry cached by namespace.

        Raises:
            RuntimeError: If the Context is closed.
            ValueError: If the namespace is already open with different codecs,
                normalizers, or limits.
        """
        self._need_open()
        namespace = identifier_key(identifier, "registry identifier")
        policy = self.bootstrap.registry
        effective_max_items = policy.get("max_items") if max_items is None else max_items
        effective_max_bytes = policy.get("max_bytes") if max_bytes is None else max_bytes
        options = (
            encode_key,
            decode_key,
            encode_value,
            decode_value,
            policy.get("hash", "sha256"),
            normalize,
            normalize_alias,
            normalize_group,
            effective_max_items,
            effective_max_bytes,
        )
        with self._lock:
            self._need_open()
            registry = self._registries.get(namespace)
            if registry is None:
                if self._registry_store is None:
                    from .registry import HeavenBaseRegistryStore

                    self._registry_store = HeavenBaseRegistryStore(
                        self._control_backend(),
                        control=lambda: self.config.scoped(self.config.base_scope),
                    )
                registry = Registry.load(
                    namespace,
                    store=self._registry_store,
                    encode_key=encode_key,
                    decode_key=decode_key,
                    encode_value=encode_value,
                    decode_value=decode_value,
                    hash_fn=policy.get("hash", "sha256"),
                    normalize=normalize,
                    normalize_alias=normalize_alias,
                    normalize_group=normalize_group,
                    max_items=effective_max_items,
                    max_bytes=effective_max_bytes,
                )
                self._registry_options[registry.identifier] = options
                self._registries[registry.identifier] = registry
            elif self._registry_options[namespace] != options:
                raise ValueError(f"Registry namespace {namespace!r} is already open with different codecs, normalizers, or limits")
            return registry

    def modules(self) -> "ModuleService":
        """Return the memoized central module lifecycle service.

        Access opens `system-modules` but performs no package discovery or
        registration. Explicit setup and workspace creation own built-in
        module indexing; runtime consumers subsequently read only Registry
        records.

        Args:
            None.

        Returns:
            ModuleService: Root machine authority over the durable
            `system-modules` namespace, shared unchanged by child views.

        Raises:
            RuntimeError: If the Context is closed.
        """
        self._need_open()
        with self._lock:
            self._need_open()
            if self._modules is None:
                from ..modules import ModuleService
                from ..modules.artifacts import ModuleArtifactStore

                def restore_capsule(target: Any, resolver: "ModuleService") -> Any:
                    from ..capsule.errors import CapsuleNotFoundError
                    from ..capsule.registry import capsule_registry
                    from ..modules.artifacts import SourceUnavailable

                    try:
                        return capsule_registry(resolver=resolver, config=self.config).load(str(target))
                    except CapsuleNotFoundError as error:
                        raise SourceUnavailable(f"Capsule {target!r} is unavailable") from error

                service = ModuleService(
                    self._open_registry("system-modules"),
                    artifacts=ModuleArtifactStore(Path(self.root) / "artifacts" / "modules"),
                    authority_token=self.authority_token,
                    authority_config=self.config,
                    source_restorers={"capsule": restore_capsule},
                )
                self._control_backend()._finalize_bootstrap_resolver(service)
                self._modules = service
            return self._modules

    def _hidden_store(self, config: Mapping[str, Any]) -> Any:
        """Return one shared Context-owned hidden domain-workspace adapter."""
        self._need_open()
        owner = self
        while owner.parent is not None:
            owner = owner.parent
        from ..workspace.hidden_store import HiddenWorkspaceStore

        key = HiddenWorkspaceStore.key(config)
        with owner._lock:
            owner._need_open()
            store = owner._hidden_stores.get(key)
            if store is None or store.retired:
                store = HiddenWorkspaceStore(owner, config)
                owner._hidden_stores[key] = store
            return store

    def _new_hidden_store(self, config: Mapping[str, Any]) -> Any:
        """Return one isolated Context-owned hidden domain-workspace adapter."""
        self._need_open()
        owner = self
        while owner.parent is not None:
            owner = owner.parent
        from ..workspace.hidden_store import HiddenWorkspaceStore

        with owner._lock:
            owner._need_open()
            store = HiddenWorkspaceStore(owner, config)
            owner._hidden_stores[f"private:{id(store)}"] = store
            return store

    def _retire_hidden_store(self, store: Any, *, drop: bool = False) -> None:
        """Remove and retire one exact hidden domain-workspace adapter."""
        owner = self
        while owner.parent is not None:
            owner = owner.parent
        with owner._lock:
            for key, candidate in tuple(owner._hidden_stores.items()):
                if candidate is store:
                    owner._hidden_stores.pop(key)
        store.drop() if drop else store.close()

    def _reset_hidden_stores(self, *, drop: bool = False) -> None:
        """Retire this Context's hidden domain-workspace adapters."""
        owner = self
        while owner.parent is not None:
            owner = owner.parent
        with owner._lock:
            stores = tuple(owner._hidden_stores.values())
            owner._hidden_stores.clear()
        for store in stores:
            store.drop() if drop else store.close()

    def _setup_modules(self, force: bool = False) -> bool:
        """Index packaged module folders at an explicit setup boundary.

        Args:
            force: Whether to rediscover the current package version even when
                its durable module-set marker is current.

        Returns:
            bool: Whether package discovery and validation ran.
        """
        self._need_open()
        with self._lock:
            return self.modules().setup(force=force)

    def child(self, workspace: str) -> "Context":
        """Create a workspace-selection view over this machine Context.

        Args:
            workspace (str): Workspace selected by the child Context.

        Returns:
            Context: Child Context sharing this Context's Backend,
            ModuleService, and ConfigManager, with separate ordinary Registry
            facade caches and workspace identity maps.

        Raises:
            RuntimeError: If this Context is closed.
            ValueError: If `workspace` is not a valid workspace identifier.
        """
        self._need_open()
        with self._lock:
            self._need_open()
            child_spec = BootstrapSpec(self.root, check_workspace_id(workspace), dict(self.bootstrap.backend), dict(self.bootstrap.registry))
            modules = self.modules()
            return type(self)(
                child_spec,
                config=self.config,
                backend=self.backend(),
                modules=modules,
                owns_backend=False,
                parent=self,
            )

    def close(self) -> None:
        """Release resources owned by this Context without deleting data.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        with self._lifecycle_condition:
            while self._closing or self._resetting:
                self._lifecycle_condition.wait()
            if self._closed:
                return
            modules = self._modules
            if self.parent is None and modules is not None:
                modules._need_retirable()
            self._closing = True
            backend = self._backend
            authority = self.authority_token
        try:
            if self.parent is None and modules is not None:
                modules._retire_authority()
                from ..llm.gateways._protocols import dispose_llm_clients

                dispose_llm_clients(modules)
            if self._owns_backend and backend is not None:
                db = getattr(backend, "db", None)
                dispose = getattr(db, "dispose", None)
                if callable(dispose):
                    dispose()
            if self.parent is None:
                from ..database.registry import DatabaseEngineRegistry

                DatabaseEngineRegistry.dispose_authority(authority)
        finally:
            with self._lifecycle_condition:
                hidden_stores = tuple(self._hidden_stores.values()) if self.parent is None else ()
                if self.parent is None:
                    self._hidden_stores.clear()
                self._registries.clear()
                self._registry_options.clear()
                self._registry_store = None
                self._modules = None
                for workspace_id in tuple(self._workspace_registry):
                    self._workspace_registry.delete(workspace_id)
                for workspace_id in tuple(self._live_workspaces):
                    self._live_workspaces.delete(workspace_id)
                self._backend = None
                self._closed = True
                self._closing = False
                self._lifecycle_condition.notify_all()
            for store in hidden_stores:
                store.close()


DEFAULT_CONTEXT = Context.load(config=CM_HVNB)


def context_or_default(context: Context | None = None) -> Context:
    """Return an explicit Context or the process default composition root.

    Args:
        context: Optional caller-owned Context.

    Returns:
        Context: The supplied Context or ``DEFAULT_CONTEXT``.

    Raises:
        TypeError: If ``context`` is not a Context.
    """
    selected = DEFAULT_CONTEXT if context is None else context
    if not isinstance(selected, Context):
        raise TypeError("Expected a heavenbase.context.Context")
    selected._need_open()
    return selected


__all__ = ["Context", "DEFAULT_CONTEXT", "context_or_default"]
