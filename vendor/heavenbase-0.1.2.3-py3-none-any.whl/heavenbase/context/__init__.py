"""Machine bootstrap and process-local service composition."""

from __future__ import annotations

from heavenbase._lazy import _attach_lazy_exports

__all__ = ["BootstrapSpec", "Context", "DEFAULT_CONTEXT", "context_or_default", "load_bootstrap"]

_LAZY_EXPORTS = {
    "BootstrapSpec": (".bootstrap", "BootstrapSpec"),
    "Context": (".runtime", "Context"),
    "DEFAULT_CONTEXT": (".runtime", "DEFAULT_CONTEXT"),
    "context_or_default": (".runtime", "context_or_default"),
    "load_bootstrap": (".bootstrap", "load_bootstrap"),
}

__getattr__, __dir__ = _attach_lazy_exports(__name__, globals(), _LAZY_EXPORTS, __all__)
