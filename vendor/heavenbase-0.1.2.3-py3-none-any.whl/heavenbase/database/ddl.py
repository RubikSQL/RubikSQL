"""Database create/drop helpers."""

from __future__ import annotations

__all__ = ["create_database", "drop_database"]

from sqlalchemy import create_engine, text

from ..utils.files import delete_file, exists_file, get_file_dir, touch_dir
from .config import DB_ENGINE, DBSpec

_MAINTENANCE_DBS = {"postgres", "mysql", "master", "default", "freepdb1", "system", "sys"}


def _server_ddl(spec: DBSpec, drop: bool = False, force: bool = False) -> None:
    dialect = spec.dialect_spec
    namespace = dialect.lifecycle_namespace(spec)
    if not namespace:
        return
    if drop and not force and namespace.lower() in _MAINTENANCE_DBS:
        raise ValueError(f"Refusing to drop maintenance database {namespace!r}")
    exists_sql = dialect.database_exists_sql()
    ddl_sql = dialect.drop_database_statement(namespace) if drop else dialect.create_database_statement(spec, namespace)
    if not ddl_sql:
        return
    kw = DB_ENGINE.apply(spec, profile="superuser")
    url = kw.pop("url")
    engine = create_engine(url, **kw)
    try:
        with engine.connect() as conn:
            exists = conn.execute(text(exists_sql), {"name": namespace}).scalar() if exists_sql else None
            if drop and exists_sql and not exists:
                return
            if not drop and exists_sql and exists:
                return
            for sql, params in dialect.before_drop_force_statements(namespace, force=force):
                conn.execute(text(sql), params or {})
            conn.execute(text(ddl_sql))
            for sql in dialect.after_create_statements(spec, namespace) if not drop else []:
                conn.execute(text(sql))
            conn.commit()
    finally:
        engine.dispose()


def create_database(spec: DBSpec) -> None:
    """Create the configured database namespace when supported.

    SQLite and DuckDB create parent folders only. Server backends use the superuser materialization from ``DBSpec`` and
    skip creation when the namespace already exists. Oracle treats the target namespace as ``schema``/``username`` because
    ``database`` is the PDB service name.

    Args:
        spec (DBSpec): Resolved database configuration.

    Returns:
        None: This function does not return a value.
    """
    dialect = spec.dialect_spec
    namespace = dialect.lifecycle_namespace(spec)
    if not namespace:
        return
    if dialect.supports("database-local-path"):
        if not spec.in_memory and spec.database:
            from ..utils.files import file_uri_to_path

            folder = get_file_dir(file_uri_to_path(spec.database))
            if folder:
                touch_dir(folder)
        return
    if dialect.supports("database-create"):
        _server_ddl(spec)


def drop_database(spec: DBSpec, *, force: bool = False) -> None:
    """Drop the configured database namespace when supported.

    Args:
        spec: Resolved database spec.
        force: Permit destructive drops for non-maintenance namespaces and request active-session cleanup where supported.

    Warnings:
        Maintenance namespaces such as ``postgres``, ``mysql``, ``master``, ``default``, ``FREEPDB1``, ``system``, and
        ``sys`` are refused unless ``force=True``. Trino catalogs are connector-managed and are intentionally left alone.

    Returns:
        None: This function does not return a value.
    """
    dialect = spec.dialect_spec
    namespace = dialect.lifecycle_namespace(spec)
    if not namespace:
        return
    if dialect.supports("database-local-path"):
        if not spec.in_memory and spec.database:
            from ..utils.files import file_uri_to_path

            database = file_uri_to_path(spec.database)
            for path in (database, f"{database}-wal", f"{database}-shm"):
                if exists_file(path):
                    delete_file(path)
        return
    if dialect.supports("database-drop"):
        _server_ddl(spec, drop=True, force=force)
