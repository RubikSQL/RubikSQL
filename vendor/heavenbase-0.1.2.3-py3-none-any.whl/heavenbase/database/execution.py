"""SQL execution and transaction helpers for the Database facade."""

from __future__ import annotations

import threading
import time

import sqlalchemy as sa
from sqlalchemy.sql.elements import ClauseElement

from ..utils.typing import Any, List, Optional, Sequence
from .readonly import is_sql_readonly
from .response import SQLResponse


class DatabaseError(RuntimeError):
    """Database execution error."""


class _DatabaseExecutionMixin:
    """Provide transaction state and SQL execution helpers for ``Database``."""

    def _init_execution_state(self) -> None:
        self._state = threading.local()
        self._conn = None
        self._tx_readonly: Optional[bool] = None
        self._tx_readonly_set = False
        self._tx_dirty = False
        self._tx_failed = False

    def _state_get(self, name: str, default: Any) -> Any:
        if not hasattr(self._state, name):
            setattr(self._state, name, default)
        return getattr(self._state, name)

    def _state_set(self, name: str, value: Any) -> None:
        setattr(self._state, name, value)

    def _lock_retry_config(self) -> tuple[int, float, float]:
        cfg = dict(self.spec.args.get("lock_retry") or {})
        attempts = max(1, int(cfg.get("attempts", 1) or 1))
        base_delay = max(0.0, float(cfg.get("base_delay", 0.0) or 0.0))
        max_delay = max(base_delay, float(cfg.get("max_delay", base_delay) or base_delay))
        return attempts, base_delay, max_delay

    def _retryable_lock_error(self, exc: Exception) -> bool:
        return self.dialect_spec.is_retryable_error(exc)

    def _execute_with_lock_retry(self, conn: Any, stmt: Any, params: Any = None) -> Any:
        attempts, base_delay, max_delay = self._lock_retry_config()
        for attempt in range(attempts):
            try:
                return conn.execute(stmt, params) if params is not None else conn.execute(stmt)
            except Exception as exc:
                if attempt + 1 >= attempts or not self._retryable_lock_error(exc):
                    raise
                delay = min(max_delay, base_delay * (2**attempt))
                if delay > 0:
                    time.sleep(delay)

    @property
    def _conn(self) -> Any:
        return self._state_get("conn", None)

    @_conn.setter
    def _conn(self, value: Any) -> None:
        self._state_set("conn", value)

    @property
    def _tx_readonly(self) -> Optional[bool]:
        return self._state_get("tx_readonly", None)

    @_tx_readonly.setter
    def _tx_readonly(self, value: Optional[bool]) -> None:
        self._state_set("tx_readonly", value)

    @property
    def _tx_readonly_set(self) -> bool:
        return bool(self._state_get("tx_readonly_set", False))

    @_tx_readonly_set.setter
    def _tx_readonly_set(self, value: bool) -> None:
        self._state_set("tx_readonly_set", value)

    @property
    def _tx_dirty(self) -> bool:
        return bool(self._state_get("tx_dirty", False))

    @_tx_dirty.setter
    def _tx_dirty(self, value: bool) -> None:
        self._state_set("tx_dirty", value)

    @property
    def _tx_failed(self) -> bool:
        return bool(self._state_get("tx_failed", False))

    @_tx_failed.setter
    def _tx_failed(self, value: bool) -> None:
        self._state_set("tx_failed", value)

    def __call__(self, readonly: Optional[bool] = False) -> "_DatabaseExecutionMixin":
        """Configure this facade as a transaction context manager.

        Args:
            readonly: Optional transaction-level readonly mode. ``False`` is mutating by default, ``True`` rejects mutating
                statements, and ``None`` enables conservative auto-detection.

        Returns:
            _DatabaseExecutionMixin: This facade, ready for context-manager entry.
        """
        self._tx_readonly = readonly
        self._tx_readonly_set = True
        return self

    def tx(self, readonly: Optional[bool] = False) -> "_DatabaseExecutionMixin":
        """Return this database configured as a transaction context manager.

        Args:
            readonly: Optional transaction-level readonly mode. ``False`` is mutating by default, ``True`` rejects mutating
                statements, and ``None`` enables conservative auto-detection.

        Returns:
            _DatabaseExecutionMixin: This facade, ready for ``with db.tx():``.

        Example:
            ``with db.tx(readonly=None) as tx: tx.execute("SELECT 1")`` auto-detects reads, while leaving default calls
            in the same transaction on the mutating path.
        """
        return self(readonly=readonly)

    def in_transaction(self) -> bool:
        """Return whether this facade currently owns an active transaction.

        Args:
            None.

        Returns:
            bool: ``True`` when this facade owns an open SQLAlchemy transaction.
        """
        return self._conn is not None and self._conn.in_transaction()

    def commit(self) -> None:
        """Commit the active transaction context, if any.

        Args:
            None.

        Returns:
            None: This method commits the current transaction and starts a fresh transaction inside the same context.

        Raises:
            DatabaseError: If a previous safe execution failed and the transaction must be rolled back first.
        """
        if self._tx_failed:
            raise DatabaseError("Cannot commit after a safe execution failure; call rollback() before continuing")
        if self._conn is not None and self._conn.in_transaction():
            self._conn.commit()
            self._conn.begin()
        self._tx_dirty = False

    def rollback(self) -> None:
        """Rollback the active transaction context, if any.

        Args:
            None.

        Returns:
            None: This method rolls back the current transaction and starts a fresh transaction inside the same context.
        """
        if self._conn is not None and self._conn.in_transaction():
            self._conn.rollback()
            self._conn.begin()
        self._tx_dirty = False
        self._tx_failed = False

    def __enter__(self) -> "_DatabaseExecutionMixin":
        """Open a transaction context for this facade.

        Args:
            None.

        Returns:
            _DatabaseExecutionMixin: This facade with an active connection and transaction.

        Raises:
            DatabaseError: If this facade already owns an active transaction.
        """
        if self._conn is not None:
            raise DatabaseError("Nested Database transactions are not supported; use clone() for parallel work")
        self._conn = self.engine.connect()
        self._conn.begin()
        self._tx_dirty = False
        self._tx_failed = False
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        """Close a transaction context, committing only successful dirty work.

        Args:
            exc_type: Exception type raised inside the context, if any.
            exc_val: Exception value raised inside the context, if any.
            exc_tb: Exception traceback raised inside the context, if any.

        Returns:
            bool: Always ``False`` so caller exceptions propagate normally.
        """
        try:
            if self._conn is not None and self._conn.in_transaction():
                self._conn.rollback() if exc_type is not None or self._tx_failed or not self._tx_dirty else self._conn.commit()
        finally:
            if self._conn is not None:
                self._conn.close()
            self._conn = None
            self._tx_readonly = None
            self._tx_readonly_set = False
            self._tx_dirty = False
            self._tx_failed = False
        return False

    def _readonly(self, stmt: Any, query_text: Optional[str], readonly: Optional[bool]) -> bool:
        readonly = self._tx_readonly if readonly is False and self._conn is not None and self._tx_readonly_set else readonly
        inferred = is_sql_readonly(stmt, query_text=query_text, dialect=self.dialect, dialect_spec=self.dialect_spec) if readonly is not False else False
        if readonly is True and not inferred:
            raise DatabaseError("readonly=True rejects mutating SQL")
        return bool(inferred)

    def _schema_mutation(self, query_text: Optional[str]) -> bool:
        token = (query_text or "").strip().split(maxsplit=1)[0].lower() if (query_text or "").strip() else ""
        return token in {"alter", "create", "drop", "rename", "truncate"}

    def _invalidate_if_schema_mutation(self, query_text: Optional[str]) -> None:
        if self._schema_mutation(query_text):
            self.invalidate_schema_index()

    def _response(
        self, conn: Any, stmt: Any, params: Any, query_text: Optional[str], readonly: Optional[bool], autocommit: Optional[bool], safe: bool
    ) -> SQLResponse:
        query_readonly = self._readonly(stmt, query_text, readonly)
        if self._conn is None and autocommit is False:
            raise DatabaseError("autocommit=False requires a transaction context: use with db.tx():")
        t0 = time.perf_counter()
        try:
            result = self._execute_with_lock_retry(conn, stmt, params)
            elapsed = time.perf_counter() - t0
            resp = SQLResponse.from_cursor(result, query=query_text or str(stmt), params=params, elapsed=elapsed)
            if self._conn is not None:
                resp.cache()
                if not query_readonly:
                    self._tx_dirty = True
                self._invalidate_if_schema_mutation(query_text or str(stmt))
                if autocommit is True and self._conn.in_transaction():
                    self._conn.commit()
                    self._conn.begin()
                    self._tx_dirty = False
            return resp
        except Exception as exc:
            if self._conn is not None:
                self._tx_failed = True
                if autocommit is True and self._conn.in_transaction():
                    self._conn.rollback()
                    self._conn.begin()
                    self._tx_dirty = False
                    self._tx_failed = False
            if safe:
                return SQLResponse.from_error(exc, query=query_text or str(stmt), params=params, elapsed=time.perf_counter() - t0)
            raise DatabaseError(f"Database execution failed: {exc}\nQuery: {query_text or stmt}\nParams: {params}") from exc

    def _exec(
        self,
        stmt: Any,
        params: Any = None,
        *,
        query_text: Optional[str] = None,
        autocommit: Optional[bool] = None,
        readonly: Optional[bool] = False,
        safe: bool = False,
    ) -> SQLResponse:
        if self._conn is not None:
            return self._response(self._conn, stmt, params, query_text, readonly, autocommit, safe)
        conn = None
        tx = None
        close_response = None

        try:
            conn = self.engine.connect()
            tx = conn.begin()
            query_readonly = self._readonly(stmt, query_text, readonly)

            def _close_response() -> None:
                try:
                    if tx.is_active:
                        tx.rollback() if query_readonly else tx.commit()
                finally:
                    conn.close()

            close_response = _close_response
            t0 = time.perf_counter()
            result = self._execute_with_lock_retry(conn, stmt, params)
            elapsed = time.perf_counter() - t0
            self._invalidate_if_schema_mutation(query_text or str(stmt))
            if result.returns_rows:
                return SQLResponse.from_cursor(result, query=query_text or str(stmt), params=params, elapsed=elapsed, close=close_response)
            resp = SQLResponse.from_cursor(result, query=query_text or str(stmt), params=params, elapsed=elapsed)
            tx.rollback() if query_readonly else tx.commit()
            conn.close()
            return resp
        except Exception as exc:
            if close_response is not None:
                close_response()
            else:
                tx.rollback() if tx is not None and tx.is_active else None
                conn.close() if conn is not None else None
            if safe:
                return SQLResponse.from_error(exc, query=query_text or str(stmt), params=params)
            raise DatabaseError(f"Database execution failed: {exc}\nQuery: {query_text or stmt}\nParams: {params}") from exc

    def execute(
        self,
        query: Any,
        params: Any = None,
        *,
        transpile: Optional[str] = None,
        autocommit: Optional[bool] = None,
        safe: bool = False,
        readonly: Optional[bool] = False,
        **kwargs: Any,
    ) -> SQLResponse:
        """Execute raw SQL or a SQLAlchemy statement.

        Args:
            query: Raw SQL text, ``sqlalchemy.text(...)``, or another SQLAlchemy clause element.
            params: Optional execution parameters. Raw SQL accepts ``:name``, ``?``, ``%s``, ``%(name)s``, ``$name``, and
                ``$1`` style placeholders; they are normalized to SQLAlchemy named binds before execution. Batch execution
                accepts ``List[Dict]`` or ``List[Tuple]`` where supported by the driver.
            transpile: Optional source dialect for SQLGlot transpilation.
            autocommit: ``False`` requires an existing ``with db.tx():`` block. ``None`` and ``True`` both allow standalone execution.
            safe: Return ``SQLResponse(ok=False)`` instead of raising on execution errors.
            readonly: ``False`` executes as mutating by default. ``True`` rejects statements that are not confidently
                read-only. ``None`` enables conservative auto-detection for commit/rollback behavior.
            **kwargs: Reserved for future execution options.

        Returns:
            SQLResponse: Reusable execution response with cached/lazy rows and export helpers.

        Warnings:
            ``readonly=True`` is a guard, not a SQL firewall. It rejects obvious mutating statements but should not be used as a
            complete security sandbox for untrusted SQL.
        """
        if isinstance(query, ClauseElement):
            return self.orm_execute(query, params=params, autocommit=autocommit, readonly=readonly, safe=safe)
        sql, out_params = self.sql_processor.process(str(query), params, transpile_from=transpile)
        return self._exec(sa.text(sql), out_params, query_text=sql, autocommit=autocommit, readonly=readonly, safe=safe)

    def execute_many(
        self,
        queries: Sequence[Any],
        params: Optional[Sequence[Any]] = None,
        *,
        transpile: Optional[str] = None,
        autocommit: Optional[bool] = None,
        safe: bool = False,
        readonly: Optional[bool] = False,
    ) -> List[SQLResponse]:
        """Execute multiple commands in one transaction context.

        Args:
            queries: SQL strings or SQLAlchemy statements to execute in order.
            params: Optional per-query parameter sequence. Length must match ``queries``.
            transpile: Optional source dialect for raw SQL strings.
            autocommit: Optional inline commit behavior for each statement.
            safe: Return failed responses instead of raising where supported.
            readonly: ``False`` treats all statements as mutating, ``True`` rejects mutating statements, and ``None``
                enables conservative per-statement auto-detection.

        Returns:
            List[SQLResponse]: Responses in input order.

        Warnings:
            The method opens one transaction context around all statements. With ``safe=True`` and ``autocommit`` not set to
            ``True``, the first failed response stops the batch and the context rolls back. Use ``autocommit=True`` only when
            explicit best-effort, per-statement commits are desired.
        """
        args = list(params) if params is not None else [None] * len(queries)
        if len(args) != len(queries):
            raise ValueError("execute_many params length must match queries length")
        with self.tx(readonly=readonly) as tx:
            res = []
            for query, param in zip(queries, args):
                resp = tx.execute(query, param, transpile=transpile, autocommit=autocommit, safe=safe, readonly=readonly)
                res.append(resp)
                if safe and not resp.ok and autocommit is not True:
                    break
            return res

    def orm_execute(
        self, stmt: Any, params: Any = None, *, autocommit: Optional[bool] = None, readonly: Optional[bool] = False, safe: bool = False
    ) -> SQLResponse:
        """Execute a SQLAlchemy statement.

        Args:
            stmt: SQLAlchemy ``ClauseElement`` such as ``select(...)``, ``insert(...)``, or DDL.
            params: Optional execution parameters.
            autocommit: ``False`` requires an existing transaction context.
            readonly: ``False`` executes as mutating by default. ``True`` rejects statements that are not confidently
                read-only. ``None`` enables conservative auto-detection for commit/rollback behavior.
            safe: Return ``SQLResponse(ok=False)`` instead of raising on execution errors.

        Returns:
            SQLResponse: Reusable execution response.
        """
        if not isinstance(stmt, ClauseElement):
            raise TypeError("orm_execute expects a SQLAlchemy ClauseElement")
        return self._exec(stmt, params, autocommit=autocommit, readonly=readonly, safe=safe)

    def orm_execute_many(
        self,
        stmts: Sequence[Any],
        params: Optional[Sequence[Any]] = None,
        *,
        autocommit: Optional[bool] = None,
        readonly: Optional[bool] = False,
        safe: bool = False,
    ) -> List[SQLResponse]:
        """Execute multiple SQLAlchemy statements in one transaction context.

        Args:
            stmts: SQLAlchemy clause elements to execute in order.
            params: Optional per-statement parameter sequence. Length must match ``stmts`` when provided.
            autocommit: Optional inline commit behavior for each statement.
            readonly: ``False`` treats all statements as mutating, ``True`` rejects mutating statements, and ``None``
                enables conservative per-statement auto-detection.
            safe: Return failed responses instead of raising where supported.

        Returns:
            List[SQLResponse]: Responses in input order.

        Warnings:
            With ``safe=True`` and ``autocommit`` not set to ``True``, the first failed response stops the batch and rolls
            back the surrounding transaction. ``autocommit=True`` opts into best-effort per-statement commits.
        """
        args = list(params) if params is not None else [None] * len(stmts)
        if len(args) != len(stmts):
            raise ValueError("orm_execute_many params length must match stmts length")
        with self.tx(readonly=readonly) as tx:
            res = []
            for stmt, param in zip(stmts, args):
                resp = tx.orm_execute(stmt, params=param, autocommit=autocommit, readonly=readonly, safe=safe)
                res.append(resp)
                if safe and not resp.ok and autocommit is not True:
                    break
            return res
