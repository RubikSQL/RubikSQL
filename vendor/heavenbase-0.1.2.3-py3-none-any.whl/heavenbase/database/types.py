"""SQLAlchemy type decorators used by SQL-family backends."""

from __future__ import annotations

__all__ = [
    "DatabaseBigIntegerType",
    "DatabaseBlobType",
    "DatabaseBooleanType",
    "DatabaseIntegerType",
    "DatabaseJsonType",
    "DatabaseTextType",
    "DatabaseVectorType",
]

import sqlalchemy as sa
import sqlalchemy.dialects.mysql as sa_mysql
import sqlalchemy.dialects.oracle as sa_oracle
import sqlalchemy.dialects.postgresql as sa_pg
import sqlalchemy.types as sa_types

from heavenbase.utils.typing import Any
from heavenbase.utils.serialize import dumps_b64, dumps_json, loads_b64, loads_json

from .dialect.spec import (
    SQL_TYPE_CLOB,
    SQL_TYPE_FLOAT_ARRAY,
    SQL_TYPE_JSON,
    SQL_TYPE_MYSQL_TEXT,
    SQL_TYPE_POSTGRESQL_JSONB,
    SQL_TYPE_STRING,
    SQL_TYPE_TEXT,
    DatabaseDialectSpec,
)
from .dialect.registry import database_dialects


def _text_type(kind: str, length: int | None = None, *, max_chars: int = 65535) -> Any:
    if kind == SQL_TYPE_CLOB:
        return sa_oracle.CLOB()
    if kind == SQL_TYPE_MYSQL_TEXT:
        return _mysql_text_type(length)
    if kind == SQL_TYPE_TEXT:
        return sa_types.Text()
    return sa_types.String(length if kind != SQL_TYPE_STRING else length or max_chars)


def _mysql_text_type(length: int | None) -> Any:
    """Choose a MySQL text family that can hold `length` utf8mb4 characters."""
    if length is None:
        return sa_mysql.TEXT()
    max_bytes = int(length) * 4
    if max_bytes <= 255:
        return sa_mysql.TINYTEXT()
    if max_bytes <= 65_535:
        return sa_mysql.TEXT()
    if max_bytes <= 16_777_215:
        return sa_mysql.MEDIUMTEXT()
    return sa_mysql.LONGTEXT()


def _native_json_type(kind: str | None) -> Any | None:
    if kind == SQL_TYPE_POSTGRESQL_JSONB:
        return sa_pg.JSONB()
    if kind == SQL_TYPE_JSON:
        return sa_types.JSON()
    return None


def _native_vector_type(kind: str | None) -> Any | None:
    if kind == SQL_TYPE_FLOAT_ARRAY:
        return sa.ARRAY(sa_types.Float())
    return None


def _bound_dialect(dialect: Any, spec: DatabaseDialectSpec | None) -> DatabaseDialectSpec:
    """Return explicit type metadata, falling back only for standalone use."""
    if spec is None:
        return database_dialects.get(dialect.name)
    name = str(dialect.name).strip().lower()
    if name != "default" and name not in {spec.identifier, *spec.sqlalchemy_aliases}:
        raise ValueError(f"Bound database dialect {spec.identifier!r} cannot compile SQLAlchemy dialect {name!r}")
    return spec


class DatabaseTextType(sa_types.TypeDecorator):
    """Portable text type."""

    impl = sa_types.String
    cache_ok = True

    def __init__(
        self,
        *args: Any,
        dialect_spec: DatabaseDialectSpec | None = None,
        max_chars: int = 65535,
        **kwargs: Any,
    ) -> None:
        """Create a portable text type decorator.

        Args:
            *args (Any): Positional arguments forwarded to ``TypeDecorator``.
            dialect_spec (DatabaseDialectSpec | None): Bound dialect metadata used for
                overflow and text-threshold selection.
            max_chars (int): Maximum string length used by text fallback types.
            **kwargs (Any): Keyword arguments forwarded to ``TypeDecorator``.

        Returns:
            None: This function does not return a value.
        """
        self.dialect_spec = dialect_spec
        self.max_chars = int(max_chars)
        super().__init__(*args, **kwargs)

    def load_dialect_impl(self, dialect):
        """Return the concrete SQLAlchemy text type for one SQL dialect.

        Args:
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any: Concrete SQLAlchemy text or string implementation.
        """
        spec = _bound_dialect(dialect, self.dialect_spec)
        varchar_max = spec.varchar_max
        if varchar_max is not None and self.length and self.length > varchar_max:
            return dialect.type_descriptor(_text_type(spec.varchar_overflow_type, self.length, max_chars=self.max_chars))
        text_min_len = spec.text_min_len
        if text_min_len is not None and self.length and self.length >= text_min_len:
            return dialect.type_descriptor(_text_type(spec.text_threshold_type, self.length, max_chars=self.max_chars))
        return dialect.type_descriptor(sa_types.String(self.length))

    def process_bind_param(self, value, dialect):
        """Convert Python values to database text parameters.

        Args:
            value: Python value bound to the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            str | None: Database text parameter, or ``None`` for SQL NULL.
        """
        return None if value is None else str(value)

    def process_result_value(self, value, dialect):
        """Convert database text values back to Python strings.

        Args:
            value: Database value read from the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            str | None: Python string, or ``None`` for SQL NULL.
        """
        return None if value is None else str(value)


class DatabaseIntegerType(sa_types.TypeDecorator):
    """Portable integer type."""

    impl = sa_types.Integer
    cache_ok = True

    def process_bind_param(self, value, dialect):
        """Convert Python values to database integer parameters.

        Args:
            value: Python value bound to the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            int | None: Database integer parameter, or ``None`` for SQL NULL.
        """
        return None if value is None else int(value)

    def process_result_value(self, value, dialect):
        """Convert database integer values back to Python integers.

        Args:
            value: Database value read from the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            int | None: Python integer, or ``None`` for SQL NULL.
        """
        return None if value is None else int(value)


class DatabaseBigIntegerType(DatabaseIntegerType):
    """Portable 64-bit integer type."""

    impl = sa_types.BigInteger
    cache_ok = True


class DatabaseBooleanType(sa_types.TypeDecorator):
    """Portable boolean type."""

    impl = sa_types.Boolean
    cache_ok = True

    def process_bind_param(self, value, dialect):
        """Convert Python values to database boolean parameters.

        Args:
            value: Python value bound to the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            bool | None: Database boolean parameter, or ``None`` for SQL NULL.
        """
        return None if value is None else bool(value)

    def process_result_value(self, value, dialect):
        """Convert database boolean values back to Python booleans.

        Args:
            value: Database value read from the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            bool | None: Python boolean, or ``None`` for SQL NULL.
        """
        return None if value is None else bool(value)


class DatabaseBlobType(sa_types.TypeDecorator):
    """Portable Artifact storage with native BLOB or base64 TEXT fallback."""

    impl = sa_types.LargeBinary
    cache_ok = True

    def __init__(
        self,
        *args: Any,
        dialect_spec: DatabaseDialectSpec | None = None,
        max_chars: int = 65535,
        **kwargs: Any,
    ) -> None:
        """Create a portable artifact blob type decorator.

        Args:
            *args (Any): Positional arguments forwarded to ``TypeDecorator``.
            dialect_spec (DatabaseDialectSpec | None): Bound dialect metadata used to
                choose native blob storage or base64 text fallback.
            max_chars (int): Maximum string length used by text fallback storage.
            **kwargs (Any): Keyword arguments forwarded to ``TypeDecorator``.

        Returns:
            None: This function does not return a value.
        """
        self.dialect_spec = dialect_spec
        self.max_chars = int(max_chars)
        super().__init__(*args, **kwargs)

    def _uses_native_blob(self, dialect) -> bool:
        return _bound_dialect(dialect, self.dialect_spec).supports("database-blob-native")

    def load_dialect_impl(self, dialect):
        """Return the concrete blob or text fallback type for one dialect.

        Args:
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any: Native ``LargeBinary`` implementation or text fallback type.
        """
        if self._uses_native_blob(dialect):
            return dialect.type_descriptor(sa_types.LargeBinary())
        return dialect.type_descriptor(_text_type(_bound_dialect(dialect, self.dialect_spec).blob_text_type, max_chars=self.max_chars))

    def _to_bind_value(self, value: Any) -> bytes:
        if value is None:
            return None
        if isinstance(value, str):
            return loads_b64(value)
        if isinstance(value, memoryview):
            return bytes(value)
        if isinstance(value, bytearray):
            return bytes(value)
        if isinstance(value, bytes):
            return value
        raise TypeError(f"Artifact expects bytes, got {type(value).__name__}")

    def process_bind_param(self, value, dialect):
        """Convert artifact bytes to native blob or base64 text storage.

        Args:
            value: Artifact bytes, base64 text, or compatible buffer value.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            bytes | str | None: Native blob value, base64 text fallback, or ``None``.

        Raises:
            TypeError: If ``value`` is not bytes-compatible artifact data.
        """
        if value is None:
            return None
        data = self._to_bind_value(value)
        return data if self._uses_native_blob(dialect) else dumps_b64(data)

    def process_result_value(self, value, dialect):
        """Convert database blob or base64 text values back to artifact data.

        Args:
            value: Database blob or base64 text value.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            bytes | str | None: Artifact bytes for native storage, base64 text for
            fallback storage, or ``None`` for SQL NULL.
        """
        if value is None:
            return None
        if self._uses_native_blob(dialect):
            return bytes(value) if not isinstance(value, bytes) else value
        return str(value)


class DatabaseJsonType(sa_types.TypeDecorator):
    """Portable JSON type with string fallback."""

    impl = sa_types.String
    cache_ok = True

    def __init__(
        self,
        *args: Any,
        dialect_spec: DatabaseDialectSpec | None = None,
        max_chars: int = 65535,
        **kwargs: Any,
    ) -> None:
        """Create a portable JSON type decorator.

        Args:
            *args (Any): Positional arguments forwarded to ``TypeDecorator``.
            dialect_spec (DatabaseDialectSpec | None): Bound dialect metadata used to
                choose native JSON storage or string fallback.
            max_chars (int): Maximum string length used by JSON text fallback.
            **kwargs (Any): Keyword arguments forwarded to ``TypeDecorator``.

        Returns:
            None: This function does not return a value.
        """
        self.dialect_spec = dialect_spec
        self.max_chars = int(max_chars)
        super().__init__(*args, **kwargs)

    def _native_impl(self, dialect):
        return _native_json_type(_bound_dialect(dialect, self.dialect_spec).json_native_type)

    def _string_impl(self, dialect):
        return _text_type(_bound_dialect(dialect, self.dialect_spec).json_text_type, max_chars=self.max_chars)

    def load_dialect_impl(self, dialect):
        """Return the concrete JSON or string fallback type for one dialect.

        Args:
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any: Native JSON implementation or string fallback type.
        """
        native = self._native_impl(dialect)
        if native is not None and _bound_dialect(dialect, self.dialect_spec).supports("database-json-native"):
            return dialect.type_descriptor(native)
        return dialect.type_descriptor(self._string_impl(dialect))

    def process_bind_param(self, value, dialect):
        """Convert Python JSON payloads to database parameters.

        Args:
            value: Python JSON-compatible payload bound to the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any | None: Native JSON value, serialized JSON text, or ``None``.
        """
        if value is None:
            return None
        return value if _bound_dialect(dialect, self.dialect_spec).supports("database-json-native") else dumps_json(value, compact=True)

    def process_result_value(self, value, dialect):
        """Convert database JSON values back to Python payloads.

        Args:
            value: Database JSON or text value read from the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any | None: Python JSON payload, or ``None`` for SQL NULL.
        """
        if value is None:
            return None
        return value if _bound_dialect(dialect, self.dialect_spec).supports("database-json-native") else loads_json(value)


class DatabaseVectorType(sa_types.TypeDecorator):
    """Portable vector type using native PostgreSQL arrays when possible."""

    impl = DatabaseJsonType
    cache_ok = True

    def __init__(
        self,
        *args: Any,
        dialect_spec: DatabaseDialectSpec | None = None,
        max_chars: int = 65535,
        **kwargs: Any,
    ) -> None:
        """Create a portable vector type decorator.

        Args:
            *args (Any): Positional arguments forwarded to ``TypeDecorator``.
            dialect_spec (DatabaseDialectSpec | None): Bound dialect metadata used to
                choose native array storage or JSON fallback.
            max_chars (int): Maximum string length used by JSON fallback storage.
            **kwargs (Any): Keyword arguments forwarded to ``TypeDecorator``.

        Returns:
            None: This function does not return a value.
        """
        # TypeDecorator constructs ``impl`` from the forwarded arguments, but
        # those values are not retained on the outer decorator.  Vector bind
        # and result processing run on that outer instance, so keep the exact
        # dialect authority there as well as on its JSON implementation.
        self.dialect_spec = dialect_spec
        self.max_chars = int(max_chars)
        super().__init__(*args, dialect_spec=dialect_spec, max_chars=max_chars, **kwargs)

    def load_dialect_impl(self, dialect):
        """Return native PostgreSQL array storage or the JSON fallback type.

        Args:
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            Any: Native float array implementation or JSON fallback type.
        """
        native = _native_vector_type(_bound_dialect(dialect, self.dialect_spec).vector_native_type)
        return (
            dialect.type_descriptor(native)
            if native is not None
            else DatabaseJsonType(dialect_spec=self.dialect_spec, max_chars=self.max_chars).load_dialect_impl(dialect)
        )

    def process_bind_param(self, value, dialect):
        """Convert vector values to database parameters.

        Args:
            value: Iterable of numeric vector components.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            list[float] | str | None: Native float list, JSON fallback text, or ``None``.
        """
        if value is None:
            return None
        vec = [float(item) for item in value]
        return (
            vec
            if _bound_dialect(dialect, self.dialect_spec).vector_native_type is not None
            else DatabaseJsonType(dialect_spec=self.dialect_spec, max_chars=self.max_chars).process_bind_param(vec, dialect)
        )

    def process_result_value(self, value, dialect):
        """Convert database vector values back to lists of floats.

        Args:
            value: Database array or JSON fallback value read from the column.
            dialect: Live SQLAlchemy dialect compiling this type.

        Returns:
            list[float] | None: Python float vector, or ``None`` for SQL NULL.
        """
        if value is None:
            return None
        if _bound_dialect(dialect, self.dialect_spec).vector_native_type is not None:
            return [float(item) for item in value]
        return [float(item) for item in DatabaseJsonType(dialect_spec=self.dialect_spec, max_chars=self.max_chars).process_result_value(value, dialect)]
