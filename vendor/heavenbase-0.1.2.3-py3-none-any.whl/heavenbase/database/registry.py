"""Thread-safe SQLAlchemy engine and schema-index cache."""

from __future__ import annotations

__all__ = ["DatabaseEngineRegistry"]

import threading
from collections import OrderedDict
from weakref import WeakValueDictionary

from ..utils.typing import Any, Callable, Mapping, Sequence, deepcopy
from . import engine as db_engine
from .schema_index import SchemaIndex, normalize_schema_index
from .config import DB_ENGINE, DBSpec


class DatabaseEngineRegistry:
    """Cache SQLAlchemy engines and schema indexes by resolved database spec."""

    _CACHE_MAX = 2048
    _engines: "OrderedDict[str, Any]" = OrderedDict()
    _schema_indices: "OrderedDict[str, SchemaIndex]" = OrderedDict()
    _disposed: set[str] = set()
    _authorities: "WeakValueDictionary[str, Any]" = WeakValueDictionary()
    _lock = threading.Lock()

    @staticmethod
    def _authority(authority_id: int | str | None) -> str:
        """Return the normalized authority segment used by cache keys."""
        return "standalone" if authority_id is None else str(authority_id)

    @classmethod
    def bind_authority(cls, authority_id: int | str | None, owner: Any) -> None:
        """Weakly bind one cache namespace to its lifecycle owner.

        Args:
            authority_id (int | str | None): Cache authority segment, or ``None`` for
                standalone facades.
            owner (Any): Lifecycle owner whose retirement should dispose cached engines.

        Returns:
            None: This function does not return a value.

        Raises:
            ValueError: If ``authority_id`` is already bound to a different owner.
        """
        authority = cls._authority(authority_id)
        if authority == "standalone" or owner is None:
            return
        try:
            with cls._lock:
                existing = cls._authorities.get(authority)
                if existing is not None and existing is not owner:
                    existing_token = getattr(existing, "authority_token", None)
                    owner_token = getattr(owner, "authority_token", None)
                    if str(existing_token) != authority or str(owner_token) != authority:
                        raise ValueError(f"Database authority {authority!r} is already bound to another owner")
                cls._authorities[authority] = owner
        except TypeError:
            return

    @classmethod
    def _authority_disposed(cls, authority: str) -> bool:
        """Return whether a weakly bound owner retired this exact generation."""
        owner = cls._authorities.get(authority)
        if owner is None:
            return False
        context = getattr(getattr(owner, "authority_config", None), "_context", None)
        for lifecycle in (owner, context):
            if lifecycle is not None and (
                bool(getattr(lifecycle, "_closed", False)) or bool(getattr(lifecycle, "_closing", False)) or bool(getattr(lifecycle, "_resetting", False))
            ):
                return True
        current = getattr(owner, "authority_token", None)
        if current is not None and str(current) != authority:
            return True
        context_token = getattr(context, "authority_token", None)
        if context_token is not None and str(context_token) != authority:
            return True
        return getattr(owner, "_active", True) is False

    @classmethod
    def key(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> str:
        """Return the cache key for a resolved database spec.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            str: Stable engine-cache key.
        """
        key = f"{cls._authority(authority_id)}:{DB_ENGINE.apply(spec, profile='cache-key')}"
        return f"{key}:{resource_id}" if resource_id else key

    @classmethod
    def clear_disposed(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Allow a newly created facade to create a fresh engine.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            None: This function does not return a value.
        """
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)):
                raise RuntimeError("Database authority has been disposed")
            cls._disposed.discard(cls.key(spec, authority_id=authority_id, resource_id=resource_id))

    @classmethod
    def is_disposed(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> bool:
        """Return whether this spec key has been disposed.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            bool: `True` when the engine key is marked disposed.
        """
        with cls._lock:
            return (
                cls._authority_disposed(cls._authority(authority_id))
                or cls.key(
                    spec,
                    authority_id=authority_id,
                    resource_id=resource_id,
                )
                in cls._disposed
            )

    @classmethod
    def has_engine(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> bool:
        """Return whether this spec currently has a cached engine.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            bool: `True` when an active engine is cached for `spec`.
        """
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)):
                return False
            return cls.key(spec, authority_id=authority_id, resource_id=resource_id) in cls._engines

    @classmethod
    def get(
        cls,
        spec: DBSpec,
        autocreate: bool = True,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> Any:
        """Return a cached engine or create one.

        Args:
            spec (DBSpec): Resolved database configuration.
            autocreate (bool): Whether newly created engines should attempt namespace creation first.

        Returns:
            Any: SQLAlchemy engine for `spec`.

        Raises:
            RuntimeError: If the engine key was disposed before or during creation.
        """
        key = cls.key(spec, authority_id=authority_id, resource_id=resource_id)
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)) or key in cls._disposed:
                raise RuntimeError("Engine has been disposed. Create a new Database instance.")
            if key in cls._engines:
                cls._engines.move_to_end(key)
                return cls._engines[key]
        engine = db_engine.create_database_engine(spec, autocreate=autocreate)
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)) or key in cls._disposed:
                engine.dispose()
                raise RuntimeError("Engine has been disposed. Create a new Database instance.")
            if key in cls._engines:
                engine.dispose()
                cls._engines.move_to_end(key)
                return cls._engines[key]
            if len(cls._engines) >= cls._CACHE_MAX:
                old_key, old = cls._engines.popitem(last=False)
                cls._schema_indices.pop(old_key, None)
                old.dispose()
            cls._engines[key] = engine
            return engine

    @classmethod
    def get_schema_index(
        cls,
        spec: DBSpec,
        *,
        builder: Callable[[], Mapping[str, Sequence[str]] | dict[str, Any]] | None = None,
        refresh: bool = False,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> SchemaIndex:
        """Return cached schema-index data for a database key.

        Args:
            spec (DBSpec): Resolved database configuration.
            builder (Callable[[], Mapping[str, Sequence[str]] | dict[str, Any]] | None): Optional callback that
                builds fresh schema-index data when the cache is empty or `refresh=True`.
            refresh (bool): Whether to rebuild the schema index even when cached data exists.

        Returns:
            SchemaIndex: Detached schema index for the database key.

        Raises:
            RuntimeError: If the engine key was disposed.
        """
        key = cls.key(spec, authority_id=authority_id, resource_id=resource_id)
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)) or key in cls._disposed:
                raise RuntimeError("Engine has been disposed. Create a new Database instance.")
            if not refresh and key in cls._schema_indices:
                cls._schema_indices.move_to_end(key)
                return deepcopy(cls._schema_indices[key])
        if builder is None:
            return {}
        schema_index = normalize_schema_index(builder())
        with cls._lock:
            if not cls._authority_disposed(cls._authority(authority_id)) and key not in cls._disposed:
                cls._schema_indices[key] = deepcopy(schema_index)
                cls._schema_indices.move_to_end(key)
                while len(cls._schema_indices) > cls._CACHE_MAX:
                    cls._schema_indices.popitem(last=False)
        return deepcopy(schema_index)

    @classmethod
    def set_schema_index(
        cls,
        spec: DBSpec,
        schema_index: Mapping[str, Sequence[str]] | dict[str, Any] | None,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Set the schema-index cache for a database key.

        Args:
            spec (DBSpec): Resolved database configuration.
            schema_index (Mapping[str, Sequence[str]] | dict[str, Any] | None): Raw schema-index data accepted by
                `normalize_schema_index`.

        Returns:
            None: This function does not return a value.

        Raises:
            RuntimeError: If the engine key was disposed.
            ValueError: If `schema_index` has an unsupported shape.
        """
        key = cls.key(spec, authority_id=authority_id, resource_id=resource_id)
        with cls._lock:
            if cls._authority_disposed(cls._authority(authority_id)) or key in cls._disposed:
                raise RuntimeError("Engine has been disposed. Create a new Database instance.")
            cls._schema_indices[key] = normalize_schema_index(schema_index)
            cls._schema_indices.move_to_end(key)
            while len(cls._schema_indices) > cls._CACHE_MAX:
                cls._schema_indices.popitem(last=False)

    @classmethod
    def invalidate_schema_index(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Remove cached schema-index data for one spec.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            None: This function does not return a value.
        """
        with cls._lock:
            cls._schema_indices.pop(cls.key(spec, authority_id=authority_id, resource_id=resource_id), None)

    @classmethod
    def dispose(
        cls,
        spec: DBSpec,
        *,
        authority_id: int | str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Dispose one cached engine.

        Args:
            spec (DBSpec): Resolved database configuration.

        Returns:
            None: This function does not return a value.
        """
        key = cls.key(spec, authority_id=authority_id, resource_id=resource_id)
        with cls._lock:
            engine = cls._engines.pop(key, None)
            cls._schema_indices.pop(key, None)
            cls._disposed.add(key)
        if engine is not None:
            engine.dispose()

    @classmethod
    def dispose_authority(cls, authority_id: int | str) -> None:
        """Dispose and permanently retire every engine owned by one authority.

        Args:
            authority_id (int | str): Cache authority segment whose engines should be
                disposed.

        Returns:
            None: This function does not return a value.
        """
        authority = cls._authority(authority_id)
        prefix = f"{authority}:"
        with cls._lock:
            keys = tuple(key for key in cls._engines if key.startswith(prefix))
            engines = [cls._engines.pop(key) for key in keys]
            for key in tuple(cls._schema_indices):
                if key.startswith(prefix):
                    cls._schema_indices.pop(key, None)
            cls._disposed.difference_update(key for key in tuple(cls._disposed) if key.startswith(prefix))
        for engine in engines:
            engine.dispose()

    @classmethod
    def dispose_all(cls) -> None:
        """Dispose every cached engine.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        with cls._lock:
            engines = list(cls._engines.values())
            cls._disposed.update(cls._engines.keys())
            cls._engines.clear()
            cls._schema_indices.clear()
        for engine in engines:
            engine.dispose()
