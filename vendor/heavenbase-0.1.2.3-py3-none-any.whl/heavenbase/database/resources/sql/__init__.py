"""SQL templates owned by the database domain."""

from __future__ import annotations

from .base import SqlTemplate
from .db import (
    DB_ADD_COLUMN,
    DB_CURRENT_DATABASE,
    DB_DDL_AFTER_CREATE,
    DB_DDL_BEFORE_DROP_FORCE,
    DB_DDL_CREATE,
    DB_DDL_DROP,
    DB_DDL_EXISTS,
    DB_LIST_DATABASES,
    DB_REFLECT_COLUMNS,
    DB_REFLECT_PRIMARY_KEYS,
    DB_RENAME_TABLE,
)
from .starrocks import SR_CREATE_DATABASE, SR_CREATE_OLAP_TABLE, SR_DROP_TABLE

__all__ = [
    "SqlTemplate",
    "DB_ADD_COLUMN",
    "DB_DDL_AFTER_CREATE",
    "DB_DDL_BEFORE_DROP_FORCE",
    "DB_DDL_CREATE",
    "DB_DDL_DROP",
    "DB_DDL_EXISTS",
    "DB_CURRENT_DATABASE",
    "DB_LIST_DATABASES",
    "DB_REFLECT_COLUMNS",
    "DB_REFLECT_PRIMARY_KEYS",
    "DB_RENAME_TABLE",
    "SR_CREATE_DATABASE",
    "SR_CREATE_OLAP_TABLE",
    "SR_DROP_TABLE",
]
