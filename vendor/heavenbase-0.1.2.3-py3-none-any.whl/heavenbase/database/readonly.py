"""Conservative SQL read-only checks."""

from __future__ import annotations

__all__ = ["is_sql_readonly"]

import re

from .dialect.registry import database_dialects
from .dialect.spec import DatabaseDialectSpec
from .sql_text import strip_sql_comments

_READONLY = {"select", "show", "describe", "desc", "explain", "pragma", "values"}
_MUTATING = {"insert", "update", "delete", "create", "drop", "alter", "truncate", "merge", "replace", "call", "exec", "execute"}


def _token(text: str) -> str:
    match = re.match(r"^([a-z_]+)\b", strip_sql_comments(text).strip().lower())
    return match.group(1) if match else ""


def _sqlglot_readonly(text: str, dialect: str | None, dialect_spec: DatabaseDialectSpec | None = None) -> bool | None:
    try:
        import sqlglot
    except Exception:
        return None
    try:
        read = dialect_spec.sqlglot_name() if dialect_spec is not None else database_dialects.to_sqlglot(dialect, default=None)
        stmts = sqlglot.parse(text, read=read)
    except Exception:
        return None
    if not stmts:
        return False
    mutating = {"Insert", "Update", "Delete", "Create", "Drop", "Alter", "Truncate", "Merge"}
    readonly = {"Select", "Union", "Except", "Intersect", "Values", "With"}
    for stmt in stmts:
        if type(stmt).__name__ in mutating or any(type(node).__name__ in mutating for node in stmt.walk()):
            return False
        if type(stmt).__name__ not in readonly and _token(stmt.sql()) not in _READONLY:
            return False
    return True


def _fallback_readonly(text: str) -> bool:
    sql = strip_sql_comments(text).strip().lower()
    token = _token(sql)
    if token in _READONLY:
        return True
    if token != "with":
        return False
    if re.search(r"\b(" + "|".join(sorted(_MUTATING)) + r")\b", sql):
        return False
    return bool(re.search(r"\)\s*(select|values)\b", sql, flags=re.S))


def is_sql_readonly(
    query: object,
    query_text: str | None = None,
    dialect: str | None = None,
    *,
    dialect_spec: DatabaseDialectSpec | None = None,
) -> bool:
    """Return whether a SQL string or SQLAlchemy statement appears read-only.

    Args:
        query (object): SQLAlchemy statement or object whose string form should be
            inspected.
        query_text (str | None): Optional explicit SQL text. When omitted, ``str(query)``
            is used.
        dialect (str | None): Optional SQLAlchemy dialect name for SQLGlot parsing.
        dialect_spec (DatabaseDialectSpec | None): Optional bound dialect metadata
            overriding SQLGlot dialect selection.

    Returns:
        bool: ``True`` when every parsed statement appears read-only under the chosen
        parser, or under the conservative lexical fallback.

    Warnings:
        This is a conservative helper for explicit ``readonly=True`` guards. It is not used for default execution and
        should not be treated as a security sandbox for untrusted SQL.
    """
    text = (query_text if query_text is not None else str(query) if query is not None else "").strip()
    parsed = _sqlglot_readonly(text, dialect, dialect_spec)
    return _fallback_readonly(text) if parsed is None else parsed
