"""SQLAlchemy table DDL and comment helpers for the Database facade."""

from __future__ import annotations

import sqlalchemy as sa

from ..utils.typing import Any, Callable, Dict, Iterable, List, Optional, Union


def _norm_col_names(cols: Iterable[Any]) -> tuple[str, ...]:
    return tuple(str(getattr(col, "name", col)).lower() for col in cols)


class _DatabaseTableMixin:
    """Provide table creation, mutation, index, and comment helpers for ``Database``."""

    def _normalize_table(self, table: Any) -> Any:
        if isinstance(table, sa.Table):
            return table
        tbl = getattr(table, "__table__", None)
        if isinstance(tbl, sa.Table):
            return tbl
        raise TypeError(f"Expected SQLAlchemy Table or ORM class, got {type(table).__name__}")

    def create_table(self, table: Any, checkfirst: bool = True) -> None:
        """Create one SQLAlchemy table.

        Args:
            table: SQLAlchemy ``Table`` or ORM class exposing ``__table__``.
            checkfirst: Skip creation when the table already exists.

        Returns:
            None: This method creates the table and invalidates the schema-index cache.
        """
        self._normalize_table(table).create(self.engine, checkfirst=checkfirst)
        self.invalidate_schema_index()

    def create_tables(self, tables: Iterable[Any], checkfirst: bool = True) -> None:
        """Create multiple SQLAlchemy tables, preserving metadata dependency ordering.

        Args:
            tables: SQLAlchemy ``Table`` objects or ORM classes exposing ``__table__``.
            checkfirst: Skip tables that already exist.

        Returns:
            None: This method creates all requested tables and invalidates the schema-index cache.
        """
        tabs = [self._normalize_table(table) for table in tables]
        metas = list(dict.fromkeys(tab.metadata for tab in tabs))
        for meta in metas:
            meta.create_all(self.engine, tables=[tab for tab in tabs if tab.metadata is meta], checkfirst=checkfirst)
        self.invalidate_schema_index()

    def index_column_sets(self, table: Any) -> dict[tuple[str, ...], bool]:
        """Return server-side indexed column sets and uniqueness.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class.

        Returns:
            dict[tuple[str, ...], bool]: Lower-cased column tuples mapped to whether
            any covering index enforces uniqueness.
        """
        tab = self._normalize_table(table)
        indexed: dict[tuple[str, ...], bool] = {}
        try:
            inspector = sa.inspect(self.engine)
        except Exception:
            return indexed
        try:
            pk = inspector.get_pk_constraint(tab.name, schema=tab.schema) or {}
            if pk.get("constrained_columns"):
                indexed[_norm_col_names(pk["constrained_columns"])] = True
        except Exception:
            pass
        try:
            for unique in inspector.get_unique_constraints(tab.name, schema=tab.schema) or []:
                if unique.get("column_names"):
                    indexed[_norm_col_names(unique["column_names"])] = True
        except Exception:
            pass
        try:
            for index in inspector.get_indexes(tab.name, schema=tab.schema) or []:
                if index.get("column_names"):
                    columns = _norm_col_names(index["column_names"])
                    indexed[columns] = indexed.get(columns, False) or bool(index.get("unique"))
        except Exception:
            pass
        return indexed

    def table_indexes(self, table: Any) -> list[dict[str, Any]]:
        """Return reflected ordinary index descriptors for one table.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class.

        Returns:
            list[dict[str, Any]]: Named reflected index descriptors.
        """
        tab = self._normalize_table(table)
        try:
            return [dict(item) for item in sa.inspect(self.engine).get_indexes(tab.name, schema=tab.schema) or [] if item.get("name")]
        except Exception:
            return []

    def drop_index(self, table: Any, name: str, column_names: Iterable[str]) -> None:
        """Drop one reflected ordinary index when it exists.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class owning the index.
            name: Reflected physical index name.
            column_names: Indexed columns used to bind the SQLAlchemy index.

        Returns:
            None: Missing indexes are ignored by ``checkfirst``.
        """
        tab = self._normalize_table(table)
        columns = [tab.c[column_name] for column_name in column_names if column_name in tab.c]
        if not columns:
            return
        sa.Index(str(name), *columns).drop(self.engine, checkfirst=True)

    def create_index(self, index: Any, checkfirst: bool = True) -> None:
        """Create one SQLAlchemy index through the shared Database engine.

        Args:
            index: SQLAlchemy ``Index`` object.
            checkfirst: Skip creation when the index already exists.

        Returns:
            None: This method creates the index when needed.

        Note:
            ``checkfirst`` relies on the dialect reflecting existing indexes; some engines (DuckDB)
            do not, so the ``CREATE INDEX`` can still raise "index already exists" even though the
            index is present. That is the desired end state for an idempotent ensure, so an
            already-exists error is treated as success; any other error propagates.

        Raises:
            sqlalchemy.exc.SQLAlchemyError: For any creation failure other than the index already
                existing (and for every failure when ``checkfirst`` is ``False``).
        """
        try:
            index.create(self.engine, checkfirst=checkfirst)
        except sa.exc.SQLAlchemyError as exc:
            if not checkfirst or "already exists" not in str(exc).lower():
                raise

    def create_missing_indexes(self, table: Any) -> None:
        """Create locally declared indexes that do not already exist server-side.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class whose ``table.indexes`` should be reconciled.

        Returns:
            None: This method creates any missing indexes declared on the table metadata.
        """
        tab = self._normalize_table(table)
        existing = self.index_column_sets(tab)
        for index in tab.indexes:
            columns = _norm_col_names(index.columns)
            satisfied = existing.get(columns, False) if index.unique else columns in existing
            if not satisfied:
                self.create_index(index, checkfirst=True)

    def clear_table(self, table: str, schema: Optional[str] = None) -> None:
        """Delete all rows from one table without dropping the table.

        Args:
            table: Table name.
            schema: Optional schema name.

        Returns:
            None: This method deletes rows from the selected table.

        Warnings:
            This is destructive and commits like any other mutating statement outside an explicit transaction.
        """
        self.orm_execute(sa.delete(self._table(table, schema=schema)), readonly=False)

    def add_table_col(self, table: Any, column: Any) -> None:
        """Add one column to an existing table.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class.
            column: SQLAlchemy ``Column`` to add.

        Returns:
            None: This method mutates the table when the column is missing and invalidates the schema-index cache.
        """
        tab = self._normalize_table(table)
        if column.name in self.columns(tab.name, schema=tab.schema):
            return
        preparer = self.engine.dialect.identifier_preparer
        table_name = preparer.format_table(tab)
        column_def = str(sa.schema.CreateColumn(column).compile(dialect=self.engine.dialect))
        sql = self.dialect_spec.add_column_statement(table_name, column_def)
        self.execute(sql, readonly=False)
        self.invalidate_schema_index()

    def rename_table(self, old_name: str, new_name: str) -> None:
        """Rename a table using dialect-appropriate DDL.

        Args:
            old_name: Existing table name.
            new_name: New table name.

        Returns:
            None: This method renames the table and invalidates the schema-index cache.
        """
        prep = self.engine.dialect.identifier_preparer
        sql, params = self.dialect_spec.rename_table_statement(old_name, new_name, prep.quote)
        self.execute(sql, params, readonly=False)
        self.invalidate_schema_index()

    def sort_table_cols(self, table: Any, order: Union[List[str], Callable[[str], Any]]) -> None:
        """Rebuild a table with columns in a requested order.

        Args:
            table: SQLAlchemy ``Table`` object or ORM class.
            order: Explicit column-name order, or key function used to sort current column names.

        Returns:
            None: This method rebuilds the table when its current column order differs from the requested order.

        Warnings:
            This copies the table and does not preserve external triggers, views, or complex table-level constraints.
        """
        tab = self._normalize_table(table)
        col_names = [col.name for col in tab.c]
        sorted_names = (
            sorted(col_names, key=order)
            if callable(order)
            else [name for name in order if name in col_names] + [name for name in col_names if name not in set(order)]
        )
        if sorted_names == col_names:
            return
        prep = self.engine.dialect.identifier_preparer
        tmp_name = f"_hb_reorder_{tab.name}"
        if tmp_name in self.tables(schema=tab.schema):
            self.drop_table(tmp_name, schema=tab.schema)
        tmp_meta = sa.MetaData()
        tmp_cols = [
            sa.Column(col.name, col.type, primary_key=col.primary_key, nullable=col.nullable, server_default=col.server_default)
            for col in (tab.c[name] for name in sorted_names)
        ]
        tmp_tab = sa.Table(tmp_name, tmp_meta, *tmp_cols, schema=tab.schema)
        tmp_tab.create(self.engine)
        try:
            cols = ", ".join(prep.quote(name) for name in sorted_names)
            src = prep.format_table(tab)
            dst = prep.format_table(tmp_tab)
            self.execute(f"INSERT INTO {dst} ({cols}) SELECT {cols} FROM {src}", readonly=False)
            tab.drop(self.engine)
            self.rename_table(tmp_name, tab.name)
        except Exception:
            tmp_tab.drop(self.engine, checkfirst=True)
            raise
        finally:
            self.invalidate_schema_index()

    def drop_table(self, table: str, schema: Optional[str] = None) -> None:
        """Drop one table by name.

        Args:
            table: Table name.
            schema: Optional schema name.

        Returns:
            None: This method drops the table and invalidates the schema-index cache.

        Warnings:
            This removes the table definition and data. Use ``clear_table()`` to keep the table.
        """
        self._table(table, schema=schema).drop(self.engine, checkfirst=True)
        self.invalidate_schema_index()

    def drop_view(self, view: str, schema: Optional[str] = None) -> None:
        """Drop one view by name when the dialect supports ``DROP VIEW``.

        Args:
            view: View name.
            schema: Optional schema name.

        Returns:
            None: This method drops the view and invalidates the schema-index cache.
        """
        prep = self.engine.dialect.identifier_preparer
        name = prep.quote_schema(schema) + "." + prep.quote(view) if schema else prep.quote(view)
        self.execute(f"DROP VIEW IF EXISTS {name}", readonly=False)
        self.invalidate_schema_index()

    def clear(self) -> None:
        """Delete all rows from all reflected tables.

        Args:
            None.

        Returns:
            None: This method deletes rows from every reflected table.

        Warnings:
            This is a destructive data operation across the current database. It does not drop table definitions.
        """
        for table in self.tables():
            self.clear_table(table)

    def table_comment(self, table: str, schema: Optional[str] = None) -> Optional[str]:
        """Return a table comment when supported by the dialect.

        Args:
            table: Table name.
            schema: Optional schema name.

        Returns:
            Optional[str]: Comment text, ``None`` when absent or unsupported.
        """
        try:
            info = sa.inspect(self.engine).get_table_comment(table, schema=schema)
            return info.get("text") if info else None
        except NotImplementedError:
            return None

    def col_comment(self, table: str, column: str, schema: Optional[str] = None) -> Optional[str]:
        """Return a column comment when supported by the dialect.

        Args:
            table: Table name.
            column: Column name.
            schema: Optional schema name.

        Returns:
            Optional[str]: Comment text, ``None`` when absent or unsupported.
        """
        return next((col.get("comment") for col in self.columns(table, schema=schema, full=True) if col.get("name") == column), None)

    def col_comments(self, table: str, schema: Optional[str] = None) -> Dict[str, Optional[str]]:
        """Return comments for all columns in a table.

        Args:
            table: Table name.
            schema: Optional schema name.

        Returns:
            Dict[str, Optional[str]]: Column names mapped to comment text or ``None``.
        """
        return {col["name"]: col.get("comment") for col in self.columns(table, schema=schema, full=True)}

    def set_table_comment(self, table: str, comment: str, schema: Optional[str] = None) -> None:
        """Set or replace a table comment using SQLAlchemy DDL.

        Args:
            table: Table name.
            comment: New comment text.
            schema: Optional schema name.

        Returns:
            None: This method emits SQLAlchemy table-comment DDL.

        Warnings:
            Unsupported dialects may raise from SQLAlchemy DDL compilation or execution.
        """
        tab = self._table(table, schema=schema)
        tab.comment = comment
        self.orm_execute(sa.schema.SetTableComment(tab), readonly=False)

    def set_col_comment(self, table: str, column: str, comment: str, schema: Optional[str] = None) -> None:
        """Set or replace a column comment using SQLAlchemy DDL.

        Args:
            table: Table name.
            column: Column name.
            comment: New comment text.
            schema: Optional schema name.

        Returns:
            None: This method emits SQLAlchemy column-comment DDL.
        """
        tab = self._table(table, schema=schema)
        tab.c[column].comment = comment
        self.orm_execute(sa.schema.SetColumnComment(tab.c[column]), readonly=False)

    def drop_table_comment(self, table: str, schema: Optional[str] = None) -> None:
        """Remove a table comment using SQLAlchemy DDL.

        Args:
            table: Table name.
            schema: Optional schema name.

        Returns:
            None: This method emits SQLAlchemy table-comment removal DDL.
        """
        self.orm_execute(sa.schema.DropTableComment(self._table(table, schema=schema)), readonly=False)

    def drop_col_comment(self, table: str, column: str, schema: Optional[str] = None) -> None:
        """Remove a column comment using SQLAlchemy DDL.

        Args:
            table: Table name.
            column: Column name.
            schema: Optional schema name.

        Returns:
            None: This method emits SQLAlchemy column-comment removal DDL.
        """
        tab = self._table(table, schema=schema)
        self.orm_execute(sa.schema.DropColumnComment(tab.c[column]), readonly=False)
