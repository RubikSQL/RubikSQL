"""SQLAlchemy engine construction for resolved database specs."""

from __future__ import annotations

__all__ = ["create_database_engine"]

from sqlalchemy import create_engine, event

from ..utils.log import get_logger
from ..utils.typing import Any
from .ddl import create_database
from .config import DB_ENGINE, DBSpec

logger = get_logger(__name__)


def _register_pragmas(engine: Any, pragmas: list[str]) -> None:
    if not pragmas:
        return

    @event.listens_for(engine, "connect")
    def _run_pragmas(dbapi_connection: Any, connection_record: Any) -> None:
        cursor = dbapi_connection.cursor()
        try:
            for pragma in pragmas:
                cursor.execute(pragma)
        finally:
            cursor.close()


def create_database_engine(spec: DBSpec, autocreate: bool = True) -> Any:
    """Create a SQLAlchemy engine from a resolved database spec.

    Args:
        spec (DBSpec): Resolved database configuration.
        autocreate (bool): Whether to attempt best-effort database namespace creation before opening the engine.

    Returns:
        Any: SQLAlchemy engine configured from `spec`.

    Warnings:
        Autocreate failures are logged and the engine connection still proceeds so existing databases can be opened.
    """
    if autocreate:
        try:
            create_database(spec)
        except Exception as exc:
            logger.warning("Database autocreate failed; attempting direct engine connection for existing database: %s", exc)
    kw = DB_ENGINE.apply(spec, profile="engine")
    url = kw.pop("url")
    engine = create_engine(url, **kw)
    _register_pragmas(engine, DB_ENGINE.apply(spec, profile="pragmas"))
    return engine
