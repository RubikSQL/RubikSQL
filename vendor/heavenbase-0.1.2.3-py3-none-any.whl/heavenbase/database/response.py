"""Reusable SQL execution response."""

from __future__ import annotations

__all__ = ["SQLResponse", "table_display"]

import traceback as tb

from ..utils.typing import Any, Callable, Dict, Iterable, Iterator, List, Literal, Optional, Tuple, Union, deepcopy
from ..utils.values import raise_mismatch
from .display import table_display
from .response_exports import _to_numpy, _to_numpy_dict, _to_pandas, _to_pyarrow

ColumnRef = Union[str, int]
RowFormat = Literal["dict", "list", "tuple"]

_DONE = object()


def _as_row_dict(row: Any) -> Dict[str, Any]:
    return dict(row._mapping) if hasattr(row, "_mapping") else dict(row)


class _ResponseIter:
    def __init__(self, response: "SQLResponse") -> None:
        self.response = response
        self.idx = 0
        self.closed = False

    def __iter__(self) -> "_ResponseIter":
        return self

    def __next__(self) -> Dict[str, Any]:
        if self.closed:
            raise StopIteration
        if self.idx < len(self.response._rows):
            row = self.response._rows[self.idx]
            self.idx += 1
            return dict(row)
        row = self.response._pull()
        if row is _DONE:
            self.closed = True
            raise StopIteration
        self.idx += 1
        return dict(row)

    def close(self) -> None:
        if not self.closed:
            self.response.cache()
            self.closed = True

    def __del__(self) -> None:
        self.close()


class SQLResponse:
    """Unified, reusable result of a SQL execution.

    Rows are cached lazily as callers iterate or export them. Column projection helpers validate requested columns by default;
    pass ``check=False`` when missing column names should be rendered as ``None``.

    A response may represent either success or failure. Failed responses are produced only by ``safe=True`` execution paths;
    call ``raise_on_error()`` to re-raise the original exception, or inspect ``error_type`` and ``error_message`` for display.
    Export helpers drain the underlying cursor once and then reuse the cached rows, so repeated conversions are deterministic.
    """

    def __init__(self) -> None:
        """Create an empty SQL execution response envelope.

        Args:
            None.

        Returns:
            None: This function does not return a value.
        """
        self.ok = True
        self._columns: List[str] = []
        self._rows: List[Dict[str, Any]] = []
        self._row_count = -1
        self._lastrowid: Any = None
        self._error_type = ""
        self._error_message = ""
        self._exception: BaseException | None = None
        self._query: str | None = None
        self._params: Any = None
        self._elapsed: float | None = None
        self._row_iter: Iterator[Any] | None = None
        self._close: Callable[[], None] | None = None

    @classmethod
    def from_cursor(
        cls,
        result: Any,
        *,
        query: Optional[str] = None,
        params: Any = None,
        elapsed: Optional[float] = None,
        close: Callable[[], None] | None = None,
    ) -> "SQLResponse":
        """Build a success response from a SQLAlchemy result.

        Args:
            result: SQLAlchemy ``CursorResult`` or compatible object.
            query: Optional SQL text recorded for diagnostics.
            params: Optional execution parameters recorded for diagnostics.
            elapsed: Optional execution duration in seconds.
            close: Optional callback invoked when lazy row consumption finishes.

        Returns:
            SQLResponse: Success response with lazy row iteration when the result returns rows.
        """
        resp = cls()
        resp._query = query
        resp._params = params
        resp._elapsed = elapsed
        resp._close = close
        try:
            returns_rows = bool(result.returns_rows)
        except Exception:
            returns_rows = False
        try:
            resp._columns = list(result.keys()) if returns_rows else []
        except Exception:
            resp._columns = []
        try:
            resp._row_count = int(getattr(result, "rowcount", -1))
        except Exception:
            resp._row_count = -1
        if not returns_rows:
            try:
                resp._lastrowid = getattr(result, "lastrowid", None)
            except Exception:
                pass
        if returns_rows:
            resp._row_iter = iter(result.mappings())
        else:
            resp.close()
        return resp

    @classmethod
    def empty(cls, *, query: Optional[str] = None, params: Any = None, elapsed: Optional[float] = None) -> "SQLResponse":
        """Build an empty successful response.

        Args:
            query: Optional SQL text recorded for diagnostics.
            params: Optional execution parameters recorded for diagnostics.
            elapsed: Optional execution duration in seconds.

        Returns:
            A cached response with zero rows.
        """
        resp = cls()
        resp._query = query
        resp._params = params
        resp._elapsed = elapsed
        resp._row_count = 0
        return resp

    @classmethod
    def from_rows(
        cls, rows: Iterable[Dict[str, Any]], *, columns: Optional[List[str]] = None, query: Optional[str] = None, params: Any = None
    ) -> "SQLResponse":
        """Build a cached response from Python row dictionaries.

        Args:
            rows: Iterable of row mappings.
            columns: Optional explicit column order. Defaults to the first row's keys.
            query: Optional query label recorded for diagnostics.
            params: Optional parameter payload recorded for diagnostics.

        Returns:
            SQLResponse: Success response with rows already cached.
        """
        resp = cls()
        resp._rows = [dict(row) for row in rows]
        resp._columns = list(columns or (resp._rows[0].keys() if resp._rows else []))
        resp._row_count = len(resp._rows)
        resp._query = query
        resp._params = params
        return resp

    @classmethod
    def from_error(cls, exc: BaseException, *, query: Optional[str] = None, params: Any = None, elapsed: Optional[float] = None) -> "SQLResponse":
        """Build an error response without raising immediately.

        Args:
            exc: Captured exception.
            query: Optional SQL text or statement string.
            params: Optional execution parameters.
            elapsed: Optional elapsed seconds before failure.

        Returns:
            SQLResponse: ``ok=False`` response preserving exception details.
        """
        resp = cls()
        resp.ok = False
        resp._exception = exc
        resp._error_type = type(exc).__name__
        resp._error_message = str(exc)
        resp._query = query
        resp._params = params
        resp._elapsed = elapsed
        return resp

    @property
    def columns(self) -> List[str]:
        """Return result column names.

        Returns:
            A detached list in result order.
        """
        return list(self._columns)

    @property
    def shape(self) -> Tuple[int, int]:
        """Return the cached table dimensions.

        Returns:
            The ``(row_count, column_count)`` pair.
        """
        self.cache()
        return len(self._rows), len(self._columns)

    @property
    def row_count(self) -> int:
        """Return the driver row count or current cached-row count.

        Returns:
            The affected or cached row count.
        """
        return self._row_count if self._row_count >= 0 else len(self._rows)

    @property
    def lastrowid(self) -> Any:
        """Return the last inserted row identifier.

        Returns:
            The driver-provided identifier, or ``None``.
        """
        return self._lastrowid

    @property
    def error_type(self) -> str:
        """Return the captured error class name.

        Returns:
            The class name, or an empty string for successful responses.
        """
        return self._error_type

    @property
    def error_message(self) -> str:
        """Return the captured error message.

        Returns:
            The message, or an empty string for successful responses.
        """
        return self._error_message

    @property
    def exception(self) -> BaseException | None:
        """Return the captured exception.

        Returns:
            The original exception, or ``None``.
        """
        return self._exception

    @property
    def query(self) -> str | None:
        """Return the recorded SQL text.

        Returns:
            The SQL text or statement string, or ``None``.
        """
        return self._query

    @property
    def params(self) -> Any:
        """Return the recorded execution parameters.

        Returns:
            The original parameter payload, or ``None``.
        """
        return self._params

    @property
    def elapsed(self) -> Optional[float]:
        """Return SQL execution duration.

        Returns:
            Elapsed seconds, or ``None``.
        """
        return self._elapsed

    def _ensure_ok(self) -> None:
        if not self.ok and self._exception is not None:
            raise self._exception

    def _pull(self) -> Any:
        if self._row_iter is None:
            return _DONE
        try:
            row = _as_row_dict(next(self._row_iter))
            self._rows.append(row)
            return row
        except StopIteration:
            self.close()
            if self._row_count < 0:
                self._row_count = len(self._rows)
            return _DONE

    def cache(self) -> "SQLResponse":
        """Drain remaining cursor rows into this response.

        Args:
            None.

        Returns:
            This reusable response.

        Raises:
            BaseException: The original exception for a failed response.
        """
        self._ensure_ok()
        while self._pull() is not _DONE:
            pass
        return self

    def close(self) -> None:
        """Close the underlying cursor or connection callback.

        Args:
            None.

        Returns:
            None.
        """
        close = self._close
        self._row_iter = None
        self._close = None
        if close is not None:
            close()

    def raise_on_error(self) -> None:
        """Raise the original exception when this response failed.

        Args:
            None.

        Returns:
            None.

        Raises:
            BaseException: The original execution exception.
        """
        self._ensure_ok()

    def traceback(self) -> Optional[str]:
        """Render the captured traceback.

        Args:
            None.

        Returns:
            The formatted traceback, or ``None``.
        """
        return "".join(tb.format_exception(type(self._exception), self._exception, self._exception.__traceback__)) if self._exception else None

    def _column_name(self, col: ColumnRef, *, check: bool = True) -> str:
        if isinstance(col, int):
            try:
                return self._columns[col]
            except IndexError as exc:
                raise ValueError(f"Column index {col} out of range for {len(self._columns)} columns") from exc
        name = str(col)
        if check and name not in self._columns:
            raise ValueError(f"Unknown column {name!r}. Available columns: {self._columns}")
        return name

    def _column_names(self, columns: Optional[List[ColumnRef]] = None, *, check: bool = True) -> List[str]:
        return list(self._columns) if columns is None else [self._column_name(col, check=check) for col in columns]

    def to_list(self, row_fmt: RowFormat = "dict", columns: Optional[List[Union[str, int]]] = None, check: bool = True) -> Any:
        """Export rows as dictionaries, lists, or tuples.

        Args:
            row_fmt: Row shape: ``"dict"``, ``"list"``, or ``"tuple"``.
            columns: Optional column names or indexes to include.
            check: Validate requested column names. Set ``False`` to emit ``None`` for missing column names.

        Returns:
            Any: Rows in the requested shape.

        Raises:
            ValueError: If a requested column is invalid or ``row_fmt`` is unsupported.
        """
        self.cache()
        names = self._column_names(columns, check=check)
        rows = [{name: row.get(name) for name in names} for row in self._rows]
        if row_fmt == "dict":
            return deepcopy(rows)
        if row_fmt == "list":
            return [[row.get(name) for name in names] for row in rows]
        if row_fmt == "tuple":
            return [tuple(row.get(name) for name in names) for row in rows]
        return raise_mismatch(("dict", "list", "tuple"), got=row_fmt, name="SQL response row format")

    def to_dicts(self, columns: Optional[List[Union[str, int]]] = None, check: bool = True) -> List[Dict[str, Any]]:
        """Return rows as list-of-dicts.

        Args:
            columns: Optional names or indexes to project.
            check: Validate requested column names.

        Returns:
            List[Dict[str, Any]]: Deep-copied row dictionaries in result order.
        """
        return self.to_list("dict", columns=columns, check=check)

    def to_lists(self, columns: Optional[List[Union[str, int]]] = None, check: bool = True) -> List[List[Any]]:
        """Return projected rows as lists.

        Args:
            columns: Optional names or indexes to project.
            check: Validate requested columns.

        Returns:
            Projected values in row order.
        """
        return self.to_list("list", columns=columns, check=check)

    def to_pandas(self, *, columns: Optional[List[Union[str, int]]] = None, check: bool = True) -> Any:
        """Return rows as a pandas DataFrame.

        Args:
            columns: Optional names or indexes to project.
            check: Validate requested column names.

        Returns:
            pandas.DataFrame: DataFrame with the requested column order.
        """
        return _to_pandas(self, columns=columns, check=check)

    def to_pyarrow(self, *, columns: Optional[List[Union[str, int]]] = None, schema: Any = None, check: bool = True) -> Any:
        """Return rows as a pyarrow Table.

        Args:
            columns: Optional names or indexes to project.
            schema: Optional pyarrow schema passed to the export adapter.
            check: Validate requested column names.

        Returns:
            pyarrow.Table: Arrow table containing cached rows.
        """
        return _to_pyarrow(self, columns=columns, schema=schema, check=check)

    def to_numpy(self, *columns: str, dtype: Any = None, check: bool = True) -> Any:
        """Return rows as a NumPy array.

        Args:
            *columns: Optional column names to project. Defaults to all columns.
            dtype: Optional NumPy dtype.
            check: Validate requested column names.

        Returns:
            numpy.ndarray: Two-dimensional array shaped ``(rows, columns)``.
        """
        return _to_numpy(self, *columns, dtype=dtype, check=check)

    def to_numpy_dict(self, *, columns: Optional[List[str]] = None, check: bool = True) -> dict[str, Any]:
        """Return projected columns as NumPy arrays.

        Args:
            columns: Optional column names to project.
            check: Validate requested columns.

        Returns:
            A mapping of requested column names to NumPy arrays.
        """
        return _to_numpy_dict(self, columns=columns, check=check)

    def scalar(self) -> Any:
        """Return the first value in the first row.

        Args:
            None.

        Returns:
            The first value, or ``None`` for an empty result.
        """
        first = self.first()
        return next(iter(first.values()), None) if first else None

    def first(self) -> Optional[Dict[str, Any]]:
        """Return the first row as a dictionary.

        Args:
            None.

        Returns:
            A detached row dictionary, or ``None`` for an empty result.
        """
        self.cache()
        return dict(self._rows[0]) if self._rows else None

    def column(self, col: str | int, check: bool = True) -> List[Any]:
        """Return one column as a list.

        Args:
            col: Column name or zero-based index.
            check: Validate the column name or index.

        Returns:
            List[Any]: Values in row order.
        """
        self.cache()
        name = self._column_name(col, check=check)
        return [row.get(name) for row in self._rows]

    def table_display(
        self,
        columns: Optional[List[Union[str, int]]] = None,
        *,
        max_rows: int = 64,
        max_width: int = 64,
        check: bool = True,
        err: bool = False,
        footer: Union[bool, str] = True,
    ) -> str:
        """Render this response as a compact ASCII table.

        Args:
            columns: Optional column names or indexes to display.
            max_rows: Maximum displayed row count.
            max_width: Maximum rendered cell width.
            check: Validate requested columns. Set ``False`` to render missing columns as empty cells.
            err: Include the full traceback for failed responses.
            footer: ``True`` to show the row-count line; ``False`` to suppress all footer text; a ``str`` to append custom text after the row count.

        Returns:
            str: Human-readable table display.
        """
        if not self.ok:
            if footer is False:
                return ""
            trace = self.traceback() if err else None
            parts = [f"{self._error_type}: {self._error_message}"]
            if trace:
                parts.append(trace)
            hint = footer if isinstance(footer, str) else ""
            if hint:
                parts.append(hint)
            return "\n".join(parts)
        self.cache()
        if not self._columns:
            if footer is False:
                return ""
            msg = "The SQL executes successfully but the result table is empty"
            if self._row_count >= 0:
                msg += f" ({self._row_count} rows affected)"
            hint = footer if isinstance(footer, str) else ""
            if hint:
                msg += f"\n{hint}"
            return msg
        if not self._rows:
            if footer is False:
                return table_display(self, columns=columns, max_rows=max_rows, max_width=max_width, check=check, footer=False)
            hint = footer if isinstance(footer, str) else ""
            combined = "The SQL executes successfully but the result table is empty." + (f"\n{hint}" if hint else "")
            return table_display(self, columns=columns, max_rows=max_rows, max_width=max_width, check=check, footer=combined)
        return table_display(self, columns=columns, max_rows=max_rows, max_width=max_width, check=check, footer=footer)

    def clone(self) -> "SQLResponse":
        """Build an independent cached response.

        Args:
            None.

        Returns:
            A deep copy with no live cursor.
        """
        self.cache()
        return deepcopy(self)

    def __iter__(self) -> Iterable[Dict[str, Any]]:
        return _ResponseIter(self)

    def __len__(self) -> int:
        self.cache()
        return len(self._rows)

    def __getitem__(self, idx: Any) -> Any:
        self.cache()
        if isinstance(idx, str):
            return self.column(idx)
        if isinstance(idx, tuple) and len(idx) == 2:
            row, col = idx
            name = self._column_name(col)
            return self._rows[row].get(name)
        return self._rows[idx]

    def __bool__(self) -> bool:
        return self.ok

    def to_str(self, err: bool = False) -> str:
        """Return a compact human-readable summary.

        Args:
            err: Include the traceback for failed responses.

        Returns:
            The rendered response text.
        """
        return self.table_display(err=err)

    def __repr__(self) -> str:
        return f"SQLResponse(ok={self.ok!r}, rows={len(self._rows)}, columns={self._columns!r})"

    def __str__(self) -> str:
        return self.table_display()
