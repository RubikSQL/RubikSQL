"""Shared provider-protocol mechanics for LLM gateway module folders."""

from __future__ import annotations

__all__: list[str] = []

import asyncio
from collections import OrderedDict
from contextlib import nullcontext
import inspect
import os
import threading
from functools import partial

from ..image import LLMImage
from ..config import LLMSpec
from heavenbase.utils import dumps_json, loads_json, sha256hash
from heavenbase.utils.typing import Any, Dict, Iterable, List

CLIENT_ARG_KEYS = {
    "batch_max_workers",
    "batch_size",
    "batch_workers",
    "cache",
    "cache_config",
    "cache_policy",
    "dim",
    "embed_max_workers",
    "embedding_batch_size",
    "embedding_max_workers",
    "api_key",
    "auth_token",
    "base_url",
    "enforce_non_stream_structured",
    "http_proxy",
    "https_proxy",
    "max_retries",
    # Loop-level keys consumed in ``_chat_context``, never provider parameters.
    # The gateway runtime re-merges spec args, so without these entries a
    # constructor-channel value reaches ``Completions.create`` and raises on
    # every openai-protocol route.
    "compact_ratio",
    "max_tool_turns",
    "tool_result_capture_chars",
    "max_workers",
    "mock",
    "mock_chat",
    "mock_embed",
    "mock_imagen",
    "mock_pause",
    "mock_seed",
    "mock_text",
    "name",
    "no_proxy",
    "reasoning_exclude",
    "reasoning_max_tokens",
    "repair_tool_calls",
    "stream_chat",
    "structured_stream",
    "think",
    "timeout",
    "tool_call_repair",
}

EMBEDDING_PAYLOAD_KEYS = {
    "dimensions",
    "encoding_format",
    "extra_body",
    "extra_headers",
    "extra_query",
    "input",
    "user",
}

_CLIENT_CACHE_MAX = 64
_ClientKey = tuple[str | int, str]
_OPENAI_CLIENTS: "OrderedDict[_ClientKey, Any]" = OrderedDict()
_OPENAI_ASYNC_CLIENTS: "OrderedDict[_ClientKey, Any]" = OrderedDict()
_ANTHROPIC_CLIENTS: "OrderedDict[_ClientKey, Any]" = OrderedDict()
_ANTHROPIC_ASYNC_CLIENTS: "OrderedDict[_ClientKey, Any]" = OrderedDict()
_LITELLM_MODULE: Any = None
_CLIENT_CACHE_LOCK = threading.RLock()
_END = object()


def _client_key(spec: LLMSpec, digest: str) -> _ClientKey:
    """Return one Context-resolver-owned SDK client key."""
    return spec.authority_key[0], digest


def _close_client(client: Any) -> None:
    """Best-effort close one synchronous or asynchronous SDK client."""
    close = getattr(client, "close", None) or getattr(client, "aclose", None)
    if not callable(close):
        return
    try:
        result = close()
        if not inspect.isawaitable(result):
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(result)
        else:
            loop.create_task(result)
    except Exception:
        return


def _cached_client(cache: Dict[_ClientKey, Any], key: _ClientKey) -> Any:
    """Return and refresh one cached client while holding no caller lock."""
    with _CLIENT_CACHE_LOCK:
        client = cache.get(key)
        if client is not None and isinstance(cache, OrderedDict):
            cache.move_to_end(key)
        return client


def _publish_client(cache: Dict[_ClientKey, Any], key: _ClientKey, created: Any, *, resolver: Any) -> Any:
    """Publish one client while its resolver authority remains active."""
    guard = getattr(resolver, "_authority_guard", None)
    if not callable(guard):
        guard = getattr(getattr(resolver, "catalog", None), "_authority_guard", None)
    authority = guard() if callable(guard) else nullcontext()
    evicted = None
    try:
        with authority:
            with _CLIENT_CACHE_LOCK:
                client = cache.get(key)
                if client is None:
                    cache[key] = created
                    client = created
                    if isinstance(cache, OrderedDict):
                        cache.move_to_end(key)
                    if len(cache) > _CLIENT_CACHE_MAX:
                        oldest = next(iter(cache))
                        if oldest != key:
                            evicted = cache.pop(oldest)
                elif isinstance(cache, OrderedDict):
                    cache.move_to_end(key)
    except BaseException:
        _close_client(created)
        raise
    if client is not created:
        _close_client(created)
    if evicted is not None:
        _close_client(evicted)
    return client


def dispose_llm_clients(authority: Any | None = None) -> None:
    """Close clients owned by one resolver authority, or every client."""
    authority_id = None if authority is None else getattr(authority, "authority_token", id(authority))
    removed = []
    with _CLIENT_CACHE_LOCK:
        for cache in (_OPENAI_CLIENTS, _OPENAI_ASYNC_CLIENTS, _ANTHROPIC_CLIENTS, _ANTHROPIC_ASYNC_CLIENTS):
            keys = [key for key in cache if authority_id is None or key[0] == authority_id]
            removed.extend(cache.pop(key) for key in keys)
    for client in removed:
        _close_client(client)


PORTKEY_OPENROUTER_EMBEDDING_ERROR = (
    "Portkey Gateway + OpenRouter embeddings are temporarily unsupported in Portkey Gateway; "
    "see https://github.com/Portkey-AI/gateway/pull/1622. Use gateway='openai' or gateway='litellm' for OpenRouter embeddings for now."
)
BIFROST_IMAGE_ERROR = (
    "Bifrost image generation is temporarily unsupported; see https://github.com/maximhq/bifrost/issues/2367. "
    "Use gateway='openai' or gateway='litellm' for image generation for now."
)


def _as_dict(obj: Any) -> Dict[str, Any]:
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "dict"):
        return obj.dict()
    if hasattr(obj, "to_dict"):
        return obj.to_dict()
    return dict(obj)


def _openai_client(spec: LLMSpec, mode: str):
    runtime = spec.engine.apply(spec, profile=mode)
    key = _client_key(spec, spec.client_key())
    client = _cached_client(_OPENAI_CLIENTS, key)
    if client is not None:
        return client, runtime
    try:
        from openai import OpenAI
    except Exception as exc:
        raise ImportError("Install the openai package to use HeavenBase LLM OpenAI-compatible gateways.") from exc
    kwargs = {"api_key": runtime.get("api_key")}
    if runtime.get("base_url"):
        kwargs["base_url"] = runtime["base_url"]
    if runtime.get("headers"):
        kwargs["default_headers"] = runtime["headers"]
    if runtime.get("args", {}).get("timeout") is not None:
        kwargs["timeout"] = runtime["args"].get("timeout")
    if runtime.get("args", {}).get("max_retries") is not None:
        kwargs["max_retries"] = runtime["args"].get("max_retries")
    client = _publish_client(_OPENAI_CLIENTS, key, OpenAI(**kwargs), resolver=spec.resolver)
    return client, runtime


def _openai_async_client(spec: LLMSpec, mode: str):
    runtime = spec.engine.apply(spec, profile=mode)
    key = _client_key(spec, spec.client_key())
    client = _cached_client(_OPENAI_ASYNC_CLIENTS, key)
    if client is not None:
        return client, runtime
    try:
        from openai import AsyncOpenAI
    except Exception as exc:
        raise ImportError("Install the openai package to use HeavenBase LLM async OpenAI-compatible gateways.") from exc
    kwargs = {"api_key": runtime.get("api_key")}
    if runtime.get("base_url"):
        kwargs["base_url"] = runtime["base_url"]
    if runtime.get("headers"):
        kwargs["default_headers"] = runtime["headers"]
    if runtime.get("args", {}).get("timeout") is not None:
        kwargs["timeout"] = runtime["args"].get("timeout")
    if runtime.get("args", {}).get("max_retries") is not None:
        kwargs["max_retries"] = runtime["args"].get("max_retries")
    client = _publish_client(_OPENAI_ASYNC_CLIENTS, key, AsyncOpenAI(**kwargs), resolver=spec.resolver)
    return client, runtime


def _strip_path_suffix(value: Any, suffix: str) -> Any:
    if not isinstance(value, str):
        return value
    clean = value.rstrip("/")
    return clean[: -len(suffix)] if clean.endswith(suffix) else clean


def _bifrost_anthropic_base_url(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    clean = value.rstrip("/")
    if clean.endswith("/anthropic"):
        return clean
    return f"{_strip_path_suffix(clean, '/v1')}/anthropic"


def _anthropic_gateway_runtime(spec: LLMSpec, mode: str) -> Dict[str, Any]:
    runtime = dict(spec.engine.apply(spec, profile=mode))
    runtime["headers"] = dict(runtime.get("headers", {}) or {})
    if mode == "portkey":
        api_key = runtime.get("api_key")
        if (
            api_key
            and api_key != "portkey"
            and "x-portkey-api-key" not in runtime["headers"]
            and runtime["headers"].get("Authorization") != f"Bearer {api_key}"
        ):
            runtime["headers"]["x-portkey-api-key"] = api_key
        runtime["base_url"] = _strip_path_suffix(runtime.get("base_url"), "/v1")
        runtime["api_key"] = "portkey"
    elif mode == "bifrost":
        runtime["base_url"] = _bifrost_anthropic_base_url(runtime.get("base_url"))
    return runtime


def _anthropic_client_key(runtime: Dict[str, Any], authority: Any = None) -> str:
    args = runtime.get("args", {}) or {}
    return sha256hash(
        {
            "gateway": runtime.get("gateway"),
            "endpoint": "anthropic",
            "authority": authority,
            "api_key": runtime.get("api_key"),
            "auth_token": runtime.get("auth_token"),
            "base_url": runtime.get("base_url"),
            "headers": runtime.get("headers", {}) or {},
            "timeout": args.get("timeout"),
            "max_retries": args.get("max_retries"),
        }
    )


def _anthropic_client(spec: LLMSpec, mode: str = "anthropic"):
    runtime = _anthropic_gateway_runtime(spec, mode)
    key = _client_key(spec, _anthropic_client_key(runtime, spec.authority_key))
    client = _cached_client(_ANTHROPIC_CLIENTS, key)
    if client is not None:
        return client, runtime
    try:
        from anthropic import Anthropic
    except Exception as exc:
        raise ImportError("Install the anthropic package to use HeavenBase LLM Anthropic gateways.") from exc
    kwargs = _anthropic_client_kwargs(runtime)
    client = _publish_client(_ANTHROPIC_CLIENTS, key, Anthropic(**kwargs), resolver=spec.resolver)
    return client, runtime


def _anthropic_async_client(spec: LLMSpec, mode: str = "anthropic"):
    runtime = _anthropic_gateway_runtime(spec, mode)
    key = _client_key(spec, _anthropic_client_key(runtime, spec.authority_key))
    client = _cached_client(_ANTHROPIC_ASYNC_CLIENTS, key)
    if client is not None:
        return client, runtime
    try:
        from anthropic import AsyncAnthropic
    except Exception as exc:
        raise ImportError("Install the anthropic package to use HeavenBase LLM async Anthropic gateways.") from exc
    kwargs = _anthropic_client_kwargs(runtime)
    client = _publish_client(_ANTHROPIC_ASYNC_CLIENTS, key, AsyncAnthropic(**kwargs), resolver=spec.resolver)
    return client, runtime


def _anthropic_client_kwargs(runtime: Dict[str, Any]) -> Dict[str, Any]:
    args = runtime.get("args", {}) or {}
    kwargs: Dict[str, Any] = {}
    auth_token = runtime.get("auth_token")
    api_key = runtime.get("api_key")
    if auth_token:
        kwargs["auth_token"] = auth_token
    elif api_key and api_key != "anthropic":
        kwargs["api_key"] = api_key
    if runtime.get("base_url"):
        kwargs["base_url"] = runtime["base_url"]
    if runtime.get("headers"):
        kwargs["default_headers"] = runtime["headers"]
    if args.get("timeout") is not None:
        kwargs["timeout"] = args.get("timeout")
    if args.get("max_retries") is not None:
        kwargs["max_retries"] = args.get("max_retries")
    return kwargs


async def _run_sync(fn: Any, *args: Any, **kwargs: Any) -> Any:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, partial(fn, *args, **kwargs))


def _next_item(iterator: Any) -> Any:
    try:
        return next(iterator)
    except StopIteration:
        return _END


async def _async_stream(items: Any):
    iterator = iter(items)
    while True:
        chunk = await _run_sync(_next_item, iterator)
        if chunk is _END:
            return
        yield chunk


def _deep_merge(left: Dict[str, Any], right: Dict[str, Any], path: tuple[str, ...] = ()) -> Dict[str, Any]:
    out = dict(left or {})
    for key, value in (right or {}).items():
        if isinstance(out.get(key), dict) and isinstance(value, dict):
            out[key] = _deep_merge(out[key], value, (*path, key))
        elif key in out and out[key] != value:
            location = ".".join((*path, key))
            raise ValueError(f"LLM semantic argument conflicts with explicit native argument at extra_body.{location}")
        else:
            out[key] = value
    return out


def _set_extra_body(args: Dict[str, Any], data: Dict[str, Any]) -> None:
    args["extra_body"] = _deep_merge(args.get("extra_body", {}) or {}, data)


def _thinking_control(args: Dict[str, Any]) -> Dict[str, Any]:
    control = {
        "think": args.pop("think", None),
        "effort": args.pop("reasoning_effort", None),
        "max_tokens": args.pop("reasoning_max_tokens", None),
        "exclude": args.pop("reasoning_exclude", None),
    }
    if control["think"] is None and any(control[key] is not None for key in ("effort", "max_tokens", "exclude")):
        control["think"] = True
    return control


def _reasoning_body(control: Dict[str, Any]) -> Dict[str, Any]:
    think = control["think"]
    reasoning = {"enabled": bool(think)}
    if think:
        if control["max_tokens"]:
            reasoning["max_tokens"] = control["max_tokens"]
        elif control["effort"]:
            reasoning["effort"] = control["effort"]
        if control["exclude"] is not None:
            reasoning["exclude"] = control["exclude"]
    return {"reasoning": reasoning}


def _thinking_type_body(control: Dict[str, Any]) -> Dict[str, Any]:
    thinking = {"type": "enabled" if control["think"] else "disabled"}
    if control["think"] and control["max_tokens"]:
        thinking["budget_tokens"] = control["max_tokens"]
    elif control["think"] and control["effort"]:
        thinking["effort"] = control["effort"]
    return {"thinking": thinking}


def _native_thinking_body(control: Dict[str, Any], model: str, args: Dict[str, Any]) -> Dict[str, Any]:
    if control["think"] is False:
        if args.get("thinking") not in (None, {"type": "disabled"}):
            raise ValueError("LLM semantic argument conflicts with explicit native argument at thinking")
        generated: Dict[str, Any] = {}
    elif control["max_tokens"] is not None:
        if _anthropic_adaptive_only_model(model):
            raise ValueError(f"Anthropic model {model!r} does not support manual thinking budgets; " "use think=True with reasoning_effort instead.")
        budget = int(control["max_tokens"])
        if budget < 1024:
            raise ValueError("Anthropic manual thinking budgets must be at least 1024 tokens.")
        max_tokens = args.get("max_tokens")
        if max_tokens is not None and int(max_tokens) <= budget:
            raise ValueError("Anthropic manual thinking budget must be lower than max_tokens.")
        generated = {"thinking": {"type": "enabled", "budget_tokens": budget, "display": "summarized"}}
    else:
        generated = {"thinking": {"type": "adaptive", "display": "summarized"}}
    if control["effort"] is not None:
        generated["effort"] = control["effort"]

    for key, value in generated.items():
        if key in args and args[key] != value:
            raise ValueError(f"LLM semantic argument conflicts with explicit native argument at {key}")
    return {key: value for key, value in generated.items() if key not in args}


def _anthropic_adaptive_only_model(model: str) -> bool:
    text = str(model or "").lower()
    return any(
        token in text
        for token in (
            "fable-5",
            "sonnet-5",
            "opus-5",
            "opus-4-7",
            "opus-4.7",
            "opus-4-8",
            "opus-4.8",
        )
    )


def _apply_thinking(runtime: Dict[str, Any], spec: LLMSpec, args: Dict[str, Any]) -> Dict[str, Any]:
    control = _thinking_control(args)
    if control["think"] is None:
        return args
    if runtime.get("thinking_control") == "extra_body_reasoning":
        _set_extra_body(args, _reasoning_body(control))
    elif runtime.get("thinking_control") == "extra_body_thinking_type":
        _set_extra_body(args, _thinking_type_body(control))
    elif runtime.get("thinking_control") == "native_thinking":
        args.update(_native_thinking_body(control, runtime.get("model", spec.model_id), args))
    elif control["think"] is True:
        raise ValueError(f"LLM route {spec.endpoint}/{spec.gateway} does not support semantic thinking controls")
    return args


def _openai_payload(runtime: Dict[str, Any], spec: LLMSpec = None, **kwargs: Any) -> Dict[str, Any]:
    args = dict(runtime.get("args", {}))
    args.update(kwargs)
    if spec is not None:
        args = _apply_thinking(runtime, spec, args)
    return {"model": runtime["model"], **{k: v for k, v in args.items() if v is not None and k not in CLIENT_ARG_KEYS}}


def _anthropic_usage(value: Dict[str, Any]) -> Dict[str, Any]:
    usage = dict(value or {})
    if "input_tokens" in usage:
        usage.setdefault("prompt_tokens", usage["input_tokens"])
    if "output_tokens" in usage:
        usage.setdefault("completion_tokens", usage["output_tokens"])
    if "total_tokens" not in usage and "prompt_tokens" in usage and "completion_tokens" in usage:
        usage["total_tokens"] = usage["prompt_tokens"] + usage["completion_tokens"]
    return usage


def _anthropic_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(_anthropic_text(item) for item in content)
    if isinstance(content, dict):
        if content.get("type") == "text":
            return str(content.get("text") or "")
        return str(content.get("content") or content.get("text") or "")
    return str(content)


def _anthropic_tool_input(arguments: Any) -> Dict[str, Any]:
    if isinstance(arguments, str):
        return loads_json(arguments) if arguments.strip() else {}
    if arguments is None:
        return {}
    return dict(arguments) if isinstance(arguments, dict) else {"value": arguments}


def _anthropic_image_source(url: str) -> Dict[str, Any]:
    if url.startswith("data:image/") and ";base64," in url:
        header, data = url.split(",", 1)
        media_type = header[len("data:") : header.index(";base64")]
        return {"type": "base64", "media_type": media_type, "data": data}
    return {"type": "url", "url": url}


def _anthropic_content_part(item: Any) -> Dict[str, Any]:
    if isinstance(item, dict):
        kind = item.get("type")
        if kind in {"text", "tool_use", "tool_result", "image"}:
            return dict(item)
        if kind == "image_url" or "image_url" in item:
            image_url = item.get("image_url")
            url = image_url.get("url") if isinstance(image_url, dict) else image_url
            return {"type": "image", "source": _anthropic_image_source(str(url or ""))}
        if "text" in item:
            return {"type": "text", "text": str(item.get("text") or "")}
    return {"type": "text", "text": _anthropic_text(item)}


def _anthropic_content(content: Any) -> Any:
    if isinstance(content, list):
        return [_anthropic_content_part(item) for item in content]
    return content if isinstance(content, str) else _anthropic_text(content)


def _anthropic_tool_result(message: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "type": "tool_result",
        "tool_use_id": message.get("tool_call_id") or message.get("id") or message.get("name") or "",
        "content": _anthropic_text(message.get("content")),
    }


def _anthropic_tool_use(tool_call: Dict[str, Any]) -> Dict[str, Any]:
    function = tool_call.get("function") if isinstance(tool_call.get("function"), dict) else {}
    return {
        "type": "tool_use",
        "id": tool_call.get("id") or function.get("name") or tool_call.get("name") or "",
        "name": function.get("name") or tool_call.get("name") or "",
        "input": _anthropic_tool_input(function.get("arguments", tool_call.get("arguments", {}))),
    }


def _anthropic_message(message: Dict[str, Any]) -> Dict[str, Any] | None:
    role = message.get("role")
    if role in {"system", "developer"}:
        return None
    if role == "tool":
        return {"role": "user", "content": [_anthropic_tool_result(message)]}
    if role not in {"user", "assistant"}:
        role = "user"
    content = _anthropic_content(message.get("content", ""))
    if role == "assistant" and message.get("tool_calls"):
        blocks = content if isinstance(content, list) else ([{"type": "text", "text": content}] if content else [])
        blocks.extend(_anthropic_tool_use(tool_call) for tool_call in message.get("tool_calls") or [])
        content = blocks
    return {"role": role, "content": content}


def _anthropic_messages(messages: List[Dict[str, Any]]) -> tuple[List[Dict[str, Any]], str]:
    system = "\n".join(_anthropic_text(message.get("content")) for message in messages if message.get("role") in {"system", "developer"})
    out = [item for message in messages if (item := _anthropic_message(message)) is not None]
    return out, system


def _anthropic_tools(tools: Any) -> List[Dict[str, Any]]:
    out = []
    for tool in tools or []:
        if not isinstance(tool, dict):
            continue
        if tool.get("name") and tool.get("input_schema"):
            out.append(dict(tool))
            continue
        function = tool.get("function") if isinstance(tool.get("function"), dict) else {}
        name = function.get("name") or tool.get("name")
        if name:
            out.append(
                {
                    "name": name,
                    "description": function.get("description") or tool.get("description") or "",
                    "input_schema": function.get("parameters")
                    or function.get("input_schema")
                    or tool.get("input_schema")
                    or {"type": "object", "properties": {}},
                }
            )
    return out


def _anthropic_tool_choice(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, str):
        mapping = {"auto": {"type": "auto"}, "none": {"type": "none"}, "required": {"type": "any"}, "any": {"type": "any"}}
        return mapping.get(value, {"type": "tool", "name": value})
    if isinstance(value, dict):
        kind = value.get("type")
        if kind == "function":
            function = value.get("function") if isinstance(value.get("function"), dict) else {}
            return {"type": "tool", "name": function.get("name") or value.get("name") or ""}
        if kind == "required":
            return {"type": "any"}
    return value


def _anthropic_payload(runtime: Dict[str, Any], spec: LLMSpec, messages: List[Dict[str, Any]], stream: bool = False, **kwargs: Any) -> Dict[str, Any]:
    args = dict(runtime.get("args", {}))
    args.update(kwargs)
    args = _apply_thinking(runtime, spec, args)
    prepared, system = _anthropic_messages(messages)
    tools = _anthropic_tools(args.pop("tools", None))
    tool_choice = _anthropic_tool_choice(args.pop("tool_choice", None))
    extra_body = args.pop("extra_body", {}) or {}
    payload = {
        "model": runtime["model"],
        "messages": prepared,
        "stream": stream,
        **{k: v for k, v in args.items() if v is not None and k in {"max_tokens", "temperature", "top_p", "metadata", "stop_sequences", "thinking", "effort"}},
    }
    if "stop" in args and args["stop"] is not None and "stop_sequences" not in payload:
        payload["stop_sequences"] = args["stop"] if isinstance(args["stop"], list) else [args["stop"]]
    if system:
        payload["system"] = system
    if tools:
        payload["tools"] = tools
    if tool_choice:
        payload["tool_choice"] = tool_choice
    if isinstance(extra_body, dict):
        payload.update({k: v for k, v in extra_body.items() if v is not None})
    return payload


def _anthropic_response(raw: Any) -> Dict[str, Any]:
    data = _as_dict(raw)
    text_parts: List[str] = []
    think_parts: List[str] = []
    tool_calls: List[Dict[str, Any]] = []
    for block in data.get("content") or []:
        item = _as_dict(block)
        kind = item.get("type")
        if kind == "text":
            text_parts.append(str(item.get("text") or ""))
        elif kind == "thinking":
            think_parts.append(str(item.get("thinking") or item.get("text") or ""))
        elif kind == "tool_use":
            tool_calls.append(
                {
                    "id": item.get("id") or "",
                    "type": "function",
                    "function": {"name": item.get("name") or "", "arguments": dumps_json(item.get("input") or {}, indent=None)},
                }
            )
    message = {"role": data.get("role") or "assistant", "content": "".join(text_parts)}
    if think_parts:
        message["reasoning_content"] = "".join(think_parts)
    if tool_calls:
        message["tool_calls"] = tool_calls
    return {
        "id": data.get("id"),
        "model": data.get("model"),
        "choices": [{"message": message, "finish_reason": data.get("stop_reason"), "index": 0}],
        "usage": _anthropic_usage(data.get("usage") or {}),
        "raw": data,
    }


def _anthropic_stream_delta(event: Dict[str, Any], blocks: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:
    kind = event.get("type")
    if kind == "message_start":
        return {"choices": [{"delta": {}}], "usage": _anthropic_usage((event.get("message") or {}).get("usage") or {})}
    if kind == "content_block_start":
        index = int(event.get("index") or 0)
        block = _as_dict(event.get("content_block") or {})
        if block.get("type") == "tool_use":
            block["_tool_index"] = sum(1 for item in blocks.values() if item.get("type") == "tool_use")
        blocks[index] = block
        if block.get("type") == "tool_use":
            return {
                "choices": [
                    {
                        "delta": {
                            "tool_calls": [
                                {
                                    "index": block["_tool_index"],
                                    "id": block.get("id") or "",
                                    "type": "function",
                                    "function": {
                                        "name": block.get("name") or "",
                                        "arguments": dumps_json(block.get("input") or {}, indent=None) if block.get("input") else "",
                                    },
                                }
                            ]
                        }
                    }
                ]
            }
    if kind == "content_block_delta":
        index = int(event.get("index") or 0)
        delta = _as_dict(event.get("delta") or {})
        if delta.get("type") == "text_delta":
            return {"choices": [{"delta": {"content": delta.get("text") or ""}}]}
        if delta.get("type") in {"thinking_delta", "signature_delta"}:
            return {"choices": [{"delta": {"reasoning": delta.get("thinking") or delta.get("signature") or ""}}]}
        if delta.get("type") == "input_json_delta":
            block = blocks.get(index, {})
            return {
                "choices": [
                    {
                        "delta": {
                            "tool_calls": [
                                {
                                    "index": block.get("_tool_index", index),
                                    "id": block.get("id") or "",
                                    "type": "function",
                                    "function": {"name": block.get("name") or "", "arguments": delta.get("partial_json") or ""},
                                }
                            ]
                        }
                    }
                ]
            }
    if kind == "message_delta":
        return {"choices": [{"delta": {}}], "usage": _anthropic_usage(event.get("usage") or {})}
    return {"choices": [{"delta": {}}]}


def _anthropic_stream(events: Any):
    blocks: Dict[int, Dict[str, Any]] = {}
    for event in events:
        chunk = _anthropic_stream_delta(_as_dict(event), blocks)
        if chunk.get("choices") or chunk.get("usage"):
            yield chunk


async def _anthropic_astream(events: Any):
    blocks: Dict[int, Dict[str, Any]] = {}
    source = events if hasattr(events, "__aiter__") else _async_stream(events)
    async for event in source:
        chunk = _anthropic_stream_delta(_as_dict(event), blocks)
        if chunk.get("choices") or chunk.get("usage"):
            yield chunk


def _embedding_payload(runtime: Dict[str, Any], **kwargs: Any) -> Dict[str, Any]:
    args = dict(runtime.get("args", {}))
    args.update(kwargs)
    return {"model": runtime["model"], **{k: v for k, v in args.items() if v is not None and k in EMBEDDING_PAYLOAD_KEYS}}


def _litellm(spec: LLMSpec):
    global _LITELLM_MODULE
    with _CLIENT_CACHE_LOCK:
        module = _LITELLM_MODULE
    if module is not None:
        return module
    gateway_cfg = spec.engine.root().get("gateways", {}).get("litellm", {})
    for key, value in (gateway_cfg.get("env_defaults", {}) or {}).items():
        os.environ.setdefault(str(key), str(value))
    try:
        import litellm
    except Exception as exc:
        raise ImportError("Install litellm or use gateway='portkey', 'openai', or 'bifrost'.") from exc
    litellm.drop_params = True
    with _CLIENT_CACHE_LOCK:
        if _LITELLM_MODULE is None:
            _LITELLM_MODULE = litellm
        return _LITELLM_MODULE


def _has_mock_request(kwargs: Dict[str, Any]) -> bool:
    return any(key in kwargs for key in ("mock", "mock_chat", "mock_embed", "mock_imagen"))


def _add_litellm_client_args(payload: Dict[str, Any], runtime: Dict[str, Any]) -> Dict[str, Any]:
    args = runtime.get("args", {}) or {}
    if args.get("timeout") is not None:
        payload["timeout"] = args["timeout"]
    if args.get("max_retries") is not None:
        payload["num_retries"] = args["max_retries"]
    return payload


def _openrouter_imagen(spec: LLMSpec, prompt: str, images: Iterable[LLMImage] = (), **kwargs: Any) -> Dict[str, Any]:
    client, runtime = _openai_client(spec, spec.gateway)
    content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    content.extend(item.to_dict() for item in images)
    payload = _openai_payload(
        runtime,
        spec=spec,
        messages=[{"role": "user", "content": content}],
        modalities=kwargs.pop("modalities", ["image", "text"]),
        stream=False,
        **kwargs,
    )
    raw = response_dict(client.chat.completions.create(**payload))
    message = (raw.get("choices") or [{}])[0].get("message") or {}
    return {"data": message.get("images") or [], "usage": raw.get("usage") or {}, "raw": raw}


async def _openrouter_aimagen(spec: LLMSpec, prompt: str, images: Iterable[LLMImage] = (), **kwargs: Any) -> Dict[str, Any]:
    client, runtime = _openai_async_client(spec, spec.gateway)
    content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    content.extend(item.to_dict() for item in images)
    payload = _openai_payload(
        runtime,
        spec=spec,
        messages=[{"role": "user", "content": content}],
        modalities=kwargs.pop("modalities", ["image", "text"]),
        stream=False,
        **kwargs,
    )
    raw = response_dict(await client.chat.completions.create(**payload))
    message = (raw.get("choices") or [{}])[0].get("message") or {}
    return {"data": message.get("images") or [], "usage": raw.get("usage") or {}, "raw": raw}


def _openrouter_imagen_litellm(spec: LLMSpec, prompt: str, images: Iterable[LLMImage] = (), **kwargs: Any) -> Dict[str, Any]:
    runtime = spec.engine.apply(spec)
    content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    content.extend(item.to_dict() for item in images)
    payload = _openai_payload(
        runtime,
        spec=spec,
        messages=[{"role": "user", "content": content}],
        modalities=kwargs.pop("modalities", ["image", "text"]),
        stream=False,
        **kwargs,
    )
    if runtime.get("api_key"):
        payload["api_key"] = runtime["api_key"]
    if runtime.get("api_base"):
        payload["api_base"] = runtime["api_base"]
    _add_litellm_client_args(payload, runtime)
    raw = response_dict(_litellm(spec).completion(**payload))
    message = (raw.get("choices") or [{}])[0].get("message") or {}
    return {"data": message.get("images") or [], "usage": raw.get("usage") or {}, "raw": raw}


async def _openrouter_aimagen_litellm(spec: LLMSpec, prompt: str, images: Iterable[LLMImage] = (), **kwargs: Any) -> Dict[str, Any]:
    runtime = spec.engine.apply(spec)
    content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    content.extend(item.to_dict() for item in images)
    payload = _openai_payload(
        runtime,
        spec=spec,
        messages=[{"role": "user", "content": content}],
        modalities=kwargs.pop("modalities", ["image", "text"]),
        stream=False,
        **kwargs,
    )
    if runtime.get("api_key"):
        payload["api_key"] = runtime["api_key"]
    if runtime.get("api_base"):
        payload["api_base"] = runtime["api_base"]
    _add_litellm_client_args(payload, runtime)
    fn = getattr(_litellm(spec), "acompletion", None)
    raw = response_dict(await fn(**payload) if fn else await _run_sync(_litellm(spec).completion, **payload))
    message = (raw.get("choices") or [{}])[0].get("message") or {}
    return {"data": message.get("images") or [], "usage": raw.get("usage") or {}, "raw": raw}


def response_dict(obj: Any) -> Dict[str, Any]:
    """Return provider response as a dictionary."""
    return _as_dict(obj)
