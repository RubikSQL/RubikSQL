"""Bundled LiteLLM gateway."""
