"""Provider-call tracing seam for LLM chat loops.

``LLM.chat``, ``achat``, ``stream``, and ``astream`` accept a ``trace``
callback. When present, every provider-bound request made on behalf of that
call — the first round, each tool round, and each in-turn compaction summary
call — emits one ``request`` event immediately BEFORE provider I/O and one
terminal ``response`` or ``error`` event after it. A cache hit emits nothing:
no provider saw a request.

A ``request`` payload is the documented canonical serialization of the
provider-bound request in HeavenBase's normalized form: the exact messages,
tool schemas, request options, and resolved route, captured at the single
funnel every provider call passes through, before gateway-specific protocol
transforms. Reconstruction and byte-comparison claims target this
serialization (see :func:`request_fingerprint`); wire-level payloads are
deterministic gateway functions of it.

Trace callbacks are observers: an exception inside one is warned once per
exception type and never fails the traced call.
"""

from __future__ import annotations

__all__ = ["LLMTraceEvent", "canonical_request", "emit_event", "forward_trace", "request_fingerprint", "trace_state"]

import json
import warnings
from dataclasses import dataclass, field, replace

from heavenbase.utils import Any, Callable, Dict, List, Mapping, Optional, deepcopy, sha256hash

TraceCallback = Callable[["LLMTraceEvent"], None]

_TRACE_WARNED: set = set()
# These CLIENT_ARG_KEYS are semantic inputs that the gateway compiler consumes
# into a provider payload. They are safe scalar controls, not client wiring, so
# the canonical request must retain them for reconstruction and fingerprinting.
_PROVIDER_SEMANTIC_OPTION_KEYS = {"reasoning_exclude", "reasoning_max_tokens", "think"}
# Client construction/wiring and credential channels never reach a provider
# payload and must never reach a persisted trace. Header channels extend the
# gateway layer's own strip list.
_NON_REQUEST_OPTION_KEYS_EXTRA = {"default_headers", "extra_headers", "headers", "no_proxy"}


def _non_request_option_keys() -> set:
    """Return option keys excluded from canonical request payloads."""
    from .gateways._protocols import CLIENT_ARG_KEYS

    return (set(CLIENT_ARG_KEYS) - _PROVIDER_SEMANTIC_OPTION_KEYS) | _NON_REQUEST_OPTION_KEYS_EXTRA


@dataclass(frozen=True)
class LLMTraceEvent:
    """One provider-call trace event.

    Attributes:
        kind (str): ``"request"`` before provider I/O, then ``"response"`` on
            success or ``"error"`` on failure. A request whose terminal event
            never arrives was interrupted mid-flight.
        call (str): What made the call: ``"round"`` for the main chat loop,
            ``"turn_compaction"`` for an in-turn compaction summary call, or a
            caller-chosen tag when events are forwarded from a sub-call via
            :func:`forward_trace`.
        seq (int): Monotonic sequence number across all events of one traced
            top-level call, shared with forwarded sub-calls, pairing each
            terminal event with its request.
        payload (Dict[str, Any]): For ``request``, the canonical request from
            :func:`canonical_request`; for ``response``, ``{"message",
            "usage", "served_model", "elapsed"}``; for ``error``,
            ``{"error"}``.
    """

    kind: str
    call: str
    seq: int
    payload: Dict[str, Any] = field(default_factory=dict)


def trace_state(emit: TraceCallback) -> Dict[str, Any]:
    """Return the mutable per-call trace state threaded through chat contexts.

    Args:
        emit (TraceCallback): Caller-supplied event observer.

    Returns:
        Dict[str, Any]: ``{"emit", "seq"}`` state shared by every provider
        call (and forwarded sub-call) of one traced top-level call.
    """
    return {"emit": emit, "seq": 0}


def emit_event(state: Mapping[str, Any], event: LLMTraceEvent) -> None:
    """Deliver one event to the trace callback without failing the call.

    A raising callback is an observability defect, not a chat failure: the
    exception is converted to a ``UserWarning`` once per exception type and
    otherwise swallowed.

    Args:
        state (Mapping[str, Any]): State from :func:`trace_state`.
        event (LLMTraceEvent): Event to deliver.
    """
    try:
        state["emit"](event)
    except Exception as error:
        marker = type(error).__name__
        if marker not in _TRACE_WARNED:
            _TRACE_WARNED.add(marker)
            try:
                warnings.warn(f"LLM trace callback failed ({marker}: {error}); tracing continues best-effort", UserWarning, stacklevel=2)
            except Exception:
                pass  # warnings-as-errors must not turn an observer defect into a chat failure


def forward_trace(state: Dict[str, Any], call: Optional[str] = None) -> TraceCallback:
    """Return a callback that forwards a sub-call's events into ``state``.

    A compaction summary (or any caller-made helper call) runs as its own
    ``chat`` invocation with its own inner sequence numbers. The forwarder
    renumbers each event on the outer shared counter — and re-tags it with
    ``call`` when one is given — so one traced conversation keeps a single
    monotonic event order.

    Args:
        state (Dict[str, Any]): Outer state from :func:`trace_state`.
        call (str | None): Tag applied to every forwarded event; ``None``
            keeps each event's own tag. Defaults to ``None``.

    Returns:
        TraceCallback: Callback to pass as the sub-call's ``trace``.
    """
    remap: Dict[int, int] = {}

    def _forward(event: LLMTraceEvent) -> None:
        if event.kind == "request":
            remap[event.seq] = state["seq"]
            state["seq"] += 1
        emit_event(state, replace(event, call=event.call if call is None else call, seq=remap.get(event.seq, event.seq)))

    return _forward


def canonical_request(messages: List[Dict[str, Any]], cfg: Mapping[str, Any], spec: Any, streamable: Optional[bool] = None) -> Dict[str, Any]:
    """Return the canonical serialization of one provider-bound request.

    This is HeavenBase's normalized request form, captured at the single
    funnel every provider call passes through — deliberately BEFORE
    gateway-native compilation, whose wire payload is a deterministic
    function of this form plus the gateway code. ``options`` carries
    request-shaping parameters only: callable values (runtime wiring) and
    client construction/credential channels (api keys, auth tokens, base URLs,
    proxies, mocks, and header wiring) are excluded. Safe semantic controls
    such as ``think`` and ``reasoning_max_tokens`` remain because gateway
    compilation turns them into provider payload fields. Model-visible content
    and arbitrary provider metadata are intentionally captured and may still be
    sensitive even though credential wiring is excluded.

    Args:
        messages (List[Dict[str, Any]]): Messages exactly as handed to the
            provider call (post message formatting, post compaction).
        cfg (Mapping[str, Any]): Request config at call time; ``tools`` rides
            separately. Remaining values are kept when JSON-serializable,
            else replaced by their ``str()`` so the payload stays persistable.
        spec (Any): Resolved ``LLMSpec`` naming the route.
        streamable (bool | None): Effective transport mode of this call
            (streaming vs complete), recorded as ``options.stream`` when
            known. Defaults to ``None``.

    Returns:
        Dict[str, Any]: ``{"messages", "tools", "options", "route"}``.
    """
    excluded = _non_request_option_keys()
    options = {key: _jsonable(value) for key, value in cfg.items() if key != "tools" and key not in excluded and not callable(value)}
    if streamable is not None:
        options["stream"] = bool(streamable)
    route = {
        key: value
        for key, value in {
            "preset": getattr(spec, "preset", None),
            "model": spec.get("model") if hasattr(spec, "get") else None,
            "provider": getattr(spec, "provider", None),
            "gateway": getattr(spec, "gateway", None),
            "endpoint": getattr(spec, "endpoint", None),
        }.items()
        if value
    }
    return {"messages": deepcopy(list(messages)), "tools": deepcopy(list(cfg.get("tools") or [])), "options": options, "route": route}


def request_fingerprint(payload: Mapping[str, Any]) -> str:
    """Return the canonical fingerprint of one request payload.

    Sorted-key JSON (with ``str()`` for stray non-JSON values) is the
    canonical byte form: two payloads are "the same request" exactly when
    their fingerprints match, independent of dict insertion order.

    Args:
        payload (Mapping[str, Any]): Request payload from
            :func:`canonical_request`.

    Returns:
        str: Hex digest of the canonical byte form.
    """
    return sha256hash(json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str))


def _jsonable(value: Any) -> Any:
    """Return ``value`` when JSON-serializable, else its ``str()`` form."""
    try:
        json.dumps(value)
        return deepcopy(value)
    except (TypeError, ValueError):
        return str(value)
