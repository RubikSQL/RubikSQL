"""Entity-backed cache service for LLM requests."""

from __future__ import annotations

__all__ = [
    "LLMCache",
    "LLMEmbeddingEntry",
    "LLMImageEntry",
    "LLMTextEntry",
]

import threading
from time import time
from typing import TYPE_CHECKING
import weakref

from .config import LLMSpec
from .image import LLMImage
from heavenbase.entity import Entity, field
from heavenbase.types import Boolean, Float, Integer, Json, LongText, ShortText
from heavenbase.utils import Any, Dict, Iterable, List, Mapping, Optional, dmerge, dumps_json, hash_id, resolve_interpolations, sha256hash
from heavenbase.utils.log import get_logger

if TYPE_CHECKING:
    from heavenbase.context import Context
    from heavenbase.utils.config import ConfigManager

TEXT = "text"
EMBEDDING = "embedding"
IMAGE = "image"
_logger = get_logger(__name__)

CONTROL_KEYS = {
    "api_key",
    "base_url",
    "batch_max_workers",
    "batch_size",
    "batch_workers",
    "cache",
    "cache_config",
    "cache_policy",
    "dim",
    "embed_max_workers",
    "embedding_batch_size",
    "embedding_max_workers",
    "enforce_non_stream_structured",
    "http_proxy",
    "https_proxy",
    "include",
    "max_retries",
    "mock_pause",
    "mock_seed",
    "max_workers",
    "no_proxy",
    "reduce",
    "stream",
    "stream_chat",
    "structured_stream",
    "timeout",
}

SORTED_LIST_KEYS = {"tools"}


class LLMTextEntry(Entity):
    """Cached normalized chat response."""

    identifier = "llm-text-cache"

    spec_key = field(ShortText).desc("Resolved LLM spec fingerprint")
    request_key = field(ShortText).desc("Semantic request fingerprint")
    messages = field(Json).default([]).desc("Normalized input messages")
    args = field(Json).default({}).desc("Semantic request arguments")
    response = field(Json).default({}).desc("Normalized LLMResponse payload")
    chunks = field(Json).default([]).desc("Normalized stream chunks")
    complete = field(Boolean).default(False).desc("Whether the response completed successfully")
    created_at = field(Float).default(0.0).desc("Creation timestamp")
    accessed_at = field(Float).default(0.0).desc("Last access timestamp")
    n_hits = field(Integer).default(0).desc("Cache hit count")
    expires_at = field(Float).optional().desc("Expiration timestamp")
    policy = field(ShortText).default("deterministic").desc("Write policy")
    size_bytes = field(Integer).default(0).desc("Approximate serialized row size")


class LLMEmbeddingEntry(Entity):
    """Cached single-input embedding response."""

    identifier = "llm-embedding-cache"

    spec_key = field(ShortText).desc("Resolved LLM spec fingerprint")
    input_hash = field(ShortText).desc("Input text fingerprint")
    input_text = field(LongText).default("").desc("Original input text")
    args = field(Json).default({}).desc("Semantic embedding arguments")
    embedding = field(Json).default([]).desc("Embedding vector")
    dim = field(Integer).default(0).desc("Embedding dimension")
    usage = field(Json).default({}).desc("Provider usage payload")
    raw = field(Json).default({}).desc("Provider raw item or response")
    created_at = field(Float).default(0.0).desc("Creation timestamp")
    accessed_at = field(Float).default(0.0).desc("Last access timestamp")
    n_hits = field(Integer).default(0).desc("Cache hit count")
    expires_at = field(Float).optional().desc("Expiration timestamp")
    size_bytes = field(Integer).default(0).desc("Approximate serialized row size")


class LLMImageEntry(Entity):
    """Cached image generation response."""

    identifier = "llm-image-cache"

    spec_key = field(ShortText).desc("Resolved LLM spec fingerprint")
    prompt = field(LongText).default("").desc("Image prompt")
    image_inputs = field(Json).default([]).desc("Reference image digests")
    args = field(Json).default({}).desc("Semantic image arguments")
    images = field(Json).default([]).desc("Normalized generated image payloads")
    usage = field(Json).default({}).desc("Provider usage payload")
    raw = field(Json).default({}).desc("Provider raw response")
    created_at = field(Float).default(0.0).desc("Creation timestamp")
    accessed_at = field(Float).default(0.0).desc("Last access timestamp")
    n_hits = field(Integer).default(0).desc("Cache hit count")
    expires_at = field(Float).optional().desc("Expiration timestamp")
    size_bytes = field(Integer).default(0).desc("Approximate serialized row size")


def _cache_root(manager: "ConfigManager") -> Dict[str, Any]:
    default = ((manager.load_default().get("heavenbase", {}) or {}).get("llm", {}) or {}).get("cache", {}) or {}
    runtime = manager.get("heavenbase.llm.cache", default={}) or {}
    cfg = dmerge([default, runtime])
    if "backend" in runtime:
        cfg["backend"] = runtime["backend"]
    return resolve_interpolations(cfg)


def _looks_image_part(value: Mapping[str, Any]) -> bool:
    """Return whether a mapping looks like an LLM image content part."""
    kind = value.get("type")
    if kind in {"image_url", "image", "input_image"}:
        return True
    return any(key in value for key in ("image_url", "b64_json")) or ("data" in value and any(key in value for key in ("media_type", "format", "image")))


def _canon_image_part(value: Mapping[str, Any]) -> Dict[str, Any]:
    """Digest one image payload while retaining request-affecting metadata."""
    image = LLMImage.from_any(dict(value))
    out = {"image_digest": _image_digest(image)}
    for name in sorted(value):
        item = value[name]
        if name in {"image", "data", "b64_json", "url"}:
            continue
        if name == "image_url":
            if isinstance(item, Mapping):
                metadata = {str(key): _canon(item[key], key=str(key)) for key in sorted(item) if key != "url"}
                if metadata:
                    out[name] = metadata
            continue
        out[str(name)] = _canon(item, key=str(name))
    return out


def _canon(value: Any, key: Optional[str] = None) -> Any:
    if value is None or isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, str):
        if value.startswith("data:image"):
            return {"data_url_hash": sha256hash(value)}
        return value
    if isinstance(value, LLMImage):
        return _image_digest(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"bytes_hash": sha256hash(bytes(value))}
    if callable(value):
        return {"callable": f"{getattr(value, '__module__', '')}.{getattr(value, '__qualname__', getattr(value, '__name__', 'callable'))}"}
    if hasattr(value, "model_dump"):
        return _canon(value.model_dump(), key=key)
    if hasattr(value, "to_dict"):
        return _canon(value.to_dict(), key=key)
    if hasattr(value, "dict"):
        return _canon(value.dict(), key=key)
    if isinstance(value, Mapping):
        if _looks_image_part(value):
            try:
                return _canon_image_part(value)
            except (OSError, TypeError, ValueError):
                pass
        return {str(name): _canon(value[name], key=str(name)) for name in sorted(value)}
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes, bytearray)):
        items = [_canon(item, key=key) for item in value]
        return sorted(items, key=_canon_str) if key in SORTED_LIST_KEYS else items
    return repr(value)


def _canon_str(value: Any) -> str:
    return dumps_json(value, sort_keys=True, compact=True)


def _semantic_args(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Return request arguments that can affect model output."""
    return {key: _canon(value, key=key) for key, value in sorted(dict(args or {}).items()) if key not in CONTROL_KEYS and value is not None}


def _spec_key(spec: LLMSpec, namespace: str) -> str:
    """Return a redacted resolved LLM spec key for one cache namespace."""
    runtime = spec.engine.apply(spec)
    return sha256hash(
        {
            "namespace": namespace,
            "semantic_spec": spec.hash_key(),
            "provider": spec.provider,
            "provider_backend": spec.provider_backend(),
            "model": spec.model,
            "model_id": spec.model_id,
            "gateway": spec.gateway,
            "runtime_model": runtime.get("model"),
            "base_url": runtime.get("base_url") or runtime.get("api_base"),
            "headers_hash": sha256hash(runtime.get("headers", {}) or {}),
            "api_key_hash": sha256hash(runtime.get("api_key")) if runtime.get("api_key") else None,
        }
    )


def _cache_id(namespace: str, spec_hash: str, req_hash: str) -> str:
    return hash_id(namespace, spec_hash, req_hash)


def _image_digest(image: LLMImage) -> Dict[str, Any]:
    """Return a cache-safe reference image digest without fetching remote URLs."""
    if image.data is not None:
        return {"data_hash": sha256hash({"data": image.data, "media_type": image.media_type}), "format": image.format, "media_type": image.media_type}
    return {"url": image.url or "", "format": image.format, "media_type": image.media_type}


class LLMCache:
    """Own semantic request keys and entity-backed LLM cache lifecycle.

    Args:
        config (Mapping[str, Any] | None): Cache configuration merged over
            `heavenbase.llm.cache` defaults.
        config_manager (ConfigManager | None): Configuration authority and owning Context.
            Omission selects ``DEFAULT_CONTEXT.config``.
    """

    def __init__(self, config: Optional[Mapping[str, Any]] = None, *, config_manager: "ConfigManager | None" = None) -> None:
        """Initialize this cache service from configuration.

        Returns:
            None: This function does not return a value.
        """
        if config_manager is None:
            from heavenbase.context import DEFAULT_CONTEXT

            config_manager = DEFAULT_CONTEXT.config
        cfg = dmerge([_cache_root(config_manager), dict(config or {})])
        if config and "backend" in config:
            cfg["backend"] = config["backend"]
        self.config = cfg
        self._config_manager_ref = weakref.ref(config_manager)
        context = getattr(config_manager, "_context", None)
        self._context_ref = None if context is None else weakref.ref(context)
        self._store: Any = None
        self._workspace: Any = None
        self._lock = threading.RLock()

    @property
    def config_manager(self) -> "ConfigManager":
        """Return the live configuration authority for this cache."""
        manager = self._config_manager_ref()
        if manager is None:
            raise RuntimeError("LLM cache configuration authority is no longer available")
        return manager

    @property
    def context(self) -> "Context | None":
        """Return the live Context that owns this cache, when one exists."""
        return None if self._context_ref is None else self._context_ref()

    @classmethod
    def from_dict(cls, data: Optional[Mapping[str, Any]] = None, *, config_manager: "ConfigManager | None" = None, **values: Any) -> "LLMCache":
        """Build a cache service from configuration values.

        Args:
            data (Mapping[str, Any] | None): Base cache configuration.
            config_manager (ConfigManager | None): Configuration authority.
                Omission selects ``DEFAULT_CONTEXT.config``.
            **values (Any): Configuration values that override `data`.

        Returns:
            LLMCache: Unopened cache service.
        """
        cfg = dict(data or {})
        cfg.update(values)
        return cls(cfg, config_manager=config_manager)

    def to_dict(self) -> Dict[str, Any]:
        """Return this cache service configuration.

        Args:
            None.

        Returns:
            Dict[str, Any]: Independent configuration dictionary.
        """
        return dict(self.config)

    @classmethod
    def current(cls, *, config_manager: "ConfigManager | None" = None) -> "LLMCache":
        """Return the cache service owned by one configuration authority.

        Args:
            config_manager (ConfigManager | None): Configuration authority.
                Omission selects ``DEFAULT_CONTEXT.config``.

        Returns:
            LLMCache: Lazily constructed authority-local cache.
        """
        from heavenbase.context import DEFAULT_CONTEXT

        if config_manager is None:
            config_manager = DEFAULT_CONTEXT.config
        with _LLM_CACHE_LOCK:
            global _DEFAULT_LLM_CACHE

            if config_manager is DEFAULT_CONTEXT.config:
                if _DEFAULT_LLM_CACHE is None:
                    _DEFAULT_LLM_CACHE = cls(config_manager=config_manager)
                return _DEFAULT_LLM_CACHE
            reference = _LLM_CACHES.get(config_manager)
            found = None if reference is None else reference()
            if found is None:
                found = cls(config_manager=config_manager)
                _LLM_CACHES[config_manager] = weakref.ref(found)
            return found

    @classmethod
    def reset(cls, *, drop: bool = False, config_manager: "ConfigManager | None" = None) -> None:
        """Reset one authority's cache service or every process cache.

        Args:
            drop (bool): Whether to drop each selected cache workspace first.
            config_manager (ConfigManager | None): Exact configuration
                authority to reset. Omission preserves the process-wide
                maintenance reset.

        Returns:
            None: This method does not return a value.
        """
        with _LLM_CACHE_LOCK:
            global _DEFAULT_LLM_CACHE

            if config_manager is None:
                caches = tuple(cache for reference in _LLM_CACHES.values() if (cache := reference()) is not None)
                if _DEFAULT_LLM_CACHE is not None:
                    caches = (*caches, _DEFAULT_LLM_CACHE)
                    _DEFAULT_LLM_CACHE = None
                _LLM_CACHES.clear()
            else:
                from heavenbase.context import DEFAULT_CONTEXT

                if config_manager is DEFAULT_CONTEXT.config:
                    cache = _DEFAULT_LLM_CACHE
                    _DEFAULT_LLM_CACHE = None
                else:
                    reference = _LLM_CACHES.pop(config_manager, None)
                    cache = None if reference is None else reference()
                caches = () if cache is None else (cache,)
            for cache in caches:
                store = getattr(cache, "_store", None)
                context = cache.context
                if store is not None:
                    if context is None:
                        store.drop() if drop else store.close()
                    else:
                        context._retire_hidden_store(store, drop=drop)
                elif drop:
                    workspace = getattr(cache, "_workspace", None)
                    if workspace is not None:
                        workspace.drop()
                cache._store = None
                cache._workspace = None

    def text_key(self, spec: LLMSpec, messages: List[Dict[str, Any]], args: Mapping[str, Any]) -> Dict[str, Any]:
        """Build a deterministic text request key.

        Args:
            spec (LLMSpec): Resolved LLM provider specification.
            messages (List[Dict[str, Any]]): Normalized chat messages.
            args (Mapping[str, Any]): Request arguments before control-key filtering.

        Returns:
            Dict[str, Any]: Identity and semantic arguments for an `LLMTextEntry` row.
        """
        semantic = _semantic_args(args)
        spec_hash = _spec_key(spec, TEXT)
        req_hash = sha256hash({"messages": _canon(messages), "args": semantic})
        return {"object_id": _cache_id(TEXT, spec_hash, req_hash), "spec_key": spec_hash, "request_key": req_hash, "args": semantic}

    def embedding_key(self, spec: LLMSpec, input_text: str, args: Mapping[str, Any]) -> Dict[str, Any]:
        """Build a deterministic embedding request key.

        Args:
            spec (LLMSpec): Resolved LLM provider specification.
            input_text (str): One embedding input.
            args (Mapping[str, Any]): Request arguments before control-key filtering.

        Returns:
            Dict[str, Any]: Identity and semantic arguments for an `LLMEmbeddingEntry` row.
        """
        semantic = _semantic_args(args)
        spec_hash = _spec_key(spec, EMBEDDING)
        input_hash = sha256hash(input_text)
        req_hash = sha256hash({"input_hash": input_hash, "args": semantic})
        return {"object_id": _cache_id(EMBEDDING, spec_hash, req_hash), "spec_key": spec_hash, "input_hash": input_hash, "args": semantic}

    def image_key(self, spec: LLMSpec, prompt: str, refs: List[LLMImage], args: Mapping[str, Any]) -> Dict[str, Any]:
        """Build a deterministic image request key.

        Args:
            spec (LLMSpec): Resolved LLM provider specification.
            prompt (str): Image generation prompt.
            refs (List[LLMImage]): Normalized reference images.
            args (Mapping[str, Any]): Request arguments before control-key filtering.

        Returns:
            Dict[str, Any]: Identity, reference digests, and semantic arguments for an `LLMImageEntry` row.
        """
        semantic = _semantic_args(args)
        spec_hash = _spec_key(spec, IMAGE)
        image_inputs = [_image_digest(ref) for ref in refs]
        req_hash = sha256hash({"prompt": prompt, "image_inputs": image_inputs, "args": semantic})
        return {
            "object_id": _cache_id(IMAGE, spec_hash, req_hash),
            "spec_key": spec_hash,
            "image_inputs": image_inputs,
            "request_key": req_hash,
            "args": semantic,
        }

    def dump_images(self, images: Any) -> List[Dict[str, Any]]:
        """Serialize generated images for an image cache row.

        Args:
            images (Any): One `LLMImage` or a list of images.

        Returns:
            List[Dict[str, Any]]: JSON-compatible image payloads. Non-image values are omitted.
        """
        items = images if isinstance(images, list) else [images]
        return [
            {"data": image.data, "url": image.url, "media_type": image.media_type, "format": image.format, "revised_prompt": image.revised_prompt}
            for image in items
            if isinstance(image, LLMImage)
        ]

    def load_images(self, payloads: Iterable[Mapping[str, Any]]) -> List[LLMImage]:
        """Hydrate images from an image cache row.

        Args:
            payloads (Iterable[Mapping[str, Any]]): Stored JSON-compatible image payloads.

        Returns:
            List[LLMImage]: Normalized image values in payload order.
        """
        return [
            LLMImage(
                data=item.get("data"),
                url=item.get("url"),
                media_type=item.get("media_type") or "image/png",
                format=item.get("format") or "png",
                revised_prompt=item.get("revised_prompt"),
                _url_timeout=None,
            )._bound(self.config_manager)
            for item in payloads
        ]

    @property
    def workspace(self) -> Any:
        """Lazily created workspace that stores cache entries."""
        with self._lock:
            context = self.context
            if context is None:
                raise RuntimeError(
                    "LLM cache persistence requires a Context-bound ConfigManager; "
                    "construct LLM(context=...), bind the manager to a Context, or disable caching"
                )
            if self._store is not None and not self._store.retired:
                return self._workspace
            self._store = context._new_hidden_store(self.config)
            self._workspace = self._store.workspace
            for entity in (LLMTextEntry, LLMEmbeddingEntry, LLMImageEntry):
                if entity.schema().entity_id not in self._workspace.entities:
                    self._workspace.register(entity)
            return self._workspace

    def ns_cfg(self, namespace: str) -> Dict[str, Any]:
        """Return configuration for one cache namespace.

        Args:
            namespace (str): Cache namespace such as `text`, `embedding`, or `image`.

        Returns:
            Dict[str, Any]: Independent namespace configuration dictionary.
        """
        return dict((self.config.get("namespaces") or {}).get(namespace) or {})

    def enabled(self, namespace: str, option: Any = None) -> bool:
        """Return whether one request should use a cache namespace.

        Args:
            namespace (str): Cache namespace.
            option (Any): Request override. `False` disables caching and a truthy value enables it subject to namespace configuration.

        Returns:
            bool: Whether cache reads and eligible writes are enabled.
        """
        if option is False:
            return False
        if not (bool(option) or bool(self.config.get("enabled", False))):
            return False
        return bool(self.ns_cfg(namespace).get("enabled", True))

    def policy(self, namespace: str, args: Mapping[str, Any], policy: Optional[str] = None) -> Optional[str]:
        """Resolve the write policy for one request.

        Args:
            namespace (str): Cache namespace.
            args (Mapping[str, Any]): Semantic provider arguments.
            policy (str | None): Optional request policy override.

        Returns:
            str | None: Effective policy, or `None` when the request must bypass the cache.
        """
        if self._stochastic_without_seed(args):
            return None
        name = str(policy or self.config.get("policy") or "deterministic")
        if name in {"off", "none", "false"}:
            return None
        if name in {"force", "always"}:
            return name
        if namespace == EMBEDDING:
            return name
        return name if self._deterministic(namespace, args) else None

    def _deterministic(self, namespace: str, args: Mapping[str, Any]) -> bool:
        temp = args.get("temperature")
        top_p = args.get("top_p")
        top_k = args.get("top_k")
        seed = args.get("seed")
        if temp not in (None, 0, 0.0) and seed is None:
            return False
        if top_p not in (None, 0, 0.0, 1, 1.0):
            return False
        if top_k not in (None, 0, 1):
            return False
        return namespace != IMAGE or args.get("seed") is not None

    def _stochastic_without_seed(self, args: Mapping[str, Any]) -> bool:
        temp = args.get("temperature")
        return temp not in (None, 0, 0.0) and args.get("seed") is None

    def expires_at(self, namespace: str, now: float) -> Optional[float]:
        """Return the expiration timestamp for a new row.

        Args:
            namespace (str): Cache namespace whose TTL applies.
            now (float): Row creation time as Unix seconds.

        Returns:
            float | None: Expiration time as Unix seconds, or `None` when no TTL applies.
        """
        ttl = self.ns_cfg(namespace).get("ttl_seconds")
        return now + float(ttl) if ttl else None

    def expired(self, row: Mapping[str, Any], now: Optional[float] = None) -> bool:
        """Return whether a cache row has expired.

        Args:
            row (Mapping[str, Any]): Cache row containing an optional `expires_at` value.
            now (float | None): Comparison time as Unix seconds. Defaults to the current time.

        Returns:
            bool: Whether the row's expiration time has passed.
        """
        expires_at = row.get("expires_at")
        return expires_at is not None and float(expires_at) <= (time() if now is None else now)

    def get_text(self, key: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
        """Return a completed text cache row and record the hit.

        Args:
            key (Mapping[str, Any]): Key payload returned by `text_key`.

        Returns:
            Dict[str, Any] | None: Cached row, or `None` when absent, incomplete, or expired.
        """
        row = self.workspace.get(key["object_id"], entity=LLMTextEntry)
        if not row or not row.get("complete") or self.expired(row):
            return None
        self.touch(LLMTextEntry, row)
        return row

    def set_text(
        self, key: Mapping[str, Any], messages: List[Dict[str, Any]], response: Mapping[str, Any], chunks: List[Mapping[str, Any]], policy: str
    ) -> None:
        """Write a completed text cache row.

        Image payloads in ``messages`` are digested before persistence so multimodal
        chat requests do not store raw base64/data-URL bytes. Rows that exceed the
        namespace ``max_bytes`` budget are skipped. Persistence failures are logged and
        swallowed so optional cache writes cannot fail an otherwise successful chat.

        Args:
            key (Mapping[str, Any]): Key payload returned by `text_key`.
            messages (List[Dict[str, Any]]): Normalized input messages.
            response (Mapping[str, Any]): Normalized response payload.
            chunks (List[Mapping[str, Any]]): Normalized stream chunks.
            policy (str): Policy that authorized the write.

        Returns:
            None: This method does not return a value.
        """
        now = time()
        row = {
            "object_id": key["object_id"],
            "spec_key": key["spec_key"],
            "request_key": key["request_key"],
            "messages": _canon(messages),
            "args": key["args"],
            "response": dict(response),
            "chunks": list(chunks),
            "complete": True,
            "created_at": now,
            "accessed_at": now,
            "n_hits": 0,
            "expires_at": self.expires_at(TEXT, now),
            "policy": policy,
        }
        if row["expires_at"] is None:
            row.pop("expires_at")
        row["size_bytes"] = self.size(row)
        max_bytes = self.ns_cfg(TEXT).get("max_bytes")
        if max_bytes is not None and int(max_bytes) > 0 and row["size_bytes"] > int(max_bytes):
            _logger.warning(
                "Skipping text cache write for %s: size %s exceeds max_bytes %s",
                key["object_id"],
                row["size_bytes"],
                int(max_bytes),
            )
            return
        try:
            self.workspace.upsert(LLMTextEntry, row)
        except Exception as exc:
            _logger.warning("Text cache persistence failed for %s (%s)", key["object_id"], type(exc).__name__)

    def get_embedding(self, key: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
        """Return a single-input embedding cache row and record the hit.

        Args:
            key (Mapping[str, Any]): Key payload returned by `embedding_key`.

        Returns:
            Dict[str, Any] | None: Cached row, or `None` when absent or expired.
        """
        return self.get_embeddings({"value": key}).get("value")

    def get_embeddings(self, keys: Mapping[str, Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Return embedding cache rows for many inputs and record hits in one batch.

        Args:
            keys (Mapping[str, Mapping[str, Any]]): Input text to embedding-key payload mapping.

        Returns:
            Dict[str, Dict[str, Any]]: Unexpired cached rows keyed by input text.
        """
        items = list(keys.items())
        rows = self.workspace.get_many([key["object_id"] for _, key in items], entity=LLMEmbeddingEntry)
        out = {input_text: row for (input_text, _), row in zip(items, rows) if row and not self.expired(row)}
        if out and self.ns_cfg(EMBEDDING).get("touch_hits"):
            self.touch_many(LLMEmbeddingEntry, out.values())
        return out

    def set_embedding(self, key: Mapping[str, Any], input_text: str, embedding: List[Any], dim: int, usage: Mapping[str, Any], raw: Any) -> None:
        """Write a single-input embedding cache row.

        Args:
            key (Mapping[str, Any]): Key payload returned by `embedding_key`.
            input_text (str): Original embedding input.
            embedding (List[Any]): Provider embedding vector.
            dim (int): Vector dimension.
            usage (Mapping[str, Any]): Provider usage payload.
            raw (Any): Provider response payload.

        Returns:
            None: This method does not return a value.
        """
        self.set_embeddings([{"key": key, "input_text": input_text, "embedding": embedding, "dim": dim, "usage": usage, "raw": raw}])

    def set_embeddings(self, items: Iterable[Mapping[str, Any]]) -> None:
        """Write multiple embedding cache rows in one batch.

        Args:
            items (Iterable[Mapping[str, Any]]): Row inputs containing key, text, vector, dimension, usage, and raw response values.

        Returns:
            None: This method does not return a value.
        """
        now = time()
        rows = []
        for item in items:
            key = item["key"]
            row = {
                "object_id": key["object_id"],
                "spec_key": key["spec_key"],
                "input_hash": key["input_hash"],
                "input_text": item["input_text"],
                "args": key["args"],
                "embedding": item["embedding"],
                "dim": item["dim"],
                "usage": dict(item.get("usage") or {}),
                "raw": item.get("raw"),
                "created_at": now,
                "accessed_at": now,
                "n_hits": 0,
                "expires_at": self.expires_at(EMBEDDING, now),
            }
            if row["expires_at"] is None:
                row.pop("expires_at")
            row["size_bytes"] = self.size(row)
            rows.append(row)
        if rows:
            self.workspace.upsert_many(LLMEmbeddingEntry, rows)

    def get_image(self, key: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
        """Return an image cache row and record the hit.

        Args:
            key (Mapping[str, Any]): Key payload returned by `image_key`.

        Returns:
            Dict[str, Any] | None: Cached row, or `None` when absent or expired.
        """
        row = self.workspace.get(key["object_id"], entity=LLMImageEntry)
        if not row or self.expired(row):
            return None
        self.touch(LLMImageEntry, row)
        return row

    def set_image(self, key: Mapping[str, Any], prompt: str, images: List[Mapping[str, Any]], usage: Mapping[str, Any], raw: Any) -> None:
        """Write an image generation cache row.

        Args:
            key (Mapping[str, Any]): Key payload returned by `image_key`.
            prompt (str): Image generation prompt.
            images (List[Mapping[str, Any]]): Serialized generated images.
            usage (Mapping[str, Any]): Provider usage payload.
            raw (Any): Provider response payload.

        Returns:
            None: This method does not return a value.
        """
        now = time()
        row = {
            "object_id": key["object_id"],
            "spec_key": key["spec_key"],
            "prompt": prompt,
            "image_inputs": key["image_inputs"],
            "args": key["args"],
            "images": list(images),
            "usage": dict(usage or {}),
            "raw": raw,
            "created_at": now,
            "accessed_at": now,
            "n_hits": 0,
            "expires_at": self.expires_at(IMAGE, now),
        }
        if row["expires_at"] is None:
            row.pop("expires_at")
        row["size_bytes"] = self.size(row)
        self.workspace.upsert(LLMImageEntry, row)

    def touch(self, entity: type, row: Mapping[str, Any]) -> None:
        """Update access metadata for one cache row.

        Args:
            entity (type): Cache entity class that owns the row.
            row (Mapping[str, Any]): Existing cache row.

        Returns:
            None: This method does not return a value.
        """
        self.touch_many(entity, [row])

    def touch_many(self, entity: type, rows: Iterable[Mapping[str, Any]]) -> None:
        """Update access metadata for multiple cache rows.

        Args:
            entity (type): Cache entity class that owns the rows.
            rows (Iterable[Mapping[str, Any]]): Existing cache rows.

        Returns:
            None: This method does not return a value.
        """
        now = time()
        data = []
        for row in rows:
            item = {key: value for key, value in dict(row).items() if key != "entity_id"}
            if item.get("expires_at") is None:
                item.pop("expires_at", None)
            item.update({"accessed_at": now, "n_hits": int(row.get("n_hits") or 0) + 1})
            data.append(item)
        if data:
            self.workspace.upsert_many(entity, data)

    def size(self, row: Mapping[str, Any]) -> int:
        """Return an approximate serialized row size.

        Args:
            row (Mapping[str, Any]): Cache row to serialize.

        Returns:
            int: UTF-8 byte length of the compact JSON representation.
        """
        return len(dumps_json(row, sort_keys=True, compact=True).encode("utf-8"))


_LLM_CACHES: weakref.WeakKeyDictionary["ConfigManager", weakref.ReferenceType[LLMCache]] = weakref.WeakKeyDictionary()
_LLM_CACHE_LOCK = threading.RLock()
_DEFAULT_LLM_CACHE: LLMCache | None = None
