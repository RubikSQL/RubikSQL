"""Desktop-host selection and dashboard server lifecycle."""

from __future__ import annotations

__all__ = ["HostMode", "open_dashboard", "serve"]

import socket
import subprocess
import threading
import time
import webbrowser

from heavenbase.api import DashboardAPI, resolve_bind, run_server
from heavenbase.dashboard.assets import gui_file
from heavenbase.utils import cmd, is_macos
from heavenbase.utils.config import CM_HVNB
from heavenbase.utils.files import exists_file, exists_path
from heavenbase.utils.typing import Any, Callable, Literal, Optional
from heavenbase.utils.values import raise_mismatch

HostMode = Literal["auto", "webview", "browser", "app"]
HOST_MODES = ("auto", "webview", "browser", "app")
CHROMIUM_APPS = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
)


def _gui_file(area: str, *parts: str) -> str:
    """Resolve one GUI asset from a source checkout or installed wheel."""
    return str(gui_file(area, *parts))


def _open_webview(url: str) -> bool:
    """Open the macOS system WebView host when it is available."""
    if not is_macos():
        return False
    from .macos import default_macos_app_path

    app = default_macos_app_path()
    if exists_path(app):
        try:
            return bool(
                cmd(
                    ["/usr/bin/open", "-na", app, "--args", url],
                    include="ok",
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            )
        except OSError:
            pass
    script = _gui_file("host", "macos.js")
    if not exists_file(script):
        return False
    icon = _gui_file("ui", "assets", "heavenbase-logo-concentric-wide-light-128.png")
    try:
        handle = cmd(
            ["/usr/bin/osascript", "-l", "JavaScript", script, url, icon],
            wait=False,
            include="handle",
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError:
        return False
    time.sleep(0.2)
    return handle.poll() is None


def _open_app_window(url: str) -> bool:
    """Open a Chromium `--app` window when one is installed."""
    candidates = [binary for binary in CHROMIUM_APPS if exists_path(binary)]
    candidates.extend(("google-chrome", "chromium", "chromium-browser", "microsoft-edge", "brave-browser"))
    for binary in candidates:
        try:
            cmd([binary, f"--app={url}", "--window-size=1280,800"], wait=False, include="handle")
            return True
        except OSError:
            continue
    return False


def open_dashboard(url: str, mode: HostMode = "auto") -> HostMode:
    """Open the dashboard with the requested desktop host policy.

    `auto` and `webview` prefer the macOS system WebView and fall back to the
    system browser when the host is unavailable. Chromium `--app` remains an
    explicit fallback mode.

    Args:
        url (str): Loopback dashboard URL to open.
        mode (HostMode): Host selection policy.
            Supported values:
            - `auto`: Prefer the system WebView, then use the system browser.
            - `webview`: Request the system WebView with browser fallback.
            - `browser`: Open the system browser directly.
            - `app`: Open Chromium `--app`, with browser fallback.

    Returns:
        HostMode: Host mode that accepted the launch.
    """
    if mode not in HOST_MODES:
        raise_mismatch(HOST_MODES, mode, name="dashboard host mode")
    if mode in {"auto", "webview"} and _open_webview(url):
        return "webview"
    if mode == "app" and _open_app_window(url):
        return "app"
    webbrowser.open(url)
    return "browser"


def _open_when_ready(
    url: str,
    host: str,
    port: int,
    *,
    timeout: float = 6.0,
    opener: Callable[[str], Any] = open_dashboard,
) -> None:
    """Call an opener once the local API port accepts connections."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                opener(url)
                return
        except OSError:
            time.sleep(0.15)


def serve(
    host: Optional[str] = None,
    port: Optional[int] = None,
    open_window: Optional[bool] = None,
    api: Optional[DashboardAPI] = None,
    host_mode: HostMode = "auto",
    allow_network: bool = False,
) -> None:
    """Launch the dashboard host and run its local HTTP service.

    Args:
        host (str | None): Bind host. Defaults to
            `heavenbase.dashboard.host` (`127.0.0.1`).
        port (int | None): Bind port. Defaults to
            `heavenbase.dashboard.port` (`42777`).
        open_window (bool | None): Whether to open a desktop window after the
            server starts. Defaults to `heavenbase.dashboard.open`.
        api (DashboardAPI | None): Application service backing the routes.
            Defaults to a fresh service over `CM_HVNB`.
        host_mode (HostMode): Desktop host policy documented by
            `open_dashboard`.
        allow_network (bool): Allow a non-loopback bind that exposes the
            unauthenticated API. Defaults to `False`.

    Returns:
        None: This function does not return a value.
    """
    if host_mode not in HOST_MODES:
        raise_mismatch(HOST_MODES, host_mode, name="dashboard host mode")
    cm = api.cm if api else CM_HVNB
    # A session log that cannot keep its durability or credential promises
    # must refuse to serve, not degrade silently after the first turn.
    from heavenbase.api.assist_log import AssistSessionLog

    AssistSessionLog.validate(cm)
    host, port = resolve_bind(cm, host, port)
    should_open = bool(cm.get("heavenbase.dashboard.open", True)) if open_window is None else open_window
    if should_open:
        name = host.strip().lower()
        broad = name in {"0.0.0.0", "::", ""}
        open_host = "::1" if name == "::" else "127.0.0.1" if broad else name
        url_host = f"[{open_host}]" if ":" in open_host else open_host
        threading.Thread(
            target=_open_when_ready,
            args=(f"http://{url_host}:{port}", open_host, port),
            kwargs={"opener": lambda url: open_dashboard(url, host_mode)},
            daemon=True,
        ).start()
    run_server(host=host, port=port, api=api, allow_network=allow_network)
