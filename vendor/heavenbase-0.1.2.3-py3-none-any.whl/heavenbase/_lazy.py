"""Shared lazy export loading helpers for package facades."""

from __future__ import annotations

from importlib import import_module
from typing import Any, Callable, Collection, Mapping

LazyExportTable = Mapping[str, tuple[str, str | None]]
LazyExportGetter = Callable[[str], Any]
LazyExportDir = Callable[[], list[str]]
RegistryEntityExportTable = Mapping[str, str]
RegistryExecutableExportTable = Mapping[str, tuple[str, str]]
RegistrySiblingExportTable = Mapping[str, tuple[str, str, str]]


def load_lazy_export(
    name: str,
    exports: LazyExportTable,
    package: str | None,
    namespace: dict[str, Any],
    *,
    owner: str | None = None,
) -> Any:
    """Load one lazy export and cache it on the caller namespace.

    Args:
        name: Requested attribute name.
        exports: Mapping from public attribute name to ``(module, attr)``.
        package: Package anchor for relative imports, or ``None`` for absolute imports.
        namespace: Caller globals where the resolved value should be cached.
        owner: Module name to report in ``AttributeError``. Defaults to ``package``.

    Returns:
        The resolved module or module attribute.

    Raises:
        AttributeError: If ``name`` is not present in ``exports``.
    """
    target = exports.get(name)
    module_owner = owner or package or ""
    if target is None:
        raise AttributeError(f"module {module_owner!r} has no attribute {name!r}")
    module_name, attr_name = target
    module = import_module(module_name, package) if package else import_module(module_name)
    value = module if attr_name is None else getattr(module, attr_name)
    namespace[name] = value
    return value


def _attach_lazy_exports(
    package: str,
    namespace: dict[str, Any],
    exports: LazyExportTable,
    public: Collection[str],
    *,
    owner: str | None = None,
) -> tuple[LazyExportGetter, LazyExportDir]:
    """Create standard lazy attribute and directory hooks for one module.

    Args:
        package: Package anchor used for relative import targets.
        namespace: Module globals where resolved values are cached.
        exports: Public names mapped to ``(module, attr)`` targets.
        public: Complete public surface, normally ``__all__``.
        owner: Module name used in missing-attribute errors. Defaults to ``package``.

    Returns:
        Module ``__getattr__`` and ``__dir__`` hooks.
    """

    def __getattr__(name: str) -> Any:
        return load_lazy_export(name, exports, package, namespace, owner=owner)

    def __dir__() -> list[str]:
        return sorted(set(namespace).union(public))

    return __getattr__, __dir__


def _attach_registry_exports(
    namespace: dict[str, Any],
    public: Collection[str],
    *,
    entities: RegistryEntityExportTable | None = None,
    executables: RegistryExecutableExportTable | None = None,
    siblings: RegistrySiblingExportTable | None = None,
    owner: str | None = None,
) -> tuple[LazyExportGetter, LazyExportDir]:
    """Create dynamic facade hooks backed by the active Registry generation.

    Entity exports resolve their own Registry records. Sibling exports use an
    Entity record as the artifact-generation anchor, so helpers and companion
    classes come from the same verified source folder. Executable exports
    resolve their own Registry records.

    Args:
        namespace: Module globals used for directory reporting.
        public: Complete public surface, normally ``__all__``.
        entities: Public names mapped to Entity registration identifiers.
        executables: Public names mapped to ``(kind, identifier)`` records.
        siblings: Public names mapped to ``(entity, module, attribute)``.
        owner: Module name used in missing-attribute errors.

    Returns:
        Module ``__getattr__`` and ``__dir__`` hooks.

    Raises:
        RuntimeError: If a public name has multiple Registry routes or a route
            is absent from ``public``.
    """
    entity_routes = dict(entities or {})
    executable_routes = dict(executables or {})
    sibling_routes = dict(siblings or {})
    routed = [*entity_routes, *executable_routes, *sibling_routes]
    if len(routed) != len(set(routed)):
        raise RuntimeError("Registry facade export names must have exactly one route")
    undeclared = set(routed).difference(public)
    if undeclared:
        raise RuntimeError(f"Registry facade routes are absent from __all__: {sorted(undeclared)!r}")
    module_owner = owner or str(namespace.get("__name__", ""))

    def __getattr__(name: str) -> Any:
        entity_id = entity_routes.get(name)
        if entity_id is not None:
            from .entity.registry import load_entity_type

            return load_entity_type(entity_id)
        executable = executable_routes.get(name)
        if executable is not None:
            from .modules import module_resolver

            return module_resolver().resolve(*executable)
        sibling = sibling_routes.get(name)
        if sibling is not None:
            from .entity.registry import load_entity_artifact_export

            entity_id, module_name, attr_name = sibling
            return load_entity_artifact_export(entity_id, module_name, attr_name)
        raise AttributeError(f"module {module_owner!r} has no attribute {name!r}")

    def __dir__() -> list[str]:
        return sorted(set(namespace).union(public))

    return __getattr__, __dir__
