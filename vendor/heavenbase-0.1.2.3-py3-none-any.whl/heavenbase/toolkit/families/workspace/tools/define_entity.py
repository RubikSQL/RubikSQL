"""MCP tool for registering workspace entity schemas."""

from __future__ import annotations

__all__ = ["build_tool"]

from heavenbase.utils import Any, Dict

from ..context import WorkspaceToolContext
from ..errors import mcp_raise
from ..schema import normalize_entity_spec


def build_tool(context: WorkspaceToolContext) -> Any:
    """Build the ``define_entity`` tool for one workspace context.

    Args:
        context (WorkspaceToolContext): Shared workspace and profile state for the tool factory.

    Returns:
        Any: MCP-callable ``define_entity`` function bound to ``context``.
    """

    def define_entity(entity: Dict[str, Any], replace: bool = False) -> Dict[str, Any]:
        """Register an entity schema in the workspace.

        Args:
            entity: Entity schema object accepted by ``HeavenBase.register``.
            replace: Whether to replace an existing entity with the same id.

        Returns:
            Entity schema, storage plan, derives, and query capabilities.

        Raises:
            RuntimeError: If registration fails; the message is redacted for MCP use.
        """
        try:
            normalized = normalize_entity_spec(entity)
            entity_cls = context.workspace._schema.entity_cls(normalized, allow_dict=True)
            context.require_entity(entity_cls.schema().entity_id)
            entity_cls = context.workspace.register(entity_cls, allow_replace=replace)
            return context.entity_dict(entity_cls)
        except Exception as exc:
            mcp_raise(exc)

    return define_entity
